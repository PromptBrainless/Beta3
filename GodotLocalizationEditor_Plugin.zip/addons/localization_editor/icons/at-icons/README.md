# @icons

Icons in this directory are sourced from [@icons](https://github.com/Voxybuns/at-icons) by Voxybuns.

See [LICENSE.txt](./LICENSE.txt) for license details.
