@tool
extends EditorPlugin

const ICON: Texture2D = preload("res://addons/localization_editor/gle-plugin-icon.svg")
const DOCK = preload("res://addons/localization_editor/scenes/dock.tscn")

var dock_instance


func _enter_tree() -> void:
	dock_instance = DOCK.instantiate()
	# ConfigManager is provided by Main.tscn in standalone mode; create it here for editor mode.
	var config_manager = load("res://addons/localization_editor/scripts/config_manager.gd").new()
	config_manager.name = "ConfigManager"
	dock_instance.add_child(config_manager)
	dock_instance._config_manager = config_manager
	dock_instance.connect("scan_files_requested", Callable(self, "_on_scan_files_requested"))
	# Add the main panel to the editor's main viewport.
	get_editor_interface().get_editor_main_screen().add_child(dock_instance)
	# Hide the main panel. Very much required.
	_make_visible(false)


func _exit_tree():
	if dock_instance:
		dock_instance.queue_free()


func _has_main_screen():
	return true


func _make_visible(visible):
	if dock_instance:
		dock_instance.visible = visible


func _get_plugin_name():
	return "Translations"


func _get_plugin_icon():
	return ICON


func _on_scan_files_requested() -> void:
	if Engine.is_editor_hint() == true:
		get_editor_interface().get_resource_filesystem().scan()
