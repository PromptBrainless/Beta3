@tool
extends Popup

signal file_selected(filename: String, delimiter: String)

@onready var _file_dialog: FileDialog = $FileDialog
@onready var _line_edit: LineEdit = $MarginContainer/VBoxContainer/HBoxContainer/LineEdit
@onready var _open_button: Button = $MarginContainer/VBoxContainer/Button
@onready
var _delimiter_option: OptionButton = $MarginContainer/VBoxContainer/HBoxContainer2/OptionButton

var _selected_file: String
var _delimiter := ","


func _ready() -> void:
	_file_dialog.access = (
		FileDialog.ACCESS_RESOURCES if Engine.is_editor_hint() else FileDialog.ACCESS_FILESYSTEM
	)


func _on_file_dialog_file_selected(path: String) -> void:
	_selected_file = path
	_line_edit.placeholder_text = ".../%s" % path.get_file()
	_line_edit.tooltip_text = path
	_open_button.disabled = false


func _on_about_to_popup() -> void:
	_selected_file = ""
	_line_edit.placeholder_text = ""
	_line_edit.tooltip_text = ""
	_open_button.disabled = true
	_delimiter = ","
	_delimiter_option.select(0)


func _on_option_button_item_selected(index: int) -> void:
	match index:
		1:
			_delimiter = ";"
		2:
			_delimiter = "	"
		_:
			_delimiter = ","


func _on_open_button_pressed():
	file_selected.emit(_selected_file, _delimiter)
	self.hide()
