@tool
extends Node

# Structure of translation entry data
# {
#   "key": "SOME_KEY",
#   "translations": {
#     "lang_1": "translation 1",
#     "lang_2": "translation 2",
#     ...
#     "lang_n": "translation n"
#   },
#   "index": 0,
#   "needs_revision": false,
#   "notes": "notes go here"
# }

signal data_changed(new_data: Dictionary)
signal translation_requested(
	source_lang: String, source_text: String, target_lang: String, callback: Callable
)
signal removed(key: String)
signal reorder_requested(direction: int)
signal jump_requested(target_data_idx: int)

@export var _ref_lang_label: Label
@export var _target_lang_line_edit: LineEdit
@export var _key_label: Label
@export var _needs_revision_cb: Button
@export var _empty_translation_color: Color
@export var _translate_button: Button
@export var _index_line_edit: LineEdit
@export var _dec_index_button: Button
@export var _inc_index_button: Button

@onready var _edit_translation_popup: Popup = $EditEntryPopup
@onready var _delete_popup: ConfirmationDialog = $Popup
var _default_translation_color: Color = Color.WHITE
@onready var _config_manager: Node = get_tree().root.find_child("ConfigManager", true, false)

var key: String = "Translation Key":
	set(new_value):
		var old_value: String = _entry_data.get("key", new_value)
		_entry_data["key"] = new_value
		_key_label.text = key
		if old_value != new_value and _is_ready_for_emit_signals:
			_config_manager.replace_key(old_value, new_value)
			_emit_data_changed()
	get:
		return _entry_data["key"]

var ref_text: String = "Reference Translation":
	set(new_value):
		_ref_lang_label.text = "[EMPTY]" if new_value.is_empty() else new_value

var target_text: String = "Translated Text":
	set(new_value):
		target_text = new_value
		if is_instance_valid(_target_lang_line_edit):
			if _target_lang_line_edit.text != new_value:
				_target_lang_line_edit.text = new_value
			_target_lang_line_edit.modulate = (
				_empty_translation_color if new_value.is_empty() else _default_translation_color
			)

var notes: String = "":
	set(new_value):
		var old_value: String = _entry_data.get("notes", new_value)
		_entry_data["notes"] = new_value
		if old_value != new_value and _is_ready_for_emit_signals:
			_config_manager.set_key_value(key, "notes", new_value)
	get:
		return _entry_data["notes"]

var needs_revision: bool = false:
	set(new_value):
		_entry_data["needs_revision"] = new_value
	get:
		return _entry_data["needs_revision"]

var old_config: Dictionary = {}
var new_config: Dictionary = {}
var ref_lang: String = "en"
var target_lang: String = "es"

# flag to avoid emitting signal as soon as the object is added to the tree
var _is_ready_for_emit_signals: bool
var _previous_key: String
var _is_dragging: bool = false
var _entry_data: Dictionary = {}
var _grab_focus: bool = false
var _key_is_invalid: bool = false
var _revision_forced_by_key: bool = false

# Virtual scroll tracking - set by translation_list
var data_index: int = 0
var filter_index: int = 0
var filter_total: int = 0


func _ready():
	if _grab_focus:
		_target_lang_line_edit.grab_focus()
		_target_lang_line_edit.caret_column = _target_lang_line_edit.text.length()
		_grab_focus = false


func has_translation() -> bool:
	return !_target_lang_line_edit.text.is_empty()


func _emit_data_changed():
	if not _is_ready_for_emit_signals:
		return
	data_changed.emit(_entry_data)


func get_entry_data() -> Dictionary:
	return _entry_data


func set_translation_data(
	key: String,
	ref_lang: String,
	target_lang: String,
	translations: Dictionary,
	notes: String,
	needs_revision: bool,
	p_data_index: int = 0,
	start_focused := false,
	has_google := false
) -> void:
	self.key = key
	self.ref_lang = ref_lang
	self.ref_text = translations[ref_lang]
	self.target_lang = target_lang
	self.target_text = translations[target_lang]
	self.notes = notes
	self.needs_revision = needs_revision
	_grab_focus = start_focused
	data_index = p_data_index
	_entry_data["index"] = p_data_index
	_index_line_edit.text = str(p_data_index)
	_entry_data["translations"] = translations
	name = key
	_previous_key = key
	_needs_revision_cb.button_pressed = needs_revision
	_translate_button.visible = has_google
	_on_needs_revision_toggled(_needs_revision_cb.button_pressed)
	old_config = {"key": key, "notes": notes, "needs_revision": needs_revision}


func set_init_complete() -> void:
	_is_ready_for_emit_signals = true


func prepare_for_reuse() -> void:
	_is_ready_for_emit_signals = false
	_key_is_invalid = false
	_revision_forced_by_key = false
	if is_instance_valid(_target_lang_line_edit):
		_target_lang_line_edit.modulate = _default_translation_color


func get_translation_data() -> Dictionary:
	var output: Dictionary = {
		"ref_text": ref_text, "target_text": target_text, "key": key, "old_key": _previous_key
	}
	_previous_key = key
	return output


func get_config_data() -> Dictionary:
	new_config = {"key": key, "notes": notes, "needs_revision": needs_revision}
	var config_changed: bool = new_config != old_config
	var output_config := new_config.duplicate(true)
	output_config["updated"] = config_changed
	output_config["old_key"] = old_config["key"]
	old_config = new_config.duplicate(true)
	return output_config


func update_reference_language(new_lang: String) -> void:
	ref_lang = new_lang
	ref_text = _entry_data["translations"][new_lang]


func update_target_language(new_lang: String) -> void:
	target_lang = new_lang
	target_text = _entry_data["translations"][new_lang]


func remove(quiet := false) -> void:
	_is_ready_for_emit_signals = false
	if not quiet:
		removed.emit(key)
	if get_parent():
		get_parent().remove_child(self)
	queue_free()


func filter(search_text: String, filters: Dictionary) -> void:
	var hide_translated: bool = filters["need_translation"]
	var hide_no_need_rev: bool = filters["need_revision"]
	var search_key: bool = filters.get("search_key", true)
	var search_ref_text: bool = filters.get("search_ref_text", true)
	var search_target_text: bool = filters.get("search_target_text", true)

	self.visible = true

	if hide_translated and has_translation() or hide_no_need_rev and not needs_revision:
		self.visible = false
		return

	if not search_text.is_empty():
		var key_match: bool = search_key and search_text in key.to_lower()
		var ref_match: bool = search_ref_text and search_text in ref_text.to_lower()
		var target_match: bool = search_target_text and search_text in target_text.to_lower()
		self.visible = key_match or ref_match or target_match


func set_key_status(is_empty: bool, duplicate_count: int) -> void:
	_key_is_invalid = is_empty or duplicate_count > 1
	if is_empty:
		_key_label.add_theme_color_override("font_color", _empty_translation_color)
		_key_label.tooltip_text = "Empty key"
	elif duplicate_count > 1:
		_key_label.add_theme_color_override("font_color", _empty_translation_color)
		_key_label.tooltip_text = "Duplicate key: %d entries share this key" % duplicate_count
	else:
		_key_label.remove_theme_color_override("font_color")
		_key_label.tooltip_text = "Translation Key"

	if _key_is_invalid and not needs_revision:
		_needs_revision_cb.button_pressed = true
		_revision_forced_by_key = true
	elif not _key_is_invalid and _revision_forced_by_key:
		_revision_forced_by_key = false
		_needs_revision_cb.button_pressed = false


# Called by translation_list to update position metadata without emitting signals.
func set_position_metadata(new_data_idx: int, new_filter_idx: int, total: int) -> void:
	data_index = new_data_idx
	filter_index = new_filter_idx
	filter_total = total
	_entry_data["index"] = new_data_idx
	_index_line_edit.text = str(new_data_idx)
	_update_arrows()


# Called by translation_list after a reorder - updates metadata and notifies dock.
func update_display_index(new_data_idx: int, new_filter_idx: int, total: int) -> void:
	data_index = new_data_idx
	filter_index = new_filter_idx
	filter_total = total
	_entry_data["index"] = new_data_idx
	_index_line_edit.text = str(new_data_idx)
	_update_arrows()
	_emit_data_changed()


func _translation_callback(new_target_text: String) -> void:
	_entry_data["translations"][target_lang] = new_target_text
	if target_text != new_target_text:
		_emit_data_changed()
	target_text = new_target_text
	if _target_lang_line_edit.has_focus():
		_target_lang_line_edit.caret_column = _target_lang_line_edit.text.length()
	_on_translation_text_changed(new_target_text)


func _on_needs_revision_toggled(button_pressed: bool) -> void:
	if not button_pressed and _key_is_invalid:
		_needs_revision_cb.button_pressed = true
		return
	needs_revision = button_pressed
	_emit_data_changed()


func _on_translation_text_changed(new_text: String) -> void:
	if new_text.is_empty():
		_target_lang_line_edit.modulate = _empty_translation_color
	else:
		_target_lang_line_edit.modulate = _default_translation_color

	if _entry_data.has("translations"):
		_entry_data["translations"][target_lang] = new_text
	if target_text != new_text:
		_emit_data_changed()
	target_text = new_text


func _on_translate_button_pressed() -> void:
	target_text = "Translating: [%s] please wait..." % [ref_text]
	_target_lang_line_edit.text = target_text
	translation_requested.emit(ref_lang, ref_text, target_lang, _translation_callback)


func _on_entry_updated(key, ref_text, target_text, notes) -> void:
	if self.ref_text != ref_text or self.target_text != target_text:
		_emit_data_changed()
	self.key = key
	self.ref_text = ref_text
	self.target_text = target_text
	_target_lang_line_edit.text = target_text
	_target_lang_line_edit.caret_column = _target_lang_line_edit.text.length()
	self.notes = notes


func _on_edit_button_pressed() -> void:
	_edit_translation_popup.request_edit(key, ref_lang, target_lang, ref_text, target_text, notes)


func _on_index_text_submitted(_line_edit: LineEdit, new_text: String) -> void:
	if new_text.is_empty():
		_index_line_edit.text = str(data_index)
		return
	var target: int = int(new_text)
	if target == data_index:
		return
	jump_requested.emit(target)


func _on_change_index_pressed(is_up: bool) -> void:
	reorder_requested.emit(-1 if is_up else 1)


func _update_arrows() -> void:
	_dec_index_button.disabled = filter_index == 0
	_inc_index_button.disabled = filter_total == 0 or filter_index >= filter_total - 1


func _on_delete_confirmed(remember_choice: bool) -> void:
	_config_manager.set_settings_value("main", "no_confirm_delete", remember_choice)
	remove()


func _on_delete_button_pressed():
	if not _config_manager.get_settings_value("main", "no_confirm_delete", false):
		_delete_popup.popup_centered()
	else:
		remove()
