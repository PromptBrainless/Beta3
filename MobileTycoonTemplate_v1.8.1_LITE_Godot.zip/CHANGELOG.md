# v1.8.1 LITE

- Added an **UPGRADE TO PRO • $29** button to the LITE main menu.
- The button opens the live PRO Gumroad product page.
- Added PRO upgrade information to README and product manifest.
- No gameplay/economy changes from v1.8 Final.

# Changelog

## v1.8 Final
- Promoted the runtime-tested v1.7 Release Candidate to the first final buyer package.
- No gameplay-system changes from v1.7 RC; release metadata/documentation only.
- Finalized package manifests and seller-facing version labels.
- Recorded Android Godot Editor 4.7.2 runtime verification for menu, reset confirmation and Clean View flow.


## v1.7 RC
- Added reset-save confirmation to prevent accidental progress loss.
- Added persistent Clean View mode for marketing screenshots and uncluttered demo capture.
- Expanded buyer config validation for arrays, costs, timing and camera settings.
- Added project version metadata and `PRODUCT_MANIFEST.json`.
- Added config reference, QA checklist and dependency disclosure.
- Preserved v1.6 gameplay/save compatibility while focusing on release polish.


## v1.6
- Fixed stale v1.5 worker-cap references after the config refactor.
- Added startup validation for common `template_config.gd` mistakes.
- Centralized player speed, collection timing, worker timing and camera feel.
- Added architecture and troubleshooting documentation.
- Kept the gameplay save path stable for demo migration.
- Added preference migration from v1.4/v1.5 settings files.
- Polished buyer-facing menu footer and package documentation.


## v1.5
- Centralized buyer-facing economy values in `scripts/template_config.gd`.
- Added configurable product title, tagline, feature strip and accent color.
- Added buyer checklist and branding documentation.
- Updated front menu to present edition features more clearly.
- Preserved v1.4 gameplay systems and mobile controls.


## 1.4
- Added product-quality start menu with Play / How to Play / Settings / Reset Demo.
- Added first-run 3-step mobile onboarding.
- Added in-game MENU button; removed always-visible Demo Reset button from gameplay.
- Added persistent guidance toggle (NEXT marker + contextual hint).
- Added persistent camera rotation speed setting.
- Added separate preference save file without touching game progression.
- Updated Lite/Pro menu branding while preserving the same shared codebase.


## v1.3
- Added real config-driven Lite / Pro editions.
- Lite now runs one centered zone with manual collection, direct raw cash-out, bag upgrades and its own save namespace.
- Pro keeps 3 zones, workers, processing and advanced upgrades.
- Added edition-aware UI/goals and removed unavailable Lite interactions.
- Added feature matrix and tailored quick-start docs.

## v1.2
- Added mobile UPGRADES shop with three upgrade paths.
- Bag capacity now has a safe maximum level.
- Processor bonus can be upgraded from +20% to +50%.
- Worker movement speed can be upgraded from 100% to 150%.
- Worker speed upgrades affect all existing workers immediately.
- Added save version 4 and defensive save migration/clamping.
- Old saves remain compatible; invalid worker/storage data in locked zones is repaired.
- Fixed duplicate hero cap child attachment from v1.1.
- Added Lite/Pro edition configuration foundation.
- Processor world label now reflects the live processing bonus.

## v1.1
- Worker cap: 3 per zone.
- Progressive worker pricing.
- Parallel worker lanes.

## v1.0
- NEXT world marker and guided demo progression.
