# 3D Mobile Tycoon Template LITE v1.8.1 Final

Mobile-first Godot 4 tycoon starter project designed for Android touch testing and fast customization.

## Start here
1. Import this ZIP directly in Godot 4.7.x.
2. Run `main.tscn`.
3. Open `scripts/template_config.gd` to customize branding, economy, progression and game feel.
4. Read `docs/QUICK_START.md` and `docs/CUSTOMIZATION.md`.

## LITE edition
- 1 centered playable zone
- Manual collection and direct cash-out
- Bag upgrades
- Guided NEXT objectives and onboarding
- Save/load
- Config validation in the Godot debugger

The Pro edition adds zones, workers, processing and advanced upgrades.

## No third-party art dependency
The demo scene is made from Godot primitives. Replace it with your own licensed art when shipping a game.

## Final-release status
- Reset-save confirmation
- Clean View screenshot mode (Settings → Clean view)
- Product manifest + expanded config validation
- Runtime-tested release-candidate flow on Android Godot Editor 4.7.2
- QA/config/dependency documentation

## Upgrade to PRO

This free LITE edition is intentionally limited to the core one-zone loop.

The PRO edition adds:
- 3 zones
- Worker automation
- Processing
- Advanced upgrades
- Extended progression

PRO: https://shklyar4.gumroad.com/l/godot-mobile-tycoon-template
