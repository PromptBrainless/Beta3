# Android export notes

The demo is configured for landscape mobile play and the GL Compatibility renderer.

Before publishing your own game:
1. Install/configure the Android export requirements for your Godot version.
2. Create your own Android export preset.
3. Set your own package/application ID.
4. Use your own signing key for release builds.
5. Replace template branding, icon and demo art.
6. Test touch input, save/load and both landscape orientations on a physical device.

Signing keys and store credentials are intentionally not included in this template.
