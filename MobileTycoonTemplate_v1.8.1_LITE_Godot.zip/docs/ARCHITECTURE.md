# Architecture map

| File | Responsibility |
|---|---|
| `template_config.gd` | Buyer-facing product, economy, progression and feel settings |
| `main.gd` | Demo world construction, UI, onboarding and orchestration |
| `game_manager.gd` | Economy state, upgrades, zones, workers, save/load |
| `player.gd` | Tap-target movement and keyboard fallback |
| `camera_controller.gd` | Follow camera, drag rotation and zoom |
| `worker.gd` | Automated source → storage loop |
| `resource_pile.gd` | Manual resource collection |
| `processor_pad.gd` | Raw → processed conversion trigger |
| `sell_pad.gd` | Cash-out trigger |
| `worker_hire_pad.gd` | Worker purchase trigger |
| `zone_unlock_pad.gd` | Zone unlock trigger |
| `upgrade_pad.gd` | World bag-upgrade trigger |

The demo intentionally keeps the world generated in code so the package has no external art dependency. Buyers can replace that layer while retaining the gameplay systems.
