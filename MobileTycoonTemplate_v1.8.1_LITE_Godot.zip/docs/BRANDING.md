# Branding

Buyer-facing menu branding starts in `scripts/template_config.gd`:
- `PRODUCT_NAME`
- `MENU_TAGLINE`
- `MENU_FEATURES`
- `ACCENT_COLOR_HEX`

The demo art is built from Godot primitives, so it can be safely replaced piece by piece with your own licensed models, textures and UI assets.
