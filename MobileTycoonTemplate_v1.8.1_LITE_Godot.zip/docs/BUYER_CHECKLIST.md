# Buyer Checklist — LITE

1. Run the template once before editing it.
2. Open `scripts/template_config.gd`.
3. Change `PRODUCT_NAME`, menu copy and economy values.
4. Replace the demo low-poly visuals with your own licensed art.
5. Rebalance zone values, unlock costs and worker costs.
6. Test a brand-new save and an upgraded save.
7. Change the package/application identity before publishing your game.
8. Export to Android and test on a physical phone.

The template is intentionally data-first: common economy tuning is centralized in one file.
