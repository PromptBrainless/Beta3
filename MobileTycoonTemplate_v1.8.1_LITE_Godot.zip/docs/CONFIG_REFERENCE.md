# Configuration reference — v1.7

Edit `scripts/template_config.gd` first.

## Branding
- `PRODUCT_NAME` — menu title
- `MENU_TAGLINE` — edition subtitle
- `MENU_FEATURES` — feature strip
- `ACCENT_COLOR_HEX` — UI accent color

## Edition switches
- `ACTIVE_ZONE_COUNT`
- `ENABLE_PROCESSING`
- `ENABLE_ADVANCED_UPGRADES`
- `ENABLE_MULTI_ZONE_AUTOMATION`

## Economy
- `STARTING_COINS`
- `ZONE_VALUES`
- `ZONE_UNLOCK_COSTS`
- `WORKER_BASE_COSTS`
- `MAX_WORKERS_PER_ZONE`

## Progression
Bag, processor and worker-speed base costs, cost steps and maximum levels are grouped in their own sections.

## Feel / timing
Player speed/acceleration, collection timing, worker timing and camera distance/pitch are centralized here.

At startup the template validates common configuration errors and reports them in Godot's debugger.
