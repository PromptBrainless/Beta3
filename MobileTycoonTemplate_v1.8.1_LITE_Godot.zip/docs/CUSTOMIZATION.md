# Customization Guide — v1.7

## 1. Edit one config file first
Open `scripts/template_config.gd`. Buyer-facing tuning is centralized there.

### Branding
- `PRODUCT_NAME`
- `MENU_TAGLINE`
- `MENU_FEATURES`
- `ACCENT_COLOR_HEX`

### Economy / progression
- `ZONE_VALUES`
- `ZONE_UNLOCK_COSTS`
- `WORKER_BASE_COSTS`
- `MAX_WORKERS_PER_ZONE`
- bag, processor and worker-speed upgrade curves

### Game feel
- `PLAYER_MOVE_SPEED`
- `PLAYER_ACCELERATION`
- `RESOURCE_COLLECT_INTERVAL`
- worker movement / gather / deposit timing
- Lite and Pro camera distance / pitch

## 2. Config validation
The project checks common configuration mistakes at startup. Look in Godot's debugger for messages beginning with `[TycoonTemplateConfig]`. Invalid values are reported clearly rather than being silently ignored.

## 3. Visual layout
Demo world construction is in `scripts/main.gd`. Search for `zone_source_positions`, `zone_storage_positions`, `zone_colors`, `_build_environment()` and `_build_zone()`.

## 4. Behavior scripts
- Player movement: `scripts/player.gd`
- Worker loop: `scripts/worker.gd`
- Camera follow/rotation: `scripts/camera_controller.gd`
- Economy + save/load: `scripts/game_manager.gd`
- Resource / sell / process / unlock pads: dedicated scripts in `scripts/`

## 5. Save data
The save file path remains stable so template updates can migrate existing demo progress. When you turn this into your own game, change the application identity and choose your own save schema before release.
