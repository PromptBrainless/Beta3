# Dependencies / third-party content

This package has no third-party runtime plugin dependency and no third-party art dependency.

The demo world is generated from Godot built-in primitives and project code. Buyers should use their own appropriately licensed art, audio, fonts and store branding when turning the template into a shipped game.
