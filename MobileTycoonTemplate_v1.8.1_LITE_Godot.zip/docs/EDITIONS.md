# Lite / Pro editions

Both packages use the same codebase and `scripts/template_config.gd`.

## Lite
- 1 centered zone
- Manual collection
- Direct raw cash-out
- Bag upgrades
- Save/load
- Touch movement + camera
- No worker automation
- No processor
- No advanced upgrades

## Pro
- 3 zones
- Worker teams (up to 3 per zone)
- Raw storage
- Processing chain with upgradeable bonus
- Worker speed upgrades
- Guided NEXT objective system
- Full upgrade shop

To maintain your own editions, edit only the constants in `scripts/template_config.gd`.
