# Feature Matrix

| Feature | Lite | Pro |
|---|---:|---:|
| Android touch movement | Yes | Yes |
| Rotating camera | Yes | Yes |
| Save/load | Yes | Yes |
| Manual resource collection | Yes | Yes |
| Bag upgrades | Yes | Yes |
| Zones | 1 | 3 |
| Worker automation | No | Yes |
| Processor + value bonus | No | Yes |
| Processor upgrades | No | Yes |
| Worker speed upgrades | No | Yes |
| Guided NEXT system | Yes | Yes |
