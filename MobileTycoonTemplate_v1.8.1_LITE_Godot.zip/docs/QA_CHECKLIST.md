# QA checklist — LITE v1.7 RC

Before shipping a customized game:
- [ ] Project imports without errors.
- [ ] Main menu, How To Play and Settings open correctly.
- [ ] Reset Demo requires confirmation.
- [ ] Clean View hides HUD and SHOW UI restores it.
- [ ] Tap-to-move works on a physical phone.
- [ ] Drag-to-rotate works without accidental movement.
- [ ] Save/load persists after closing and reopening.
- [ ] Bag upgrades stop at MAX.
- [ ] Only one zone is shown.
- [ ] Raw stock sells directly without processor/worker UI.
- [ ] Both landscape orientations are tested on device.
- [ ] Android export uses the seller's own package ID and signing key.
