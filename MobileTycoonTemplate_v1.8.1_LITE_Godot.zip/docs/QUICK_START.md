# LITE Quick Start — v1.7

1. Import the ZIP in Godot 4.7.x.
2. Run `main.tscn`.
3. Tap the ground to move and drag to rotate the camera.
4. Follow the yellow NEXT marker through the demo loop.
5. Open `scripts/template_config.gd` before editing gameplay scripts.
6. Change one group of values at a time and run the project after each change.
7. Watch the Godot debugger: v1.7 validates common config mistakes at startup.
