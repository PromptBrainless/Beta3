# v1.8 Final release notes

This is the first final buyer-facing package. Gameplay code is unchanged from v1.7 RC. The RC was run on Android in Godot Editor 4.7.2 and the menu, reset confirmation, settings/Clean View and core demo loop were verified during device testing.

Before publishing your own game, replace demo branding/art, rebalance the economy, review the license terms and run your own export/device QA.
