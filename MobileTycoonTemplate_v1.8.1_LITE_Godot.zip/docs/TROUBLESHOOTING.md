# Troubleshooting

## ZIP does not import
`project.godot` must be at the root of the ZIP. The distributed package already follows this layout.

## Godot reports a config error
Read the debugger message beginning with `[TycoonTemplateConfig]`, then fix the named value in `scripts/template_config.gd`.

## Old demo progress appears
Use `RESET DEMO SAVE` from the template menu. Preferences such as guidance/camera speed are stored separately from gameplay progress.

## Android editor feels cramped
Run the embedded game in landscape/full-screen when possible. The project is designed around a 1280×720 landscape viewport with canvas-item stretching.

## A feature is missing in Lite
That is intentional. Lite uses the same core codebase but disables worker automation, processing, advanced upgrades and extra zones through `template_config.gd`.

## After changing edition flags, the scene looks wrong
Keep `ACTIVE_ZONE_COUNT` within the size of `ZONE_VALUES`, `ZONE_UNLOCK_COSTS` and `WORKER_BASE_COSTS`. v1.7 reports mismatched arrays in the debugger.
