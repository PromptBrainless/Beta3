extends Node3D
class_name TycoonCameraController

@export var target: Node3D
@export var distance: float = 10.5
@export var pitch_degrees: float = -52.0
@export var rotate_sensitivity: float = 0.22
@export var follow_speed: float = 10.0

var yaw_degrees: float = 45.0
var _camera: Camera3D

func _ready() -> void:
    _camera = Camera3D.new()
    _camera.name = "Camera3D"
    add_child(_camera)
    _camera.current = true
    _update_camera_transform()

func _process(delta: float) -> void:
    if target:
        global_position = global_position.lerp(target.global_position, minf(1.0, follow_speed * delta))
    _update_camera_transform()

func rotate_by(screen_delta_x: float) -> void:
    yaw_degrees -= screen_delta_x * rotate_sensitivity

func zoom_by(amount: float) -> void:
    distance = clampf(distance + amount, 6.0, 16.0)

func get_camera() -> Camera3D:
    return _camera

func _update_camera_transform() -> void:
    if not _camera:
        return
    var yaw: float = deg_to_rad(yaw_degrees)
    var pitch: float = deg_to_rad(pitch_degrees)
    var offset: Vector3 = Vector3(
        sin(yaw) * cos(pitch),
        -sin(pitch),
        cos(yaw) * cos(pitch)
    ) * distance
    _camera.position = offset
    _camera.look_at(global_position + Vector3(0.0, 0.7, 0.0), Vector3.UP)
