extends Node
class_name GameManager

signal coins_changed(value: int)
signal inventory_changed(current: int, capacity: int, carried_value: int)
signal storage_changed(zone_index: int, amount: int, stored_value: int)
signal processed_changed(value: int)
signal zone_changed(zone_index: int, unlocked: bool)
signal worker_changed(zone_index: int, count: int)
signal upgrades_changed(process_bonus_percent: int, worker_speed_percent: int)
signal message_requested(text: String)

const SAVE_PATH: String = "user://tycoon_save_v02.json"

var coins: int = TycoonTemplateConfig.STARTING_COINS
var inventory: int = 0
var inventory_value: int = 0
var processed_value: int = 0
var capacity: int = TycoonTemplateConfig.BASE_BAG_CAPACITY
var capacity_upgrade_level: int = 0
var processor_upgrade_level: int = 0
var worker_speed_level: int = 0
var zone_unlocked: Array[bool] = [true, false, false]
var zone_storage: Array[int] = [0, 0, 0]
var workers_owned: Array[int] = [0, 0, 0]

func _ready() -> void:
    load_game()
    _emit_all()

func zone_count() -> int:
    return mini(TycoonTemplateConfig.ZONE_VALUES.size(), TycoonTemplateConfig.ACTIVE_ZONE_COUNT)

func processing_enabled() -> bool:
    return TycoonTemplateConfig.ENABLE_PROCESSING

func advanced_upgrades_enabled() -> bool:
    return TycoonTemplateConfig.ENABLE_ADVANCED_UPGRADES

func automation_enabled() -> bool:
    return TycoonTemplateConfig.ENABLE_MULTI_ZONE_AUTOMATION

func get_zone_value(zone_index: int) -> int:
    if not _valid_zone(zone_index):
        return 0
    return TycoonTemplateConfig.ZONE_VALUES[zone_index]

func get_zone_unlock_cost(zone_index: int) -> int:
    if not _valid_zone(zone_index):
        return 999999
    return TycoonTemplateConfig.ZONE_UNLOCK_COSTS[zone_index]

func get_worker_cost(zone_index: int) -> int:
    if not automation_enabled() or not _valid_zone(zone_index):
        return 999999
    var owned: int = clampi(workers_owned[zone_index], 0, TycoonTemplateConfig.MAX_WORKERS_PER_ZONE)
    return TycoonTemplateConfig.WORKER_BASE_COSTS[zone_index] * (owned + 1)

func worker_team_full(zone_index: int) -> bool:
    if not automation_enabled() or not _valid_zone(zone_index):
        return true
    return workers_owned[zone_index] >= TycoonTemplateConfig.MAX_WORKERS_PER_ZONE

func is_zone_unlocked(zone_index: int) -> bool:
    return _valid_zone(zone_index) and zone_unlocked[zone_index]

func add_resource_from_zone(zone_index: int, amount: int = 1) -> int:
    if not is_zone_unlocked(zone_index):
        message_requested.emit("Zone %d is locked" % (zone_index + 1))
        return 0
    var accepted: int = mini(amount, capacity - inventory)
    if accepted <= 0:
        return 0
    inventory += accepted
    inventory_value += accepted * get_zone_value(zone_index)
    inventory_changed.emit(inventory, capacity, inventory_value)
    return accepted

func add_worker_delivery(zone_index: int, amount: int = 1) -> void:
    if not is_zone_unlocked(zone_index) or amount <= 0:
        return
    zone_storage[zone_index] += amount
    storage_changed.emit(zone_index, zone_storage[zone_index], zone_storage[zone_index] * get_zone_value(zone_index))
    save_game()

func raw_value_ready() -> int:
    var total: int = inventory_value
    for i in range(zone_count()):
        total += zone_storage[i] * get_zone_value(i)
    return total

func process_all_raw() -> int:
    if not processing_enabled():
        message_requested.emit("Processing is available in Pro")
        return 0
    var raw_value: int = raw_value_ready()
    if raw_value <= 0:
        message_requested.emit("No raw stock to process")
        return 0

    inventory = 0
    inventory_value = 0
    inventory_changed.emit(inventory, capacity, inventory_value)

    for i in range(zone_storage.size()):
        zone_storage[i] = 0
        storage_changed.emit(i, 0, 0)

    var bonus_percent: int = get_process_bonus_percent()
    var bonus_value: int = int((float(raw_value) * float(bonus_percent)) / 100.0)
    var output_value: int = raw_value + bonus_value
    processed_value += output_value
    processed_changed.emit(processed_value)
    message_requested.emit("Processed $%d raw → $%d (+%d%%)" % [raw_value, output_value, bonus_percent])
    save_game()
    return output_value

func cash_out_all() -> int:
    var earned: int = 0
    if processing_enabled():
        earned = processed_value
        if earned <= 0:
            return 0
        processed_value = 0
        processed_changed.emit(processed_value)
    else:
        earned = raw_value_ready()
        if earned <= 0:
            return 0
        inventory = 0
        inventory_value = 0
        inventory_changed.emit(inventory, capacity, inventory_value)
        for i in range(zone_count()):
            zone_storage[i] = 0
            storage_changed.emit(i, 0, 0)
    coins += earned
    coins_changed.emit(coins)
    save_game()
    return earned

func capacity_upgrade_maxed() -> bool:
    return capacity_upgrade_level >= TycoonTemplateConfig.MAX_BAG_UPGRADE_LEVEL

func capacity_upgrade_cost() -> int:
    if capacity_upgrade_maxed():
        return 0
    return TycoonTemplateConfig.BAG_UPGRADE_BASE_COST + capacity_upgrade_level * TycoonTemplateConfig.BAG_UPGRADE_COST_STEP

func get_process_bonus_percent() -> int:
    return TycoonTemplateConfig.BASE_PROCESS_BONUS_PERCENT + processor_upgrade_level * TycoonTemplateConfig.PROCESS_BONUS_PER_LEVEL

func processor_upgrade_maxed() -> bool:
    return processor_upgrade_level >= TycoonTemplateConfig.MAX_PROCESSOR_UPGRADE_LEVEL

func processor_upgrade_cost() -> int:
    if processor_upgrade_maxed():
        return 0
    return TycoonTemplateConfig.PROCESSOR_UPGRADE_BASE_COST + processor_upgrade_level * TycoonTemplateConfig.PROCESSOR_UPGRADE_COST_STEP

func get_worker_speed_percent() -> int:
    return TycoonTemplateConfig.BASE_WORKER_SPEED_PERCENT + worker_speed_level * TycoonTemplateConfig.WORKER_SPEED_PER_LEVEL

func get_worker_speed_multiplier() -> float:
    return float(get_worker_speed_percent()) / 100.0

func worker_speed_upgrade_maxed() -> bool:
    return worker_speed_level >= TycoonTemplateConfig.MAX_WORKER_SPEED_LEVEL

func worker_speed_upgrade_cost() -> int:
    if worker_speed_upgrade_maxed():
        return 0
    return TycoonTemplateConfig.WORKER_SPEED_UPGRADE_BASE_COST + worker_speed_level * TycoonTemplateConfig.WORKER_SPEED_UPGRADE_COST_STEP

func buy_capacity_upgrade() -> bool:
    if capacity_upgrade_maxed():
        message_requested.emit("Bag capacity is MAX")
        return false
    var cost: int = capacity_upgrade_cost()
    if not _spend(cost):
        message_requested.emit("Need $%d" % cost)
        return false
    capacity_upgrade_level += 1
    capacity = TycoonTemplateConfig.BASE_BAG_CAPACITY + capacity_upgrade_level * TycoonTemplateConfig.BAG_CAPACITY_PER_LEVEL
    inventory_changed.emit(inventory, capacity, inventory_value)
    upgrades_changed.emit(get_process_bonus_percent(), get_worker_speed_percent())
    message_requested.emit("Bag capacity upgraded to %d" % capacity)
    save_game()
    return true

func buy_processor_upgrade() -> bool:
    if not advanced_upgrades_enabled() or not processing_enabled():
        message_requested.emit("Processor upgrades are available in Pro")
        return false
    if processor_upgrade_maxed():
        message_requested.emit("Processor bonus is MAX")
        return false
    var cost: int = processor_upgrade_cost()
    if not _spend(cost):
        message_requested.emit("Need $%d for processor upgrade" % cost)
        return false
    processor_upgrade_level += 1
    upgrades_changed.emit(get_process_bonus_percent(), get_worker_speed_percent())
    message_requested.emit("Processor bonus upgraded to +%d%%" % get_process_bonus_percent())
    save_game()
    return true

func buy_worker_speed_upgrade() -> bool:
    if not advanced_upgrades_enabled() or not automation_enabled():
        message_requested.emit("Worker upgrades are available in Pro")
        return false
    if worker_speed_upgrade_maxed():
        message_requested.emit("Worker speed is MAX")
        return false
    var cost: int = worker_speed_upgrade_cost()
    if not _spend(cost):
        message_requested.emit("Need $%d for worker speed" % cost)
        return false
    worker_speed_level += 1
    upgrades_changed.emit(get_process_bonus_percent(), get_worker_speed_percent())
    message_requested.emit("Worker speed upgraded to %d%%" % get_worker_speed_percent())
    save_game()
    return true

func unlock_zone(zone_index: int) -> bool:
    if not _valid_zone(zone_index):
        return false
    if zone_unlocked[zone_index]:
        message_requested.emit("Zone %d already unlocked" % (zone_index + 1))
        return false
    if zone_index > 0 and not zone_unlocked[zone_index - 1]:
        message_requested.emit("Unlock Zone %d first" % zone_index)
        return false
    var cost: int = get_zone_unlock_cost(zone_index)
    if not _spend(cost):
        message_requested.emit("Need $%d for Zone %d" % [cost, zone_index + 1])
        return false
    zone_unlocked[zone_index] = true
    zone_changed.emit(zone_index, true)
    message_requested.emit("Zone %d unlocked" % (zone_index + 1))
    save_game()
    return true

func hire_worker(zone_index: int) -> bool:
    if not automation_enabled():
        message_requested.emit("Worker automation is available in Pro")
        return false
    if not is_zone_unlocked(zone_index):
        message_requested.emit("Unlock Zone %d first" % (zone_index + 1))
        return false
    if worker_team_full(zone_index):
        message_requested.emit("Zone %d team full (%d/%d)" % [zone_index + 1, TycoonTemplateConfig.MAX_WORKERS_PER_ZONE, TycoonTemplateConfig.MAX_WORKERS_PER_ZONE])
        return false
    var cost: int = get_worker_cost(zone_index)
    if not _spend(cost):
        message_requested.emit("Need $%d for worker" % cost)
        return false
    workers_owned[zone_index] += 1
    worker_changed.emit(zone_index, workers_owned[zone_index])
    message_requested.emit("Worker hired for Zone %d" % (zone_index + 1))
    save_game()
    return true

func reset_save() -> void:
    coins = TycoonTemplateConfig.STARTING_COINS
    inventory = 0
    inventory_value = 0
    processed_value = 0
    capacity = TycoonTemplateConfig.BASE_BAG_CAPACITY
    capacity_upgrade_level = 0
    processor_upgrade_level = 0
    worker_speed_level = 0
    zone_unlocked = [true, false, false]
    zone_storage = [0, 0, 0]
    workers_owned = [0, 0, 0]
    if FileAccess.file_exists(SAVE_PATH):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
    _emit_all()

func save_game() -> void:
    var data: Dictionary = {
        "coins": coins,
        "inventory": inventory,
        "inventory_value": inventory_value,
        "processed_value": processed_value,
        "save_version": TycoonTemplateConfig.SAVE_VERSION,
        "edition": TycoonTemplateConfig.EDITION,
        "capacity": capacity,
        "capacity_upgrade_level": capacity_upgrade_level,
        "processor_upgrade_level": processor_upgrade_level,
        "worker_speed_level": worker_speed_level,
        "zone_unlocked": zone_unlocked,
        "zone_storage": zone_storage,
        "workers_owned": workers_owned
    }
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not file:
        return
    var parsed_value: Variant = JSON.parse_string(file.get_as_text())
    if parsed_value is not Dictionary:
        return
    var parsed: Dictionary = parsed_value as Dictionary

    coins = maxi(0, int(parsed.get("coins", 0)))
    capacity_upgrade_level = clampi(int(parsed.get("capacity_upgrade_level", 0)), 0, TycoonTemplateConfig.MAX_BAG_UPGRADE_LEVEL)
    processor_upgrade_level = clampi(int(parsed.get("processor_upgrade_level", 0)), 0, TycoonTemplateConfig.MAX_PROCESSOR_UPGRADE_LEVEL)
    worker_speed_level = clampi(int(parsed.get("worker_speed_level", 0)), 0, TycoonTemplateConfig.MAX_WORKER_SPEED_LEVEL)
    capacity = TycoonTemplateConfig.BASE_BAG_CAPACITY + capacity_upgrade_level * TycoonTemplateConfig.BAG_CAPACITY_PER_LEVEL
    inventory = clampi(int(parsed.get("inventory", 0)), 0, capacity)
    inventory_value = maxi(0, int(parsed.get("inventory_value", inventory * TycoonTemplateConfig.ZONE_VALUES[0])))
    processed_value = maxi(0, int(parsed.get("processed_value", 0)))
    zone_unlocked = _load_bool_array(parsed.get("zone_unlocked", [true, false, false]), [true, false, false])
    zone_storage = _load_int_array(parsed.get("zone_storage", [0, 0, 0]), [0, 0, 0])
    workers_owned = _load_int_array(parsed.get("workers_owned", [0, 0, 0]), [0, 0, 0])
    if zone_unlocked[2]:
        zone_unlocked[1] = true
    for i in range(zone_unlocked.size()):
        if i >= zone_count():
            zone_unlocked[i] = false
            zone_storage[i] = 0
            workers_owned[i] = 0
    if not automation_enabled():
        for i in range(workers_owned.size()):
            workers_owned[i] = 0
            zone_storage[i] = 0
    for i in range(workers_owned.size()):
        workers_owned[i] = clampi(workers_owned[i], 0, TycoonTemplateConfig.MAX_WORKERS_PER_ZONE)
        if not zone_unlocked[i]:
            workers_owned[i] = 0
            zone_storage[i] = 0

func _spend(cost: int) -> bool:
    if coins < cost:
        return false
    coins -= cost
    coins_changed.emit(coins)
    return true

func _emit_all() -> void:
    coins_changed.emit(coins)
    inventory_changed.emit(inventory, capacity, inventory_value)
    processed_changed.emit(processed_value)
    upgrades_changed.emit(get_process_bonus_percent(), get_worker_speed_percent())
    for i in range(zone_count()):
        zone_changed.emit(i, zone_unlocked[i])
        storage_changed.emit(i, zone_storage[i], zone_storage[i] * get_zone_value(i))
        worker_changed.emit(i, workers_owned[i])

func _valid_zone(zone_index: int) -> bool:
    return zone_index >= 0 and zone_index < zone_count()

func _load_bool_array(value: Variant, fallback: Array[bool]) -> Array[bool]:
    var result: Array[bool] = fallback.duplicate()
    if value is Array:
        for i in range(mini(value.size(), result.size())):
            result[i] = bool(value[i])
    result[0] = true
    return result

func _load_int_array(value: Variant, fallback: Array[int]) -> Array[int]:
    var result: Array[int] = fallback.duplicate()
    if value is Array:
        for i in range(mini(value.size(), result.size())):
            result[i] = maxi(0, int(value[i]))
    return result
