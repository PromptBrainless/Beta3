extends Node3D

var manager: GameManager
var player: TycoonPlayer
var camera_controller: TycoonCameraController

var coins_label: Label
var inventory_label: Label
var processed_label: Label
var hint_label: Label
var toast_label: Label
var upgrade_label: Label
var goal_label: Label
var goal_detail_label: Label
var goal_progress: ProgressBar
var context_label: Label
var last_context_text: String = ""
var zone_status_labels: Array[Label] = []
var zone_storage_world_labels: Array[Label3D] = []
var zone_lock_nodes: Array[Node3D] = []
var zone_source_visuals: Array[Node3D] = []
var zone_floor_visuals: Array[MeshInstance3D] = []
var zone_storage_roots: Array[Node3D] = []
var hire_world_labels: Array[Label3D] = []
var hire_pads: Array[WorkerHirePad] = []
var workers_by_zone: Dictionary = {}
var processor_rotor: Node3D
var objective_marker: Node3D
var objective_label: Label3D
var processor_world_label: Label3D
var shop_panel: PanelContainer
var shop_toggle_button: Button
var shop_bag_button: Button
var shop_processor_button: Button
var shop_worker_speed_button: Button
var context_panel: PanelContainer
var front_layer: CanvasLayer
var front_root: Control
var front_main_box: VBoxContainer
var front_settings_box: VBoxContainer
var guidance_button: Button
var camera_button: Button
var clean_view_button: Button
var reset_dialog: ConfirmationDialog
var game_ui_root: Control
var clean_view_layer: CanvasLayer
var clean_view_restore_button: Button
var tutorial_layer: CanvasLayer
var tutorial_root: Control
var tutorial_text: Label
var tutorial_action_button: Button
var gameplay_enabled: bool = false
var guidance_enabled: bool = true
var fast_camera: bool = false
var clean_view_enabled: bool = false
var onboarding_seen: bool = false
var onboarding_step: int = 0
const PREFS_PATH: String = "user://tycoon_prefs.json"
const LEGACY_PREFS_PATHS: Array[String] = ["user://tycoon_prefs_v15.json", "user://tycoon_prefs_v14.json"]

var zone_source_positions: Array[Vector3] = [
    Vector3(-8.0, 0.0, -2.8),
    Vector3(0.0, 0.0, -2.8),
    Vector3(8.0, 0.0, -2.8)
]
var zone_storage_positions: Array[Vector3] = [
    Vector3(-8.0, 0.0, 3.0),
    Vector3(0.0, 0.0, 3.0),
    Vector3(8.0, 0.0, 3.0)
]
var zone_colors: Array[Color] = [
    Color("#6798d0"),
    Color("#ce9560"),
    Color("#8e72c7")
]

var touch_start: Vector2 = Vector2.ZERO
var touch_last: Vector2 = Vector2.ZERO
var touch_dragged: bool = false
var active_touch: int = -1
const DRAG_THRESHOLD: float = 18.0

func _ready() -> void:
    _validate_template_config()
    _load_preferences()
    _build_environment()

    manager = GameManager.new()
    manager.name = "GameManager"
    add_child(manager)

    _apply_edition_layout()

    for i in range(manager.zone_count()):
        workers_by_zone[i] = []

    _build_player()
    _build_camera()
    _build_tycoon_world()
    _build_ui()
    _build_frontend_ui()
    _build_tutorial_ui()
    _apply_preferences()

    manager.coins_changed.connect(_on_coins_changed)
    manager.inventory_changed.connect(_on_inventory_changed)
    manager.processed_changed.connect(_on_processed_changed)
    manager.storage_changed.connect(_on_storage_changed)
    manager.zone_changed.connect(_on_zone_changed)
    manager.worker_changed.connect(_on_worker_changed)
    manager.upgrades_changed.connect(_on_upgrades_changed)
    manager.message_requested.connect(_show_message)

    _sync_all_ui_and_world()
    _open_front_menu()

func _process(delta: float) -> void:
    if not gameplay_enabled:
        return
    _refresh_context_hint()
    if processor_rotor and manager and manager.processing_enabled() and manager.raw_value_ready() > 0:
        processor_rotor.rotation.y += delta * 2.4

func _apply_edition_layout() -> void:
    if manager != null and manager.zone_count() == 1:
        zone_source_positions[0] = Vector3(0.0, 0.0, -2.8)
        zone_storage_positions[0] = Vector3(0.0, 0.0, 3.0)

func _validate_template_config() -> void:
    var errors: PackedStringArray = TycoonTemplateConfig.get_validation_errors()
    if errors.is_empty():
        print("[TycoonTemplate] Config OK • %s v%s" % [TycoonTemplateConfig.EDITION, TycoonTemplateConfig.VERSION])
        return
    for i in range(errors.size()):
        var error_text: String = errors[i]
        push_error("[TycoonTemplateConfig] " + error_text)

func _build_environment() -> void:
    var world: WorldEnvironment = WorldEnvironment.new()
    world.environment = Environment.new()
    world.environment.background_mode = Environment.BG_COLOR
    world.environment.background_color = Color("#a8d2e0")
    world.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    world.environment.ambient_light_color = Color("#fff7e8")
    world.environment.ambient_light_energy = 0.62
    add_child(world)

    var sun: DirectionalLight3D = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -32, 0)
    sun.light_energy = 1.08
    sun.shadow_enabled = true
    add_child(sun)

    var ground: StaticBody3D = StaticBody3D.new()
    ground.name = "Ground"
    add_child(ground)

    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    var box: BoxMesh = BoxMesh.new()
    box.size = Vector3(32, 0.2, 22)
    mesh_instance.mesh = box
    mesh_instance.position.y = -0.1
    mesh_instance.material_override = _material(Color("#78945f"), 0.95)
    ground.add_child(mesh_instance)

    var collision: CollisionShape3D = CollisionShape3D.new()
    var shape: BoxShape3D = BoxShape3D.new()
    shape.size = Vector3(32, 0.2, 22)
    collision.shape = shape
    collision.position.y = -0.1
    ground.add_child(collision)

    _add_box(Vector3(0, 0.035, 6.8), Vector3(28, 0.07, 3.5), Color("#9aa4a8"), "ServiceLane")
    _add_box(Vector3(0, 0.075, 6.8), Vector3(18.5, 0.035, 2.35), Color("#4d5961"), "AsphaltStrip")
    _add_box(Vector3(0, 0.098, 6.8), Vector3(0.18, 0.02, 2.1), Color("#f0c85e"), "LaneMarker0")
    var lane_markers: Array[float] = [-7.0, -3.5, 3.5, 7.0]
    for lane_x in lane_markers:
        _add_box(Vector3(lane_x, 0.098, 6.8), Vector3(1.25, 0.02, 0.12), Color("#f0c85e"), "LaneMarker")

    _add_box(Vector3(0.0, 0.11, 5.03), Vector3(27.0, 0.16, 0.16), Color("#d4cbb4"), "RoadCurbNear")
    _add_box(Vector3(0.0, 0.11, 8.57), Vector3(27.0, 0.16, 0.16), Color("#d4cbb4"), "RoadCurbFar")

    _build_shop_building(Vector3(-11.3, 0.0, 6.75), Color("#3d6d7e"), Color("#294d5b"), "CASH")
    _build_shop_building(Vector3(11.3, 0.0, 6.75), Color("#b3734f"), Color("#7e4f37"), "UPGRADE")

    var light_positions: Array[Vector3] = [
        Vector3(-8.0, 0.0, 8.75), Vector3(0.0, 0.0, 8.75), Vector3(8.0, 0.0, 8.75)
    ]
    for light_pos in light_positions:
        _add_yard_light(light_pos)

    var tree_positions: Array[Vector3] = [
        Vector3(-14.0, 0.0, -7.5), Vector3(14.0, 0.0, -7.2),
        Vector3(-14.3, 0.0, 1.4), Vector3(14.2, 0.0, 1.0),
        Vector3(-10.2, 0.0, -8.3), Vector3(10.5, 0.0, -8.4)
    ]
    for tree_pos in tree_positions:
        _add_tree(tree_pos)

func _build_player() -> void:
    player = TycoonPlayer.new()
    player.name = "Player"
    player.position = Vector3(zone_source_positions[0].x, 0.9, 5.2)
    player.collision_layer = 2
    player.collision_mask = 1
    player.move_speed = TycoonTemplateConfig.PLAYER_MOVE_SPEED
    player.acceleration = TycoonTemplateConfig.PLAYER_ACCELERATION
    add_child(player)

    var collision: CollisionShape3D = CollisionShape3D.new()
    var capsule_shape: CapsuleShape3D = CapsuleShape3D.new()
    capsule_shape.radius = 0.42
    capsule_shape.height = 1.55
    collision.shape = capsule_shape
    player.add_child(collision)

    var torso: MeshInstance3D = _make_box_mesh(Vector3(0.78, 0.9, 0.5), Color("#2f72dc"))
    torso.position.y = 0.05
    player.add_child(torso)

    var legs: MeshInstance3D = _make_box_mesh(Vector3(0.58, 0.58, 0.42), Color("#263447"))
    legs.position.y = -0.55
    player.add_child(legs)

    var head: MeshInstance3D = MeshInstance3D.new()
    var sphere: SphereMesh = SphereMesh.new()
    sphere.radius = 0.32
    sphere.height = 0.64
    head.mesh = sphere
    head.position.y = 0.82
    head.material_override = _material(Color("#f0c79e"), 0.72)
    player.add_child(head)

    var cap: MeshInstance3D = _make_cylinder(0.34, 0.12, Color("#174e9f"))
    cap.position.y = 1.08
    player.add_child(cap)

    var backpack: MeshInstance3D = _make_box_mesh(Vector3(0.52, 0.62, 0.28), Color("#f0a236"))
    backpack.position = Vector3(0.0, 0.08, -0.38)
    player.add_child(backpack)

func _build_camera() -> void:
    camera_controller = TycoonCameraController.new()
    camera_controller.name = "CameraRig"
    camera_controller.target = player
    camera_controller.distance = TycoonTemplateConfig.CAMERA_DISTANCE_LITE if manager.zone_count() == 1 else TycoonTemplateConfig.CAMERA_DISTANCE_PRO
    camera_controller.pitch_degrees = TycoonTemplateConfig.CAMERA_PITCH_DEGREES
    camera_controller.position = player.position
    add_child(camera_controller)

func _build_tycoon_world() -> void:
    for zone_index in range(manager.zone_count()):
        _build_zone(zone_index)

    _build_cashout_pad()
    if manager.processing_enabled():
        _build_processor_station()
    _build_capacity_upgrade_pad()

    if manager.zone_count() > 1:
        _build_unlock_pad(1, Vector3(-4.0, 0.0, 6.8))
    if manager.zone_count() > 2:
        _build_unlock_pad(2, Vector3(4.0, 0.0, 6.8))
    _build_objective_marker()

func _build_zone(zone_index: int) -> void:
    var center_x: float = zone_source_positions[zone_index].x
    var zone_root: Node3D = Node3D.new()
    zone_root.name = "Zone%d" % (zone_index + 1)
    add_child(zone_root)

    var zone_floor_color: Color = Color("#9da7a2")
    var zone_inner_color: Color = Color("#c7ceca").lerp(zone_colors[zone_index], 0.13) if manager.is_zone_unlocked(zone_index) else Color("#9da5a1")
    var border_color: Color = Color("#727d78")
    _add_box(Vector3(center_x, 0.02, 0.1), Vector3(7.2, 0.04, 11.4), zone_floor_color, "Zone%dFloor" % (zone_index + 1))
    var inner_floor: MeshInstance3D = _make_box_mesh(Vector3(6.72, 0.025, 10.92), zone_inner_color)
    inner_floor.name = "Zone%dInnerFloor" % (zone_index + 1)
    inner_floor.position = Vector3(center_x, 0.045, 0.1)
    add_child(inner_floor)
    zone_floor_visuals.append(inner_floor)
    _add_box(Vector3(center_x, 0.065, -5.38), Vector3(7.0, 0.08, 0.12), border_color, "ZoneBorder")
    _add_box(Vector3(center_x, 0.065, 5.58), Vector3(7.0, 0.08, 0.12), zone_colors[zone_index], "ZoneAccent")
    _add_box(Vector3(center_x - 3.46, 0.065, 0.1), Vector3(0.12, 0.08, 11.0), border_color, "ZoneBorder")
    _add_box(Vector3(center_x + 3.46, 0.065, 0.1), Vector3(0.12, 0.08, 11.0), border_color, "ZoneBorder")
    var seam_positions: Array[float] = [-3.15, 0.0, 3.15]
    for seam_z in seam_positions:
        _add_box(Vector3(center_x, 0.064, seam_z), Vector3(6.35, 0.012, 0.045), Color("#929b97"), "ConcreteSeam")

    var route_z: Array[float] = [-1.25, 0.25, 1.75]
    for marker_z in route_z:
        var route_color: Color = zone_colors[zone_index].lerp(Color("#d7ddd9"), 0.45) if manager.is_zone_unlocked(zone_index) else Color("#8f9894")
        _add_box(Vector3(center_x, 0.071, marker_z), Vector3(0.34, 0.014, 0.72), route_color, "RouteMarker")

    _add_zone_sign(zone_root, zone_index, Vector3(center_x, 0.0, -4.75))

    var pile: ResourcePile = ResourcePile.new()
    pile.name = "ResourcePile%d" % (zone_index + 1)
    pile.position = zone_source_positions[zone_index]
    pile.collision_layer = 1
    pile.collision_mask = 2
    pile.collect_interval = TycoonTemplateConfig.RESOURCE_COLLECT_INTERVAL
    add_child(pile)
    pile.setup(manager, zone_index)
    _add_area_collision(pile, Vector3(3.0, 1.8, 3.0))
    var scrap_visual: Node3D = _create_scrap_pile(zone_colors[zone_index], zone_index)
    scrap_visual.position.y = 0.28
    pile.add_child(scrap_visual)
    pile.visual = scrap_visual
    zone_source_visuals.append(scrap_visual)

    var collect_pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    collect_pulse.name = "CollectPulse"
    collect_pulse.pulse_amount = 0.035
    collect_pulse.bob_amount = 0.0
    collect_pulse.phase = float(zone_index) * 0.8
    pile.add_child(collect_pulse)
    var collect_ring: MeshInstance3D = _make_cylinder(0.92, 0.055, zone_colors[zone_index].darkened(0.08))
    collect_ring.position.y = 0.05
    collect_pulse.add_child(collect_ring)
    var collect_inner: MeshInstance3D = _make_cylinder(0.62, 0.068, zone_colors[zone_index].lightened(0.12))
    collect_inner.position.y = 0.065
    collect_pulse.add_child(collect_inner)

    var storage_root: Node3D = Node3D.new()
    storage_root.name = "Storage%d" % (zone_index + 1)
    storage_root.position = zone_storage_positions[zone_index]
    add_child(storage_root)
    zone_storage_roots.append(storage_root)

    var pallet: MeshInstance3D = _make_box_mesh(Vector3(2.45, 0.16, 2.1), Color("#745239"))
    pallet.position.y = 0.08
    storage_root.add_child(pallet)
    var crate_a: MeshInstance3D = _make_box_mesh(Vector3(0.95, 0.8, 0.85), Color("#a86f42"))
    crate_a.position = Vector3(-0.55, 0.5, 0.0)
    storage_root.add_child(crate_a)
    var crate_b: MeshInstance3D = _make_box_mesh(Vector3(0.9, 0.75, 0.8), Color("#b47a49"))
    crate_b.position = Vector3(0.48, 0.48, 0.15)
    storage_root.add_child(crate_b)
    var crate_c: MeshInstance3D = _make_box_mesh(Vector3(0.85, 0.62, 0.75), Color("#96603b"))
    crate_c.position = Vector3(0.0, 1.05, -0.12)
    storage_root.add_child(crate_c)
    var rack_left: MeshInstance3D = _make_box_mesh(Vector3(0.12, 1.7, 0.12), Color("#59636a"))
    rack_left.position = Vector3(-1.08, 0.86, 0.72)
    storage_root.add_child(rack_left)
    var rack_right: MeshInstance3D = _make_box_mesh(Vector3(0.12, 1.7, 0.12), Color("#59636a"))
    rack_right.position = Vector3(1.08, 0.86, 0.72)
    storage_root.add_child(rack_right)
    var rack_beam: MeshInstance3D = _make_box_mesh(Vector3(2.28, 0.12, 0.12), Color("#59636a"))
    rack_beam.position = Vector3(0.0, 1.55, 0.72)
    storage_root.add_child(rack_beam)
    var storage_label: Label3D = _add_world_label(storage_root, "x0", Vector3(0, 1.78, 0), 10)
    zone_storage_world_labels.append(storage_label)

    if manager.automation_enabled():
        var hire: WorkerHirePad = WorkerHirePad.new()
        hire.name = "HireWorkerPad%d" % (zone_index + 1)
        hire.position = Vector3(center_x + 2.2, 0.0, 4.8)
        hire.collision_layer = 1
        hire.collision_mask = 2
        add_child(hire)
        hire.setup(manager, zone_index)
        hire_pads.append(hire)
        _add_area_collision(hire, Vector3(1.8, 1.5, 1.8))
        var hire_pulse: TycoonPulseVisual = TycoonPulseVisual.new()
        hire_pulse.name = "HirePulse"
        hire_pulse.phase = float(zone_index) * 0.75
        hire_pulse.bob_amount = 0.025
        hire.add_child(hire_pulse)
        var hire_visual: MeshInstance3D = _make_cylinder(0.72, 0.09, Color("#4f89c4"))
        hire_visual.position.y = 0.06
        hire_pulse.add_child(hire_visual)
        _add_worker_marker(hire_pulse, zone_colors[zone_index])
        var hire_label: Label3D = _add_world_label(hire_pulse, "HIRE\n$%d" % manager.get_worker_cost(zone_index), Vector3(0, 1.42, 0), 12)
        hire_world_labels.append(hire_label)

    var lock_root: Node3D = Node3D.new()
    lock_root.name = "Zone%dLock" % (zone_index + 1)
    add_child(lock_root)
    zone_lock_nodes.append(lock_root)
    if zone_index > 0:
        var gate_z: float = 4.82
        var left_post: MeshInstance3D = _make_box_mesh(Vector3(0.22, 1.65, 0.22), Color("#8d4b43"))
        left_post.position = Vector3(center_x - 2.55, 0.83, gate_z)
        lock_root.add_child(left_post)
        var right_post: MeshInstance3D = _make_box_mesh(Vector3(0.22, 1.65, 0.22), Color("#8d4b43"))
        right_post.position = Vector3(center_x + 2.55, 0.83, gate_z)
        lock_root.add_child(right_post)
        var barrier: MeshInstance3D = _make_box_mesh(Vector3(5.25, 0.22, 0.18), Color("#c85d4d"))
        barrier.position = Vector3(center_x, 1.0, gate_z)
        lock_root.add_child(barrier)
        var stripe_a: MeshInstance3D = _make_box_mesh(Vector3(0.75, 0.24, 0.19), Color("#f1d7a5"))
        stripe_a.position = Vector3(center_x - 1.35, 1.0, gate_z - 0.01)
        stripe_a.rotation_degrees.z = 18.0
        lock_root.add_child(stripe_a)
        var stripe_b: MeshInstance3D = _make_box_mesh(Vector3(0.75, 0.24, 0.19), Color("#f1d7a5"))
        stripe_b.position = Vector3(center_x + 1.35, 1.0, gate_z - 0.01)
        stripe_b.rotation_degrees.z = 18.0
        lock_root.add_child(stripe_b)
        _add_world_label(lock_root, "LOCKED", Vector3(center_x, 1.62, gate_z), 10)

func _build_cashout_pad() -> void:
    var sell: SellPad = SellPad.new()
    sell.name = "CashOutPad"
    sell.position = Vector3(-11.3, 0.0, 5.0)
    sell.collision_layer = 1
    sell.collision_mask = 2
    add_child(sell)
    sell.setup(manager)
    _add_area_collision(sell, Vector3(2.5, 1.6, 2.5))
    var pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    pulse.name = "SellPulse"
    pulse.pulse_amount = 0.045
    pulse.bob_amount = 0.025
    sell.add_child(pulse)
    var visual: MeshInstance3D = _make_cylinder(0.92, 0.11, Color("#48bd72"))
    visual.position.y = 0.07
    pulse.add_child(visual)
    var inner: MeshInstance3D = _make_cylinder(0.58, 0.13, Color("#2f9255"))
    inner.position.y = 0.12
    pulse.add_child(inner)
    _add_world_label(pulse, "CASH OUT", Vector3(0, 0.92, 0), 12)

func _build_processor_station() -> void:
    var process_pad: ProcessorPad = ProcessorPad.new()
    process_pad.name = "ProcessorPad"
    process_pad.position = Vector3(0.0, 0.0, 5.0)
    process_pad.collision_layer = 1
    process_pad.collision_mask = 2
    add_child(process_pad)
    process_pad.setup(manager)
    _add_area_collision(process_pad, Vector3(2.5, 1.6, 2.5))

    var pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    pulse.name = "ProcessorPulse"
    pulse.pulse_amount = 0.045
    pulse.bob_amount = 0.025
    pulse.phase = 0.55
    process_pad.add_child(pulse)

    var outer: MeshInstance3D = _make_cylinder(0.92, 0.11, Color("#58aeb6"))
    outer.position.y = 0.07
    pulse.add_child(outer)
    var inner: MeshInstance3D = _make_cylinder(0.58, 0.13, Color("#337e87"))
    inner.position.y = 0.12
    pulse.add_child(inner)
    processor_world_label = _add_world_label(pulse, "PROCESS\n+%d%%" % manager.get_process_bonus_percent(), Vector3(0, 0.98, 0), 12)

    var machine: Node3D = Node3D.new()
    machine.name = "ProcessorMachine"
    machine.position = Vector3(0.0, 0.0, 7.35)
    add_child(machine)

    var base: MeshInstance3D = _make_box_mesh(Vector3(2.7, 0.35, 1.5), Color("#44535a"))
    base.position.y = 0.18
    machine.add_child(base)
    var body: MeshInstance3D = _make_box_mesh(Vector3(2.15, 1.35, 1.25), Color("#5b7378"))
    body.position.y = 1.0
    machine.add_child(body)
    var hopper: MeshInstance3D = _make_box_mesh(Vector3(1.4, 0.6, 1.05), Color("#7d8e91"))
    hopper.position = Vector3(0.0, 1.92, 0.0)
    machine.add_child(hopper)

    processor_rotor = Node3D.new()
    processor_rotor.name = "Rotor"
    processor_rotor.position = Vector3(0.0, 1.0, -0.68)
    machine.add_child(processor_rotor)
    var hub: MeshInstance3D = _make_cylinder(0.34, 0.18, Color("#2b3d43"))
    hub.rotation_degrees.x = 90.0
    processor_rotor.add_child(hub)
    for angle_index in range(4):
        var blade: MeshInstance3D = _make_box_mesh(Vector3(0.16, 0.92, 0.12), Color("#e0a747"))
        blade.position.y = 0.46
        blade.rotation_degrees.z = float(angle_index) * 90.0
        processor_rotor.add_child(blade)

    _add_world_label(machine, "PROCESSOR", Vector3(0.0, 2.45, -0.72), 11)

func _build_capacity_upgrade_pad() -> void:
    var upgrade: UpgradePad = UpgradePad.new()
    upgrade.name = "CapacityUpgradePad"
    upgrade.position = Vector3(11.3, 0.0, 5.0)
    upgrade.collision_layer = 1
    upgrade.collision_mask = 2
    add_child(upgrade)
    upgrade.setup(manager)
    _add_area_collision(upgrade, Vector3(2.5, 1.6, 2.5))
    var pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    pulse.name = "UpgradePulse"
    pulse.pulse_amount = 0.045
    pulse.bob_amount = 0.025
    pulse.phase = 1.1
    upgrade.add_child(pulse)
    var visual: MeshInstance3D = _make_cylinder(0.92, 0.11, Color("#e4a53b"))
    visual.position.y = 0.07
    pulse.add_child(visual)
    var inner: MeshInstance3D = _make_cylinder(0.58, 0.13, Color("#b9791d"))
    inner.position.y = 0.12
    pulse.add_child(inner)
    _add_world_label(pulse, "BAG +2", Vector3(0, 0.92, 0), 12)

func _build_unlock_pad(zone_index: int, pos: Vector3) -> void:
    var unlock: ZoneUnlockPad = ZoneUnlockPad.new()
    unlock.name = "UnlockZone%dPad" % (zone_index + 1)
    unlock.position = pos
    unlock.collision_layer = 1
    unlock.collision_mask = 2
    add_child(unlock)
    unlock.setup(manager, zone_index)
    _add_area_collision(unlock, Vector3(2.4, 1.5, 2.4))
    var pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    pulse.name = "UnlockPulse"
    pulse.pulse_amount = 0.05
    pulse.bob_amount = 0.025
    pulse.phase = float(zone_index) * 1.2
    unlock.add_child(pulse)
    var visual: MeshInstance3D = _make_cylinder(0.82, 0.09, Color("#d95d5d"))
    visual.position.y = 0.06
    pulse.add_child(visual)
    var inner: MeshInstance3D = _make_cylinder(0.52, 0.11, Color("#a83e3e"))
    inner.position.y = 0.11
    pulse.add_child(inner)
    _add_world_label(pulse, "UNLOCK Z%d\n$%d" % [zone_index + 1, manager.get_zone_unlock_cost(zone_index)], Vector3(0, 1.02, 0), 12)

func _build_objective_marker() -> void:
    objective_marker = Node3D.new()
    objective_marker.name = "ObjectiveMarker"
    objective_marker.visible = false
    add_child(objective_marker)

    var pulse: TycoonPulseVisual = TycoonPulseVisual.new()
    pulse.name = "ObjectivePulse"
    pulse.pulse_amount = 0.08
    pulse.bob_amount = 0.08
    objective_marker.add_child(pulse)

    var ring: MeshInstance3D = _make_cylinder(1.12, 0.055, Color("#f2c14e"))
    ring.position.y = 0.13
    pulse.add_child(ring)
    var core: MeshInstance3D = _make_cylinder(0.26, 0.075, Color("#fff0a6"))
    core.position.y = 0.17
    pulse.add_child(core)

    var pole: MeshInstance3D = _make_box_mesh(Vector3(0.09, 1.55, 0.09), Color("#f7d66d"))
    pole.position = Vector3(0.0, 0.88, 0.0)
    pulse.add_child(pole)
    var flag: MeshInstance3D = _make_box_mesh(Vector3(0.85, 0.42, 0.08), Color("#f2c14e"))
    flag.position = Vector3(0.4, 1.48, 0.0)
    pulse.add_child(flag)

    objective_label = _add_world_label(pulse, "NEXT", Vector3(0.0, 2.05, 0.0), 13)

func _set_objective_marker(world_position: Vector3, label_text: String) -> void:
    if objective_marker == null or objective_label == null:
        return
    if not guidance_enabled or clean_view_enabled:
        objective_marker.visible = false
        return
    objective_marker.position = Vector3(world_position.x, 0.0, world_position.z)
    objective_label.text = label_text
    objective_marker.visible = true

func _best_unlocked_zone() -> int:
    if manager == null:
        return 0
    var result: int = 0
    for i in range(manager.zone_count()):
        if manager.is_zone_unlocked(i):
            result = i
    return result

func _purchase_position_for_goal() -> Vector3:
    if manager == null:
        return zone_source_positions[0]
    if manager.workers_owned[0] <= 0:
        return Vector3(zone_source_positions[0].x + 2.2, 0.0, 4.8)
    if not manager.is_zone_unlocked(1):
        return Vector3(-4.0, 0.0, 6.8)
    if manager.workers_owned[1] <= 0:
        return Vector3(zone_source_positions[1].x + 2.2, 0.0, 4.8)
    if not manager.is_zone_unlocked(2):
        return Vector3(4.0, 0.0, 6.8)
    if manager.workers_owned[2] <= 0:
        return Vector3(zone_source_positions[2].x + 2.2, 0.0, 4.8)
    return Vector3(0.0, 0.0, 5.0)

func _build_ui() -> void:
    var canvas: CanvasLayer = CanvasLayer.new()
    canvas.name = "UI"
    add_child(canvas)

    var root: Control = Control.new()
    game_ui_root = root
    root.name = "SafeUI"
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    canvas.add_child(root)

    var top_margin: MarginContainer = MarginContainer.new()
    top_margin.set_anchors_preset(Control.PRESET_TOP_WIDE)
    top_margin.offset_left = 18.0
    top_margin.offset_top = 14.0
    top_margin.offset_right = -18.0
    top_margin.offset_bottom = 76.0
    root.add_child(top_margin)

    var top_panel: PanelContainer = PanelContainer.new()
    top_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    top_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.78), 14))
    top_margin.add_child(top_panel)

    var top: HBoxContainer = HBoxContainer.new()
    top.add_theme_constant_override("separation", 14)
    top_panel.add_child(top)

    coins_label = _ui_label("$0", 26)
    coins_label.custom_minimum_size = Vector2(150, 50)
    coins_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    top.add_child(coins_label)

    inventory_label = _ui_label("Bag 0/5 • raw $0", 20)
    inventory_label.custom_minimum_size = Vector2(230, 50)
    inventory_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    top.add_child(inventory_label)

    processed_label = _ui_label("Processed $0" if manager.processing_enabled() else "LITE • v%s" % TycoonTemplateConfig.VERSION, 18)
    processed_label.custom_minimum_size = Vector2(175, 50)
    processed_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    processed_label.add_theme_color_override("font_color", Color("#91e0e3"))
    top.add_child(processed_label)

    var spacer: Control = Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(spacer)

    upgrade_label = _ui_label("Bag +2  $50", 18)
    upgrade_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    upgrade_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    upgrade_label.custom_minimum_size = Vector2(190, 50)
    top.add_child(upgrade_label)

    var goal_margin: MarginContainer = MarginContainer.new()
    goal_margin.set_anchors_preset(Control.PRESET_TOP_LEFT)
    goal_margin.offset_left = 18.0
    goal_margin.offset_top = 92.0
    goal_margin.offset_right = 360.0
    goal_margin.offset_bottom = 206.0
    root.add_child(goal_margin)

    var goal_panel: PanelContainer = PanelContainer.new()
    goal_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    goal_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.72), 14))
    goal_margin.add_child(goal_panel)

    var goal_box: VBoxContainer = VBoxContainer.new()
    goal_box.add_theme_constant_override("separation", 2)
    goal_panel.add_child(goal_box)

    var goal_title: Label = _ui_label("NEXT GOAL", 13)
    goal_title.add_theme_color_override("font_color", Color("#f0c85e"))
    goal_box.add_child(goal_title)

    goal_label = _ui_label("Hire first worker", 17)
    goal_label.custom_minimum_size = Vector2(300, 27)
    goal_box.add_child(goal_label)

    goal_progress = ProgressBar.new()
    goal_progress.custom_minimum_size = Vector2(300, 12)
    goal_progress.show_percentage = false
    goal_progress.mouse_filter = Control.MOUSE_FILTER_IGNORE
    goal_progress.add_theme_stylebox_override("background", _panel_style(Color(0.12, 0.16, 0.18, 0.95), 6))
    goal_progress.add_theme_stylebox_override("fill", _panel_style(Color("#e4a53b"), 6))
    goal_box.add_child(goal_progress)

    goal_detail_label = _ui_label("Cash $0 / $100", 12)
    goal_detail_label.add_theme_color_override("font_color", Color("#d8e0e2"))
    goal_box.add_child(goal_detail_label)

    var status_margin: MarginContainer = MarginContainer.new()
    status_margin.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    status_margin.offset_left = -292.0
    status_margin.offset_top = 92.0
    status_margin.offset_right = -18.0
    status_margin.offset_bottom = 276.0
    root.add_child(status_margin)

    var status_panel: PanelContainer = PanelContainer.new()
    status_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    status_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.72), 14))
    status_margin.add_child(status_panel)

    var status_box: VBoxContainer = VBoxContainer.new()
    status_box.add_theme_constant_override("separation", 3)
    status_panel.add_child(status_box)

    var status_title: Label = _ui_label("ZONES • %s" % TycoonTemplateConfig.EDITION, 17)
    status_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status_title.custom_minimum_size = Vector2(244, 28)
    status_box.add_child(status_title)

    for i in range(manager.zone_count()):
        var label: Label = _ui_label("Z%d" % (i + 1), 15)
        label.custom_minimum_size = Vector2(244, 33)
        label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        status_box.add_child(label)
        zone_status_labels.append(label)

    toast_label = _ui_label("", 20)
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    toast_label.position = Vector2(-220, 78)
    toast_label.size = Vector2(440, 40)
    toast_label.add_theme_color_override("font_color", Color("#ffe9a6"))
    root.add_child(toast_label)

    context_panel = PanelContainer.new()
    context_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    context_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    context_panel.offset_left = -245.0
    context_panel.offset_top = -96.0
    context_panel.offset_right = 245.0
    context_panel.offset_bottom = -56.0
    context_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.70), 12))
    root.add_child(context_panel)

    context_label = _ui_label("", 15)
    context_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    context_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    context_panel.add_child(context_label)

    hint_label = _ui_label("Tap: move  •  Drag: rotate", 14)
    hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    hint_label.position = Vector2(-190, -42)
    hint_label.size = Vector2(380, 28)
    root.add_child(hint_label)

    shop_toggle_button = Button.new()
    shop_toggle_button.text = "UPGRADES"
    shop_toggle_button.add_theme_font_size_override("font_size", 15)
    shop_toggle_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    shop_toggle_button.position = Vector2(-142, -54)
    shop_toggle_button.size = Vector2(124, 36)
    shop_toggle_button.pressed.connect(_toggle_upgrade_shop)
    root.add_child(shop_toggle_button)

    shop_panel = PanelContainer.new()
    shop_panel.name = "UpgradeShop"
    shop_panel.visible = false
    shop_panel.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    shop_panel.offset_left = -316.0
    shop_panel.offset_top = -292.0 if manager.advanced_upgrades_enabled() else -196.0
    shop_panel.offset_right = -18.0
    shop_panel.offset_bottom = -64.0
    shop_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.92), 14))
    root.add_child(shop_panel)

    var shop_box: VBoxContainer = VBoxContainer.new()
    shop_box.add_theme_constant_override("separation", 8)
    shop_panel.add_child(shop_box)

    var shop_title: Label = _ui_label("UPGRADES", 18)
    shop_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    shop_box.add_child(shop_title)

    shop_bag_button = Button.new()
    shop_bag_button.custom_minimum_size = Vector2(260, 44)
    shop_bag_button.add_theme_font_size_override("font_size", 14)
    shop_bag_button.pressed.connect(func():
        manager.buy_capacity_upgrade()
        _refresh_upgrade_shop()
    )
    shop_box.add_child(shop_bag_button)

    shop_processor_button = Button.new()
    shop_processor_button.custom_minimum_size = Vector2(260, 44)
    shop_processor_button.add_theme_font_size_override("font_size", 14)
    shop_processor_button.pressed.connect(func():
        manager.buy_processor_upgrade()
        _refresh_upgrade_shop()
    )
    shop_box.add_child(shop_processor_button)
    shop_processor_button.visible = manager.advanced_upgrades_enabled() and manager.processing_enabled()

    shop_worker_speed_button = Button.new()
    shop_worker_speed_button.custom_minimum_size = Vector2(260, 44)
    shop_worker_speed_button.add_theme_font_size_override("font_size", 14)
    shop_worker_speed_button.pressed.connect(func():
        manager.buy_worker_speed_upgrade()
        _refresh_upgrade_shop()
    )
    shop_box.add_child(shop_worker_speed_button)
    shop_worker_speed_button.visible = manager.advanced_upgrades_enabled() and manager.automation_enabled()

    var close_shop: Button = Button.new()
    close_shop.text = "CLOSE"
    close_shop.custom_minimum_size = Vector2(260, 34)
    close_shop.pressed.connect(_toggle_upgrade_shop)
    shop_box.add_child(close_shop)

    _refresh_upgrade_shop()

    var menu_button: Button = Button.new()
    menu_button.text = "MENU"
    menu_button.add_theme_font_size_override("font_size", 14)
    menu_button.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    menu_button.position = Vector2(18, -54)
    menu_button.size = Vector2(104, 36)
    menu_button.pressed.connect(_open_front_menu)
    root.add_child(menu_button)

    _build_clean_view_restore_ui()

func _build_clean_view_restore_ui() -> void:
    clean_view_layer = CanvasLayer.new()
    clean_view_layer.name = "CleanViewUI"
    clean_view_layer.layer = 35
    add_child(clean_view_layer)

    clean_view_restore_button = Button.new()
    clean_view_restore_button.text = "SHOW UI"
    clean_view_restore_button.visible = false
    clean_view_restore_button.add_theme_font_size_override("font_size", 13)
    clean_view_restore_button.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    clean_view_restore_button.position = Vector2(-106, 16)
    clean_view_restore_button.size = Vector2(90, 34)
    clean_view_restore_button.pressed.connect(_disable_clean_view)
    clean_view_layer.add_child(clean_view_restore_button)

func _build_frontend_ui() -> void:
    front_layer = CanvasLayer.new()
    front_layer.name = "FrontendUI"
    front_layer.layer = 40
    add_child(front_layer)

    front_root = Control.new()
    front_root.name = "FrontRoot"
    front_root.mouse_filter = Control.MOUSE_FILTER_STOP
    front_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    front_layer.add_child(front_root)

    var dim: ColorRect = ColorRect.new()
    dim.color = Color(0.025, 0.05, 0.07, 0.88)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    front_root.add_child(dim)

    var card_margin: MarginContainer = MarginContainer.new()
    card_margin.set_anchors_preset(Control.PRESET_CENTER)
    card_margin.offset_left = -255.0
    card_margin.offset_top = -250.0
    card_margin.offset_right = 255.0
    card_margin.offset_bottom = 250.0
    front_root.add_child(card_margin)

    var card: PanelContainer = PanelContainer.new()
    card.add_theme_stylebox_override("panel", _panel_style(Color(0.055, 0.09, 0.12, 0.98), 22))
    card_margin.add_child(card)

    var content_margin: MarginContainer = MarginContainer.new()
    content_margin.add_theme_constant_override("margin_left", 30)
    content_margin.add_theme_constant_override("margin_right", 30)
    content_margin.add_theme_constant_override("margin_top", 24)
    content_margin.add_theme_constant_override("margin_bottom", 24)
    card.add_child(content_margin)

    var stack: VBoxContainer = VBoxContainer.new()
    stack.add_theme_constant_override("separation", 12)
    content_margin.add_child(stack)

    var title: Label = _ui_label(TycoonTemplateConfig.PRODUCT_NAME.to_upper(), 29)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(TycoonTemplateConfig.ACCENT_COLOR_HEX))
    stack.add_child(title)

    var subtitle: Label = _ui_label(TycoonTemplateConfig.MENU_TAGLINE, 15)
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_color_override("font_color", Color("#a9cbd5"))
    stack.add_child(subtitle)

    var features: Label = _ui_label(TycoonTemplateConfig.MENU_FEATURES, 12)
    features.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    features.add_theme_color_override("font_color", Color("#d9e3e6"))
    stack.add_child(features)

    var version_label: Label = _ui_label("Godot 4.x • Mobile-ready • v%s" % TycoonTemplateConfig.VERSION, 13)
    version_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    version_label.add_theme_color_override("font_color", Color("#aab7bc"))
    stack.add_child(version_label)

    var separator: HSeparator = HSeparator.new()
    separator.custom_minimum_size = Vector2(0.0, 10.0)
    stack.add_child(separator)

    front_main_box = VBoxContainer.new()
    front_main_box.add_theme_constant_override("separation", 10)
    stack.add_child(front_main_box)

    var play_button: Button = _menu_button("PLAY / CONTINUE")
    play_button.pressed.connect(_start_or_resume_game)
    front_main_box.add_child(play_button)

    var how_button: Button = _menu_button("HOW TO PLAY")
    how_button.pressed.connect(_show_tutorial_from_menu)
    front_main_box.add_child(how_button)

    var settings_button: Button = _menu_button("SETTINGS")
    settings_button.pressed.connect(_show_settings_panel)
    front_main_box.add_child(settings_button)

    if TycoonTemplateConfig.EDITION == "LITE":
        var pro_button: Button = _menu_button("UPGRADE TO PRO • $29")
        pro_button.pressed.connect(_open_pro_product_page)
        front_main_box.add_child(pro_button)

    var reset_button: Button = _menu_button("RESET DEMO SAVE")
    reset_button.pressed.connect(_request_reset_demo)
    front_main_box.add_child(reset_button)

    reset_dialog = ConfirmationDialog.new()
    reset_dialog.title = "Reset demo save?"
    reset_dialog.dialog_text = "Coins, zones, workers and upgrades will be reset. Settings are kept."
    reset_dialog.ok_button_text = "RESET"
    reset_dialog.confirmed.connect(_reset_demo_from_menu)
    front_root.add_child(reset_dialog)

    front_settings_box = VBoxContainer.new()
    front_settings_box.add_theme_constant_override("separation", 10)
    front_settings_box.visible = false
    stack.add_child(front_settings_box)

    var settings_title: Label = _ui_label("SETTINGS", 20)
    settings_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    front_settings_box.add_child(settings_title)

    guidance_button = _menu_button("")
    guidance_button.pressed.connect(_toggle_guidance)
    front_settings_box.add_child(guidance_button)

    camera_button = _menu_button("")
    camera_button.pressed.connect(_toggle_camera_speed)
    front_settings_box.add_child(camera_button)

    clean_view_button = _menu_button("")
    clean_view_button.pressed.connect(_toggle_clean_view)
    front_settings_box.add_child(clean_view_button)

    var tutorial_again: Button = _menu_button("SHOW TUTORIAL")
    tutorial_again.pressed.connect(_show_tutorial_from_menu)
    front_settings_box.add_child(tutorial_again)

    var settings_back: Button = _menu_button("BACK")
    settings_back.pressed.connect(_show_main_menu_panel)
    front_settings_box.add_child(settings_back)

    var footer: Label = _ui_label("CUSTOMIZE: template_config.gd  •  GUIDE: docs/QUICK_START.md", 11)
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    footer.add_theme_color_override("font_color", Color("#839399"))
    stack.add_child(footer)

    _refresh_settings_buttons()

func _build_tutorial_ui() -> void:
    tutorial_layer = CanvasLayer.new()
    tutorial_layer.name = "TutorialUI"
    tutorial_layer.layer = 50
    add_child(tutorial_layer)

    tutorial_root = Control.new()
    tutorial_root.visible = false
    tutorial_root.mouse_filter = Control.MOUSE_FILTER_STOP
    tutorial_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    tutorial_layer.add_child(tutorial_root)

    var dim: ColorRect = ColorRect.new()
    dim.color = Color(0.02, 0.04, 0.055, 0.62)
    dim.mouse_filter = Control.MOUSE_FILTER_STOP
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    tutorial_root.add_child(dim)

    var panel_margin: MarginContainer = MarginContainer.new()
    panel_margin.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    panel_margin.offset_left = -340.0
    panel_margin.offset_top = -230.0
    panel_margin.offset_right = 340.0
    panel_margin.offset_bottom = -55.0
    tutorial_root.add_child(panel_margin)

    var panel: PanelContainer = PanelContainer.new()
    panel.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.08, 0.11, 0.96), 18))
    panel_margin.add_child(panel)

    var box: VBoxContainer = VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    panel.add_child(box)

    var title: Label = _ui_label("QUICK START", 18)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(TycoonTemplateConfig.ACCENT_COLOR_HEX))
    box.add_child(title)

    tutorial_text = _ui_label("", 17)
    tutorial_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tutorial_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    tutorial_text.custom_minimum_size = Vector2(620, 60)
    box.add_child(tutorial_text)

    tutorial_action_button = _menu_button("NEXT")
    tutorial_action_button.pressed.connect(_advance_tutorial)
    box.add_child(tutorial_action_button)

func _open_pro_product_page() -> void:
    var error_code: Error = OS.shell_open(TycoonTemplateConfig.PRO_PRODUCT_URL)
    if error_code != OK:
        _show_message("Open PRO page: https://shklyar4.gumroad.com/l/godot-mobile-tycoon-template")

func _menu_button(label_text: String) -> Button:
    var button: Button = Button.new()
    button.text = label_text
    button.custom_minimum_size = Vector2(420, 48)
    button.add_theme_font_size_override("font_size", 17)
    return button

func _open_front_menu() -> void:
    gameplay_enabled = false
    if clean_view_restore_button:
        clean_view_restore_button.visible = false
    if front_root:
        front_root.visible = true
    if tutorial_root:
        tutorial_root.visible = false
    _show_main_menu_panel()

func _start_or_resume_game() -> void:
    if front_root:
        front_root.visible = false
    if not onboarding_seen:
        _start_tutorial(false)
    else:
        gameplay_enabled = true
        _apply_preferences()
        _refresh_goal_ui()
        _refresh_context_hint(true)

func _show_main_menu_panel() -> void:
    if front_main_box:
        front_main_box.visible = true
    if front_settings_box:
        front_settings_box.visible = false

func _show_settings_panel() -> void:
    if front_main_box:
        front_main_box.visible = false
    if front_settings_box:
        front_settings_box.visible = true
    _refresh_settings_buttons()

func _show_tutorial_from_menu() -> void:
    if front_root:
        front_root.visible = false
    _start_tutorial(true)

func _start_tutorial(_manual: bool) -> void:
    gameplay_enabled = false
    onboarding_step = 0
    if tutorial_root:
        tutorial_root.visible = true
    _refresh_tutorial_page()

func _refresh_tutorial_page() -> void:
    if tutorial_text == null or tutorial_action_button == null:
        return
    var pages: Array[String] = [
        "1/3  TAP THE GROUND to move your character around the yard.",
        "2/3  Stand on a RESOURCE PILE to collect. Pro workers can automate collection.",
        "3/3  Follow the yellow NEXT marker: collect → process/sell → buy upgrades."
    ]
    onboarding_step = clampi(onboarding_step, 0, pages.size() - 1)
    tutorial_text.text = pages[onboarding_step]
    tutorial_action_button.text = "GOT IT" if onboarding_step == pages.size() - 1 else "NEXT"

func _advance_tutorial() -> void:
    if onboarding_step < 2:
        onboarding_step += 1
        _refresh_tutorial_page()
        return
    onboarding_seen = true
    _save_preferences()
    if tutorial_root:
        tutorial_root.visible = false
    gameplay_enabled = true
    _apply_preferences()
    _refresh_goal_ui()
    _refresh_context_hint(true)

func _request_reset_demo() -> void:
    if reset_dialog:
        reset_dialog.popup_centered(Vector2i(560, 220))

func _reset_demo_from_menu() -> void:
    if manager:
        manager.reset_save()
        _sync_all_ui_and_world()
    _show_message("Demo save reset")

func _toggle_guidance() -> void:
    guidance_enabled = not guidance_enabled
    _apply_preferences()
    _save_preferences()
    _refresh_settings_buttons()
    _refresh_goal_ui()
    _refresh_context_hint(true)

func _toggle_camera_speed() -> void:
    fast_camera = not fast_camera
    _apply_preferences()
    _save_preferences()
    _refresh_settings_buttons()

func _toggle_clean_view() -> void:
    clean_view_enabled = not clean_view_enabled
    _apply_preferences()
    _save_preferences()
    _refresh_settings_buttons()
    _refresh_goal_ui()
    _refresh_context_hint(true)

func _disable_clean_view() -> void:
    clean_view_enabled = false
    _apply_preferences()
    _save_preferences()
    _refresh_settings_buttons()
    _refresh_goal_ui()
    _refresh_context_hint(true)

func _refresh_settings_buttons() -> void:
    if guidance_button:
        guidance_button.text = "Guidance / NEXT markers: %s" % ("ON" if guidance_enabled else "OFF")
    if camera_button:
        camera_button.text = "Camera rotation: %s" % ("FAST" if fast_camera else "NORMAL")
    if clean_view_button:
        clean_view_button.text = "Clean view / screenshots: %s" % ("ON" if clean_view_enabled else "OFF")

func _apply_preferences() -> void:
    if camera_controller:
        camera_controller.rotate_sensitivity = 0.32 if fast_camera else 0.22
    if game_ui_root:
        game_ui_root.visible = not clean_view_enabled
    if clean_view_restore_button:
        clean_view_restore_button.visible = clean_view_enabled and gameplay_enabled
    if context_panel:
        context_panel.visible = guidance_enabled and not clean_view_enabled
    if objective_marker and (not guidance_enabled or clean_view_enabled):
        objective_marker.visible = false

func _load_preferences() -> void:
    var read_path: String = PREFS_PATH
    var migrated_legacy: bool = false
    if not FileAccess.file_exists(read_path):
        for i in range(LEGACY_PREFS_PATHS.size()):
            var legacy_path: String = LEGACY_PREFS_PATHS[i]
            if FileAccess.file_exists(legacy_path):
                read_path = legacy_path
                migrated_legacy = true
                break
    if not FileAccess.file_exists(read_path):
        return
    var file: FileAccess = FileAccess.open(read_path, FileAccess.READ)
    if not file:
        return
    var parsed_value: Variant = JSON.parse_string(file.get_as_text())
    if parsed_value is not Dictionary:
        return
    var parsed: Dictionary = parsed_value as Dictionary
    guidance_enabled = bool(parsed.get("guidance_enabled", true))
    fast_camera = bool(parsed.get("fast_camera", false))
    clean_view_enabled = bool(parsed.get("clean_view_enabled", false))
    onboarding_seen = bool(parsed.get("onboarding_seen", false))
    if migrated_legacy:
        _save_preferences()

func _save_preferences() -> void:
    var data: Dictionary = {
        "guidance_enabled": guidance_enabled,
        "fast_camera": fast_camera,
        "clean_view_enabled": clean_view_enabled,
        "onboarding_seen": onboarding_seen
    }
    var file: FileAccess = FileAccess.open(PREFS_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))

func _sync_all_ui_and_world() -> void:
    _on_coins_changed(manager.coins)
    _on_inventory_changed(manager.inventory, manager.capacity, manager.inventory_value)
    _on_processed_changed(manager.processed_value)
    _on_upgrades_changed(manager.get_process_bonus_percent(), manager.get_worker_speed_percent())
    for i in range(manager.zone_count()):
        _on_storage_changed(i, manager.zone_storage[i], manager.zone_storage[i] * manager.get_zone_value(i))
        _on_zone_changed(i, manager.zone_unlocked[i])
        _on_worker_changed(i, manager.workers_owned[i])
    _refresh_goal_ui()
    _refresh_context_hint(true)

func _unhandled_input(event: InputEvent) -> void:
    if not gameplay_enabled:
        return
    if event is InputEventScreenTouch:
        var touch_event: InputEventScreenTouch = event as InputEventScreenTouch
        if touch_event.pressed and active_touch == -1:
            active_touch = touch_event.index
            touch_start = touch_event.position
            touch_last = touch_event.position
            touch_dragged = false
        elif not touch_event.pressed and touch_event.index == active_touch:
            if not touch_dragged:
                _move_player_from_screen(touch_event.position)
            active_touch = -1
    elif event is InputEventScreenDrag:
        var drag_event: InputEventScreenDrag = event as InputEventScreenDrag
        if drag_event.index == active_touch:
            var drag_delta: Vector2 = drag_event.position - touch_last
            touch_last = drag_event.position
            if drag_event.position.distance_to(touch_start) > DRAG_THRESHOLD:
                touch_dragged = true
            if touch_dragged:
                camera_controller.rotate_by(drag_delta.x)
    elif event is InputEventMouseButton:
        var mouse_button_event: InputEventMouseButton = event as InputEventMouseButton
        if mouse_button_event.button_index == MOUSE_BUTTON_LEFT:
            if mouse_button_event.pressed:
                touch_start = mouse_button_event.position
                touch_last = mouse_button_event.position
                touch_dragged = false
            else:
                if not touch_dragged:
                    _move_player_from_screen(mouse_button_event.position)
        elif mouse_button_event.button_index == MOUSE_BUTTON_WHEEL_UP and mouse_button_event.pressed:
            camera_controller.zoom_by(-0.8)
        elif mouse_button_event.button_index == MOUSE_BUTTON_WHEEL_DOWN and mouse_button_event.pressed:
            camera_controller.zoom_by(0.8)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        var mouse_motion_event: InputEventMouseMotion = event as InputEventMouseMotion
        var drag_delta: Vector2 = mouse_motion_event.position - touch_last
        touch_last = mouse_motion_event.position
        if mouse_motion_event.position.distance_to(touch_start) > DRAG_THRESHOLD:
            touch_dragged = true
        if touch_dragged:
            camera_controller.rotate_by(drag_delta.x)

func _move_player_from_screen(screen_position: Vector2) -> void:
    var camera: Camera3D = camera_controller.get_camera()
    if camera == null:
        return
    var origin: Vector3 = camera.project_ray_origin(screen_position)
    var direction: Vector3 = camera.project_ray_normal(screen_position)
    if abs(direction.y) < 0.0001:
        return
    var t: float = -origin.y / direction.y
    if t <= 0.0:
        return
    var point: Vector3 = origin + direction * t
    point.x = clampf(point.x, -14.0, 14.0)
    point.z = clampf(point.z, -9.0, 9.0)
    player.set_move_target(point)

func _on_coins_changed(value: int) -> void:
    if coins_label:
        coins_label.text = "$%d" % value
        coins_label.scale = Vector2(1.08, 1.08)
        var coins_tween: Tween = create_tween()
        coins_tween.tween_property(coins_label, "scale", Vector2.ONE, 0.16)
    if upgrade_label and manager:
        if manager.capacity_upgrade_maxed():
            upgrade_label.text = "Bag MAX"
        else:
            upgrade_label.text = "Bag +2  $%d" % manager.capacity_upgrade_cost()
    _refresh_upgrade_shop()
    _refresh_hire_pads()
    _refresh_zone_status_labels()
    _refresh_goal_ui()

func _on_inventory_changed(current: int, capacity_value: int, carried_value: int) -> void:
    if inventory_label:
        inventory_label.text = "Bag %d/%d • raw $%d" % [current, capacity_value, carried_value]
        if current > 0:
            inventory_label.scale = Vector2(1.05, 1.05)
            var inventory_tween: Tween = create_tween()
            inventory_tween.tween_property(inventory_label, "scale", Vector2.ONE, 0.14)
    _refresh_zone_status_labels()
    _refresh_goal_ui()

func _on_processed_changed(value: int) -> void:
    if processed_label:
        if manager != null and not manager.processing_enabled():
            processed_label.text = "LITE • v%s" % TycoonTemplateConfig.VERSION
        else:
            processed_label.text = "Processed $%d" % value
            if value > 0:
                processed_label.scale = Vector2(1.07, 1.07)
                var processed_tween: Tween = create_tween()
                processed_tween.tween_property(processed_label, "scale", Vector2.ONE, 0.18)
    _refresh_goal_ui()

func _on_storage_changed(zone_index: int, amount: int, stored_value: int) -> void:
    if zone_index >= 0 and zone_index < zone_storage_world_labels.size():
        zone_storage_world_labels[zone_index].text = "x%d" % amount
    if zone_index >= 0 and zone_index < zone_storage_roots.size() and amount > 0:
        var storage_root: Node3D = zone_storage_roots[zone_index]
        storage_root.scale = Vector3(1.08, 1.08, 1.08)
        var storage_tween: Tween = create_tween()
        storage_tween.tween_property(storage_root, "scale", Vector3.ONE, 0.18)
    _refresh_zone_status_labels()
    _refresh_goal_ui()

func _on_zone_changed(zone_index: int, unlocked: bool) -> void:
    if zone_index >= 0 and zone_index < zone_lock_nodes.size():
        zone_lock_nodes[zone_index].visible = not unlocked and zone_index > 0
    if zone_index >= 0 and zone_index < zone_source_visuals.size():
        zone_source_visuals[zone_index].visible = unlocked
    if zone_index >= 0 and zone_index < zone_floor_visuals.size():
        var floor_color: Color = Color("#c7ceca").lerp(zone_colors[zone_index], 0.13) if unlocked else Color("#9da5a1")
        zone_floor_visuals[zone_index].material_override = _material(floor_color)
    if zone_index >= 0 and zone_index < zone_storage_roots.size():
        zone_storage_roots[zone_index].visible = unlocked
    if zone_index >= 0 and zone_index < hire_pads.size():
        var hire_pad: WorkerHirePad = hire_pads[zone_index]
        hire_pad.visible = unlocked
        hire_pad.monitoring = unlocked and not manager.worker_team_full(zone_index)
    if zone_index > 0:
        var unlock_pad: ZoneUnlockPad = get_node_or_null("UnlockZone%dPad" % (zone_index + 1)) as ZoneUnlockPad
        if unlock_pad:
            unlock_pad.visible = not unlocked
            unlock_pad.monitoring = not unlocked
    if not unlocked:
        _remove_all_workers(zone_index)
    _refresh_hire_pads()
    _refresh_zone_status_labels()
    _refresh_goal_ui()

func _on_worker_changed(zone_index: int, count: int) -> void:
    _sync_worker_count(zone_index, count)
    _refresh_hire_pads()
    _refresh_zone_status_labels()
    _refresh_goal_ui()

func _sync_worker_count(zone_index: int, desired_count: int) -> void:
    if not workers_by_zone.has(zone_index):
        workers_by_zone[zone_index] = []
    var list: Array = workers_by_zone[zone_index] as Array

    while list.size() > desired_count:
        var old_worker: TycoonWorker = list.pop_back() as TycoonWorker
        if is_instance_valid(old_worker):
            old_worker.queue_free()

    while list.size() < desired_count:
        var number: int = list.size()
        var worker: TycoonWorker = _create_worker(zone_index, number)
        add_child(worker)
        list.append(worker)

    workers_by_zone[zone_index] = list

func _remove_all_workers(zone_index: int) -> void:
    if not workers_by_zone.has(zone_index):
        return
    var list: Array = workers_by_zone[zone_index] as Array
    for worker_value: Variant in list:
        var worker: TycoonWorker = worker_value as TycoonWorker
        if is_instance_valid(worker):
            worker.queue_free()
    workers_by_zone[zone_index] = []

func _create_worker(zone_index: int, number: int) -> TycoonWorker:
    var worker: TycoonWorker = TycoonWorker.new()
    worker.name = "Zone%dWorker%d" % [zone_index + 1, number + 1]
    worker.collision_layer = 0
    worker.collision_mask = 0
    worker.move_speed = TycoonTemplateConfig.WORKER_MOVE_SPEED
    worker.gather_delay = TycoonTemplateConfig.WORKER_GATHER_DELAY
    worker.deposit_delay = TycoonTemplateConfig.WORKER_DEPOSIT_DELAY
    worker.setup(
        manager,
        zone_index,
        zone_source_positions[zone_index] + Vector3(0.0, 0.9, 0.0),
        zone_storage_positions[zone_index] + Vector3(0.0, 0.9, 0.0),
        number
    )

    var visual_root: Node3D = Node3D.new()
    visual_root.name = "VisualRoot"
    worker.add_child(visual_root)
    worker.visual_root = visual_root

    var torso: MeshInstance3D = _make_box_mesh(Vector3(0.62, 0.72, 0.44), zone_colors[zone_index].lightened(0.1))
    torso.position.y = 0.02
    visual_root.add_child(torso)

    var legs: MeshInstance3D = _make_box_mesh(Vector3(0.48, 0.5, 0.34), Color("#39424c"))
    legs.position.y = -0.47
    visual_root.add_child(legs)

    var head: MeshInstance3D = MeshInstance3D.new()
    var head_mesh: SphereMesh = SphereMesh.new()
    head_mesh.radius = 0.27
    head_mesh.height = 0.54
    head.mesh = head_mesh
    head.position.y = 0.62
    head.material_override = _material(Color("#efc59a"), 0.7)
    visual_root.add_child(head)

    var hat: MeshInstance3D = _make_cylinder(0.31, 0.14, Color("#f3cf4e"))
    hat.position.y = 0.86
    visual_root.add_child(hat)

    var carry: Node3D = Node3D.new()
    carry.name = "CarryVisual"
    carry.position = Vector3(0.0, 0.28, 0.42)
    visual_root.add_child(carry)
    var carried_box: MeshInstance3D = _make_box_mesh(Vector3(0.46, 0.34, 0.4), Color("#a86f42"))
    carry.add_child(carried_box)
    worker.carry_visual = carry

    return worker

func _toggle_upgrade_shop() -> void:
    if shop_panel == null:
        return
    shop_panel.visible = not shop_panel.visible
    if shop_toggle_button:
        shop_toggle_button.text = "CLOSE" if shop_panel.visible else "UPGRADES"
    _refresh_upgrade_shop()

func _refresh_upgrade_shop() -> void:
    if manager == null:
        return
    if shop_bag_button:
        if manager.capacity_upgrade_maxed():
            shop_bag_button.text = "Bag Capacity  •  MAX (%d)" % manager.capacity
            shop_bag_button.disabled = true
        else:
            shop_bag_button.text = "Bag +2  •  %d slots  •  $%d" % [manager.capacity, manager.capacity_upgrade_cost()]
            shop_bag_button.disabled = false
    if shop_processor_button:
        if manager.processor_upgrade_maxed():
            shop_processor_button.text = "Processor  •  MAX (+%d%%)" % manager.get_process_bonus_percent()
            shop_processor_button.disabled = true
        else:
            shop_processor_button.text = "Processor +5%%  •  now +%d%%  •  $%d" % [manager.get_process_bonus_percent(), manager.processor_upgrade_cost()]
            shop_processor_button.disabled = false
    if shop_worker_speed_button:
        if manager.worker_speed_upgrade_maxed():
            shop_worker_speed_button.text = "Worker Speed  •  MAX (%d%%)" % manager.get_worker_speed_percent()
            shop_worker_speed_button.disabled = true
        else:
            shop_worker_speed_button.text = "Worker Speed +10%%  •  now %d%%  •  $%d" % [manager.get_worker_speed_percent(), manager.worker_speed_upgrade_cost()]
            shop_worker_speed_button.disabled = false

func _on_upgrades_changed(process_bonus_percent: int, _worker_speed_percent: int) -> void:
    if processor_world_label:
        processor_world_label.text = "PROCESS\n+%d%%" % process_bonus_percent
    _refresh_upgrade_shop()
    _refresh_goal_ui()

func _refresh_hire_pads() -> void:
    if manager == null:
        return
    var count: int = mini(hire_pads.size(), hire_world_labels.size())
    count = mini(count, manager.zone_count())
    for i in range(count):
        var unlocked: bool = manager.is_zone_unlocked(i)
        var full: bool = manager.worker_team_full(i)
        hire_pads[i].visible = unlocked
        hire_pads[i].monitoring = unlocked and not full
        if full:
            hire_world_labels[i].text = "TEAM MAX\n%d/%d" % [manager.workers_owned[i], TycoonTemplateConfig.MAX_WORKERS_PER_ZONE]
        else:
            hire_world_labels[i].text = "HIRE %d/%d\n$%d" % [manager.workers_owned[i], TycoonTemplateConfig.MAX_WORKERS_PER_ZONE, manager.get_worker_cost(i)]

func _refresh_zone_status_labels() -> void:
    if manager == null:
        return
    for i in range(mini(zone_status_labels.size(), manager.zone_count())):
        if manager.is_zone_unlocked(i):
            zone_status_labels[i].text = "Z%d  $%d/item  •  raw x%d  •  W%d/%d" % [
                i + 1,
                manager.get_zone_value(i),
                manager.zone_storage[i],
                manager.workers_owned[i],
                TycoonTemplateConfig.MAX_WORKERS_PER_ZONE
            ]
        else:
            zone_status_labels[i].text = "Z%d  LOCKED  •  $%d" % [i + 1, manager.get_zone_unlock_cost(i)]

func _refresh_goal_ui() -> void:
    if manager == null or goal_label == null or goal_progress == null or goal_detail_label == null:
        return

    if not manager.processing_enabled() and not manager.automation_enabled() and manager.zone_count() == 1:
        var raw_ready_lite: int = manager.raw_value_ready()
        if raw_ready_lite > 0:
            goal_label.text = "Sell raw stock"
            goal_progress.max_value = float(maxi(manager.capacity_upgrade_cost(), 1))
            goal_progress.value = float(clampi(manager.coins + raw_ready_lite, 0, maxi(manager.capacity_upgrade_cost(), 1)))
            goal_detail_label.text = "$%d raw ready • CASH OUT" % raw_ready_lite
            _set_objective_marker(Vector3(-11.3, 0.0, 5.0), "NEXT • SELL")
            return
        if not manager.capacity_upgrade_maxed() and manager.coins >= manager.capacity_upgrade_cost():
            goal_label.text = "Upgrade bag"
            goal_progress.max_value = float(maxi(manager.capacity_upgrade_cost(), 1))
            goal_progress.value = goal_progress.max_value
            goal_detail_label.text = "READY • Bag %d • $%d" % [manager.capacity, manager.capacity_upgrade_cost()]
            _set_objective_marker(Vector3(11.3, 0.0, 5.0), "NEXT • UPGRADE")
            return
        if manager.capacity_upgrade_maxed():
            goal_label.text = "Lite demo complete"
            goal_progress.max_value = 1.0
            goal_progress.value = 1.0
            goal_detail_label.text = "Manual collect + sell loop ready"
            _set_objective_marker(zone_source_positions[0], "FREE PLAY")
            return
        goal_label.text = "Earn for bag upgrade"
        goal_progress.max_value = float(maxi(manager.capacity_upgrade_cost(), 1))
        goal_progress.value = float(clampi(manager.coins, 0, manager.capacity_upgrade_cost()))
        goal_detail_label.text = "Cash $%d / $%d • collect raw" % [manager.coins, manager.capacity_upgrade_cost()]
        _set_objective_marker(zone_source_positions[0], "NEXT • COLLECT")
        return

    var purchase_title: String = "Demo loop complete"
    var purchase_target: int = 1

    if manager.workers_owned[0] <= 0:
        purchase_title = "Hire Zone 1 worker"
        purchase_target = manager.get_worker_cost(0)
    elif not manager.is_zone_unlocked(1):
        purchase_title = "Unlock Zone 2"
        purchase_target = manager.get_zone_unlock_cost(1)
    elif manager.workers_owned[1] <= 0:
        purchase_title = "Hire Zone 2 worker"
        purchase_target = manager.get_worker_cost(1)
    elif not manager.is_zone_unlocked(2):
        purchase_title = "Unlock Zone 3"
        purchase_target = manager.get_zone_unlock_cost(2)
    elif manager.workers_owned[2] <= 0:
        purchase_title = "Hire Zone 3 worker"
        purchase_target = manager.get_worker_cost(2)

    if purchase_title == "Demo loop complete":
        goal_label.text = purchase_title
        goal_progress.max_value = 1.0
        goal_progress.value = 1.0
        goal_detail_label.text = "All zones + automation active"
        _set_objective_marker(Vector3(0.0, 0.0, 5.0), "FREE PLAY")
        return

    var raw_ready: int = manager.raw_value_ready()
    var process_bonus: int = manager.get_process_bonus_percent()
    var potential_processed: int = raw_ready + int((float(raw_ready) * float(process_bonus)) / 100.0)
    goal_progress.max_value = float(maxi(purchase_target, 1))

    if manager.coins >= purchase_target:
        goal_label.text = purchase_title
        goal_progress.value = float(purchase_target)
        goal_detail_label.text = "READY • Cash $%d / $%d" % [manager.coins, purchase_target]
        _set_objective_marker(_purchase_position_for_goal(), "NEXT • BUY")
    elif manager.processed_value > 0:
        var after_sale: int = manager.coins + manager.processed_value
        goal_label.text = "Cash out $%d" % manager.processed_value
        goal_progress.value = float(clampi(after_sale, 0, purchase_target))
        if after_sale >= purchase_target:
            goal_detail_label.text = "Then %s • $%d ready" % [purchase_title, after_sale]
        else:
            goal_detail_label.text = "After sale $%d / $%d • %s" % [after_sale, purchase_target, purchase_title]
        _set_objective_marker(Vector3(-11.3, 0.0, 5.0), "NEXT • SELL")
    elif raw_ready > 0:
        goal_label.text = "Process raw stock"
        goal_progress.value = float(clampi(manager.coins + potential_processed, 0, purchase_target))
        goal_detail_label.text = "Raw $%d → $%d • then %s" % [raw_ready, potential_processed, purchase_title]
        _set_objective_marker(Vector3(0.0, 0.0, 5.0), "NEXT • PROCESS")
    else:
        var collect_zone: int = _best_unlocked_zone()
        var missing_cash: int = maxi(0, purchase_target - manager.coins)
        goal_label.text = purchase_title
        goal_progress.value = float(clampi(manager.coins, 0, purchase_target))
        goal_detail_label.text = "Need $%d more • collect Zone %d" % [missing_cash, collect_zone + 1]
        _set_objective_marker(zone_source_positions[collect_zone], "NEXT • COLLECT")

func _refresh_context_hint(force: bool = false) -> void:
    if context_label == null or player == null or manager == null:
        return
    if context_panel:
        context_panel.visible = guidance_enabled and not clean_view_enabled
    if not guidance_enabled or clean_view_enabled:
        last_context_text = ""
        return

    var player_pos: Vector3 = player.global_position
    var best_distance: float = 999.0
    var next_text: String = "Collect raw • PROCESS • CASH OUT" if manager.processing_enabled() else "Collect raw • CASH OUT • upgrade bag"

    for i in range(manager.zone_count()):
        if manager.is_zone_unlocked(i):
            var collect_distance: float = _flat_distance(player_pos, zone_source_positions[i])
            if collect_distance < best_distance and collect_distance <= 3.2:
                best_distance = collect_distance
                next_text = "COLLECT RAW Z%d  •  $%d per item" % [i + 1, manager.get_zone_value(i)]

            if manager.automation_enabled():
                var hire_pos: Vector3 = Vector3(zone_source_positions[i].x + 2.2, 0.0, 4.8)
                var hire_distance: float = _flat_distance(player_pos, hire_pos)
                if hire_distance < best_distance and hire_distance <= 3.0:
                    best_distance = hire_distance
                    if manager.worker_team_full(i):
                        next_text = "ZONE %d TEAM MAX  •  %d/%d" % [i + 1, manager.workers_owned[i], TycoonTemplateConfig.MAX_WORKERS_PER_ZONE]
                    else:
                        next_text = "HIRE Z%d WORKER %d/%d  •  $%d" % [i + 1, manager.workers_owned[i], TycoonTemplateConfig.MAX_WORKERS_PER_ZONE, manager.get_worker_cost(i)]

    if manager.processing_enabled():
        var processor_distance: float = _flat_distance(player_pos, Vector3(0.0, 0.0, 5.0))
        if processor_distance < best_distance and processor_distance <= 3.2:
            best_distance = processor_distance
            var raw_ready: int = manager.raw_value_ready()
            var process_bonus: int = manager.get_process_bonus_percent()
            var process_output: int = raw_ready + int((float(raw_ready) * float(process_bonus)) / 100.0)
            next_text = "PROCESS RAW $%d  →  $%d (+%d%%)" % [raw_ready, process_output, process_bonus]

    var sell_distance: float = _flat_distance(player_pos, Vector3(-11.3, 0.0, 5.0))
    if sell_distance < best_distance and sell_distance <= 3.2:
        best_distance = sell_distance
        if manager.processing_enabled():
            next_text = "CASH OUT PROCESSED  •  $%d ready" % manager.processed_value
        else:
            next_text = "CASH OUT RAW  •  $%d ready" % manager.raw_value_ready()

    var upgrade_distance: float = _flat_distance(player_pos, Vector3(11.3, 0.0, 5.0))
    if upgrade_distance < best_distance and upgrade_distance <= 3.2:
        best_distance = upgrade_distance
        if manager.capacity_upgrade_maxed():
            next_text = "BAG CAPACITY MAX  •  Open UPGRADES for more"
        else:
            next_text = "UPGRADE BAG +2  •  $%d" % manager.capacity_upgrade_cost()

    var unlock_positions: Array[Vector3] = [Vector3.ZERO, Vector3(-4.0, 0.0, 6.8), Vector3(4.0, 0.0, 6.8)]
    for i in range(1, manager.zone_count()):
        if not manager.is_zone_unlocked(i):
            var unlock_distance: float = _flat_distance(player_pos, unlock_positions[i])
            if unlock_distance < best_distance and unlock_distance <= 3.1:
                best_distance = unlock_distance
                next_text = "UNLOCK Z%d  •  $%d" % [i + 1, manager.get_zone_unlock_cost(i)]

    if force or next_text != last_context_text:
        last_context_text = next_text
        context_label.text = next_text

func _ready_cash_value() -> int:
    if manager == null:
        return 0
    return manager.processed_value if manager.processing_enabled() else manager.raw_value_ready()

func _flat_distance(a: Vector3, b: Vector3) -> float:
    return Vector2(a.x, a.z).distance_to(Vector2(b.x, b.z))

func _show_message(text: String) -> void:
    if not toast_label:
        return
    toast_label.text = text
    var token: String = text
    await get_tree().create_timer(1.8).timeout
    if toast_label.text == token:
        toast_label.text = ""

func _material(color: Color, roughness: float = 0.75) -> StandardMaterial3D:
    var mat: StandardMaterial3D = StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    return mat

func _add_box(pos: Vector3, size: Vector3, color: Color, node_name: String) -> void:
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    mesh_instance.name = node_name
    var mesh: BoxMesh = BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.material_override = _material(color)
    add_child(mesh_instance)

func _make_box_mesh(size: Vector3, color: Color) -> MeshInstance3D:
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    var mesh: BoxMesh = BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    mesh_instance.material_override = _material(color)
    return mesh_instance

func _make_cylinder(radius: float, height: float, color: Color) -> MeshInstance3D:
    var mesh_instance: MeshInstance3D = MeshInstance3D.new()
    var mesh: CylinderMesh = CylinderMesh.new()
    mesh.top_radius = radius
    mesh.bottom_radius = radius
    mesh.height = height
    mesh_instance.mesh = mesh
    mesh_instance.material_override = _material(color)
    return mesh_instance

func _add_area_collision(area: Area3D, size: Vector3) -> void:
    var collision: CollisionShape3D = CollisionShape3D.new()
    var shape: BoxShape3D = BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    collision.position.y = size.y * 0.5
    area.add_child(collision)

func _add_world_label(parent: Node3D, text: String, pos: Vector3, font_size: int = 48) -> Label3D:
    var label: Label3D = Label3D.new()
    label.text = text
    label.position = pos
    label.font_size = font_size
    label.outline_size = 2
    label.modulate = Color.WHITE
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.fixed_size = false
    label.pixel_size = 0.008
    parent.add_child(label)
    return label

func _build_shop_building(center: Vector3, wall_color: Color, roof_color: Color, sign_text: String) -> void:
    var root: Node3D = Node3D.new()
    root.position = center
    add_child(root)

    var base: MeshInstance3D = _make_box_mesh(Vector3(2.45, 1.5, 2.25), wall_color)
    base.position.y = 0.75
    root.add_child(base)

    var roof: MeshInstance3D = _make_box_mesh(Vector3(2.72, 0.2, 2.52), roof_color)
    roof.position.y = 1.6
    root.add_child(roof)

    var awning: MeshInstance3D = _make_box_mesh(Vector3(2.0, 0.16, 0.62), roof_color.lightened(0.08))
    awning.position = Vector3(0.0, 1.16, -1.32)
    root.add_child(awning)

    var door: MeshInstance3D = _make_box_mesh(Vector3(0.66, 0.94, 0.12), Color("#2d3742"))
    door.position = Vector3(0.0, 0.48, -1.18)
    root.add_child(door)

    _add_world_label(root, sign_text, Vector3(0.0, 1.86, -1.29), 11)


func _add_tree(pos: Vector3) -> void:
    var root: Node3D = Node3D.new()
    root.position = pos
    add_child(root)

    var trunk: MeshInstance3D = _make_cylinder(0.19, 1.4, Color("#785033"))
    trunk.position.y = 0.7
    root.add_child(trunk)

    var crown: MeshInstance3D = MeshInstance3D.new()
    var sphere: SphereMesh = SphereMesh.new()
    sphere.radius = 0.72
    sphere.height = 1.35
    crown.mesh = sphere
    crown.position.y = 1.65
    crown.material_override = _material(Color("#4f8d4d"), 0.95)
    root.add_child(crown)



func _add_yard_light(pos: Vector3) -> void:
    var root: Node3D = Node3D.new()
    root.position = pos
    add_child(root)

    var pole: MeshInstance3D = _make_cylinder(0.08, 2.55, Color("#4e5b61"))
    pole.position.y = 1.275
    root.add_child(pole)

    var arm: MeshInstance3D = _make_box_mesh(Vector3(0.75, 0.09, 0.09), Color("#4e5b61"))
    arm.position = Vector3(-0.3, 2.48, 0.0)
    root.add_child(arm)

    var lamp: MeshInstance3D = _make_box_mesh(Vector3(0.42, 0.12, 0.28), Color("#e7d9a5"))
    lamp.position = Vector3(-0.66, 2.42, 0.0)
    root.add_child(lamp)

func _add_zone_sign(parent: Node3D, zone_index: int, pos: Vector3) -> void:
    var sign_root: Node3D = Node3D.new()
    sign_root.position = pos
    parent.add_child(sign_root)

    var left_post: MeshInstance3D = _make_box_mesh(Vector3(0.12, 1.15, 0.12), Color("#5a4433"))
    left_post.position = Vector3(-0.75, 0.58, 0.0)
    sign_root.add_child(left_post)

    var right_post: MeshInstance3D = _make_box_mesh(Vector3(0.12, 1.15, 0.12), Color("#5a4433"))
    right_post.position = Vector3(0.75, 0.58, 0.0)
    sign_root.add_child(right_post)

    var board: MeshInstance3D = _make_box_mesh(Vector3(1.85, 0.7, 0.14), zone_colors[zone_index].darkened(0.42))
    board.position = Vector3(0.0, 1.12, 0.0)
    sign_root.add_child(board)

    _add_world_label(sign_root, "ZONE %d" % (zone_index + 1), Vector3(0.0, 1.13, -0.09), 12)


func _create_scrap_pile(color: Color, zone_index: int) -> Node3D:
    var root: Node3D = Node3D.new()

    var base: MeshInstance3D = _make_cylinder(0.95, 0.2, color.darkened(0.18))
    base.position.y = 0.1
    root.add_child(base)

    var piece_positions: Array[Vector3] = [
        Vector3(-0.5, 0.35, -0.18),
        Vector3(0.35, 0.32, 0.2),
        Vector3(0.05, 0.58, -0.25),
        Vector3(-0.18, 0.55, 0.35)
    ]
    var piece_rotations: Array[float] = [0.35, -0.5, 0.9, -0.2]
    for i in range(piece_positions.size()):
        var piece: MeshInstance3D = _make_box_mesh(Vector3(0.8, 0.24, 0.42), color.lightened(0.08 + 0.04 * float(i)))
        piece.position = piece_positions[i]
        piece.rotation_degrees.y = rad_to_deg(piece_rotations[i])
        root.add_child(piece)

    var drum_color: Color = Color("#5c6e77").lightened(0.05 * float(zone_index))
    var drum: MeshInstance3D = _make_cylinder(0.28, 0.65, drum_color)
    drum.position = Vector3(0.48, 0.45, -0.38)
    drum.rotation_degrees.z = 82.0
    root.add_child(drum)

    return root


func _add_worker_marker(parent: Node3D, shirt_color: Color) -> void:
    var marker: Node3D = Node3D.new()
    marker.position = Vector3(0.0, 0.42, 0.0)
    parent.add_child(marker)

    var body: MeshInstance3D = _make_box_mesh(Vector3(0.42, 0.5, 0.3), shirt_color)
    body.position.y = 0.16
    marker.add_child(body)

    var head: MeshInstance3D = MeshInstance3D.new()
    var sphere: SphereMesh = SphereMesh.new()
    sphere.radius = 0.2
    sphere.height = 0.4
    head.mesh = sphere
    head.position.y = 0.56
    head.material_override = _material(Color("#efc59a"), 0.75)
    marker.add_child(head)


func _panel_style(color: Color, radius: int) -> StyleBoxFlat:
    var style: StyleBoxFlat = StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = radius
    style.corner_radius_top_right = radius
    style.corner_radius_bottom_left = radius
    style.corner_radius_bottom_right = radius
    style.content_margin_left = 14.0
    style.content_margin_right = 14.0
    style.content_margin_top = 6.0
    style.content_margin_bottom = 6.0
    return style

func _ui_label(text: String, font_size: int) -> Label:
    var label: Label = Label.new()
    label.text = text
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", Color.WHITE)
    label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.75))
    label.add_theme_constant_override("shadow_offset_x", 2)
    label.add_theme_constant_override("shadow_offset_y", 2)
    return label
