extends CharacterBody3D
class_name TycoonPlayer

@export var move_speed: float = 5.0
@export var acceleration: float = 14.0
@export var stopping_distance: float = 0.12

var target_position: Vector3
var has_target: bool = false

func _ready() -> void:
    target_position = global_position

func set_move_target(world_position: Vector3) -> void:
    target_position = world_position
    target_position.y = global_position.y
    has_target = true

func _physics_process(delta: float) -> void:
    var keyboard: Vector2 = Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        keyboard.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        keyboard.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        keyboard.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        keyboard.y += 1.0
    var desired: Vector3 = Vector3.ZERO

    if keyboard.length() > 0.05:
        has_target = false
        keyboard = keyboard.normalized()
        desired = Vector3(keyboard.x, 0.0, keyboard.y) * move_speed
    elif has_target:
        var to_target: Vector3 = target_position - global_position
        to_target.y = 0.0
        if to_target.length() <= stopping_distance:
            has_target = false
        else:
            desired = to_target.normalized() * move_speed

    velocity.x = move_toward(velocity.x, desired.x, acceleration * delta)
    velocity.z = move_toward(velocity.z, desired.z, acceleration * delta)

    if Vector2(velocity.x, velocity.z).length() > 0.2:
        var facing: float = atan2(velocity.x, velocity.z)
        rotation.y = lerp_angle(rotation.y, facing, minf(1.0, 10.0 * delta))

    move_and_slide()
