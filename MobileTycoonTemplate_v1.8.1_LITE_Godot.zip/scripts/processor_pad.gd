extends Area3D
class_name ProcessorPad

var manager: GameManager
var cooldown: bool = false

func setup(game_manager: GameManager) -> void:
    manager = game_manager

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    if cooldown or manager == null or not (body is TycoonPlayer):
        return
    manager.process_all_raw()
    cooldown = true
    await get_tree().create_timer(0.5).timeout
    cooldown = false
