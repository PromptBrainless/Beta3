extends Node3D
class_name TycoonPulseVisual

@export var pulse_amount: float = 0.055
@export var pulse_speed: float = 2.4
@export var bob_amount: float = 0.055
@export var bob_speed: float = 2.1
@export var phase: float = 0.0

var base_scale: Vector3 = Vector3.ONE
var base_y: float = 0.0
var time_value: float = 0.0

func _ready() -> void:
    base_scale = scale
    base_y = position.y

func _process(delta: float) -> void:
    time_value += delta
    var wave: float = sin(time_value * pulse_speed + phase)
    var scale_factor: float = 1.0 + wave * pulse_amount
    scale = base_scale * scale_factor
    position.y = base_y + sin(time_value * bob_speed + phase) * bob_amount
