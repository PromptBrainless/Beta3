extends Area3D
class_name ResourcePile

@export var collect_interval: float = 0.65

var manager: GameManager
var zone_index: int = 0
var player_inside: bool = false
var timer: float = 0.0
var pulse: float = 0.0
var visual: Node3D
var lock_visual: Node3D

func setup(game_manager: GameManager, source_zone_index: int) -> void:
    manager = game_manager
    zone_index = source_zone_index

func _ready() -> void:
    body_entered.connect(_on_body_entered)
    body_exited.connect(_on_body_exited)

func _process(delta: float) -> void:
    pulse += delta
    if visual:
        visual.position.y = 0.28 + sin(pulse * 2.0) * 0.055
        visual.rotation.y += delta * 0.35
    if not player_inside or manager == null:
        timer = 0.0
        return
    if not manager.is_zone_unlocked(zone_index):
        timer = 0.0
        return
    timer += delta
    if timer >= collect_interval:
        timer = 0.0
        var accepted: int = manager.add_resource_from_zone(zone_index, 1)
        if accepted <= 0:
            manager.message_requested.emit("Inventory full — cash out!")

func _on_body_entered(body: Node3D) -> void:
    if body is TycoonPlayer:
        player_inside = true
        if manager and not manager.is_zone_unlocked(zone_index):
            manager.message_requested.emit("Zone %d is locked" % (zone_index + 1))

func _on_body_exited(body: Node3D) -> void:
    if body is TycoonPlayer:
        player_inside = false
        timer = 0.0
