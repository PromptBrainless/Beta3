extends Area3D
class_name SellPad

var manager: GameManager
var cooldown: bool = false

func setup(game_manager: GameManager) -> void:
    manager = game_manager

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    if cooldown or manager == null or not (body is TycoonPlayer):
        return
    var earned: int = manager.cash_out_all()
    if earned > 0:
        if manager.processing_enabled():
            manager.message_requested.emit("Sold processed goods for $%d" % earned)
        else:
            manager.message_requested.emit("Sold raw goods for $%d" % earned)
    else:
        if manager.processing_enabled():
            manager.message_requested.emit("Process raw stock first")
        else:
            manager.message_requested.emit("Collect raw stock first")
    cooldown = true
    await get_tree().create_timer(0.5).timeout
    cooldown = false
