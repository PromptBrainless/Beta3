extends RefCounted
class_name TycoonTemplateConfig

# ============================================================
# BUYER CONFIGURATION — edit this file first.
# v1.8 Final keeps the most common product, economy and feel settings
# in one place so buyers do not need to hunt through gameplay code.
# ============================================================

# Product / branding
const PRODUCT_NAME: String = "3D Mobile Tycoon Template"
const VERSION: String = "1.8.1"
const SAVE_VERSION: int = 7
const EDITION: String = "LITE"
const MENU_TAGLINE: String = "FULL SYSTEMS • PRO TEMPLATE" if EDITION == "PRO" else "FREE DEMO • LITE EDITION"
const MENU_FEATURES: String = "3 ZONES  •  WORKERS  •  PROCESSING  •  UPGRADES" if EDITION == "PRO" else "1 ZONE  •  COLLECTION  •  CASH OUT  •  BAG UPGRADE"
const ACCENT_COLOR_HEX: String = "#f6d36d"
const DEFAULT_LANGUAGE: String = "en"
const PRO_PRODUCT_URL: String = "https://shklyar4.gumroad.com/l/godot-mobile-tycoon-template"

# Edition switches
const ACTIVE_ZONE_COUNT: int = 1
const ENABLE_PROCESSING: bool = false
const ENABLE_ADVANCED_UPGRADES: bool = false
const ENABLE_MULTI_ZONE_AUTOMATION: bool = false

# Economy — zone order is Zone 1, Zone 2, Zone 3
const STARTING_COINS: int = 0
const ZONE_VALUES: Array[int] = [10, 18, 32]
const ZONE_UNLOCK_COSTS: Array[int] = [0, 150, 450]
const WORKER_BASE_COSTS: Array[int] = [100, 260, 600]
const MAX_WORKERS_PER_ZONE: int = 3

# Bag progression
const BASE_BAG_CAPACITY: int = 5
const BAG_CAPACITY_PER_LEVEL: int = 2
const BAG_UPGRADE_BASE_COST: int = 50
const BAG_UPGRADE_COST_STEP: int = 75
const MAX_BAG_UPGRADE_LEVEL: int = 8

# Processor progression (Pro)
const BASE_PROCESS_BONUS_PERCENT: int = 20
const PROCESS_BONUS_PER_LEVEL: int = 5
const PROCESSOR_UPGRADE_BASE_COST: int = 180
const PROCESSOR_UPGRADE_COST_STEP: int = 220
const MAX_PROCESSOR_UPGRADE_LEVEL: int = 6

# Worker progression (Pro)
const BASE_WORKER_SPEED_PERCENT: int = 100
const WORKER_SPEED_PER_LEVEL: int = 10
const WORKER_SPEED_UPGRADE_BASE_COST: int = 250
const WORKER_SPEED_UPGRADE_COST_STEP: int = 300
const MAX_WORKER_SPEED_LEVEL: int = 5

# Game feel / timing
const PLAYER_MOVE_SPEED: float = 5.0
const PLAYER_ACCELERATION: float = 14.0
const RESOURCE_COLLECT_INTERVAL: float = 0.65
const WORKER_MOVE_SPEED: float = 2.5
const WORKER_GATHER_DELAY: float = 1.10
const WORKER_DEPOSIT_DELAY: float = 0.35
const CAMERA_DISTANCE_LITE: float = 10.8
const CAMERA_DISTANCE_PRO: float = 11.6
const CAMERA_PITCH_DEGREES: float = -54.0

# Lightweight guardrails for buyers editing this file.
# The template reports these issues in the Godot debugger instead of failing silently.
static func get_validation_errors() -> PackedStringArray:
    var errors: PackedStringArray = PackedStringArray()
    if ACTIVE_ZONE_COUNT < 1:
        errors.append("ACTIVE_ZONE_COUNT must be at least 1")
    if ACTIVE_ZONE_COUNT > ZONE_VALUES.size():
        errors.append("ACTIVE_ZONE_COUNT is larger than ZONE_VALUES")
    if ZONE_UNLOCK_COSTS.size() < ACTIVE_ZONE_COUNT:
        errors.append("ZONE_UNLOCK_COSTS needs one entry per active zone")
    if WORKER_BASE_COSTS.size() < ACTIVE_ZONE_COUNT:
        errors.append("WORKER_BASE_COSTS needs one entry per active zone")
    if BASE_BAG_CAPACITY < 1:
        errors.append("BASE_BAG_CAPACITY must be at least 1")
    if BAG_CAPACITY_PER_LEVEL < 1:
        errors.append("BAG_CAPACITY_PER_LEVEL must be at least 1")
    if MAX_WORKERS_PER_ZONE < 1 and ENABLE_MULTI_ZONE_AUTOMATION:
        errors.append("MAX_WORKERS_PER_ZONE must be at least 1 when automation is enabled")
    if ZONE_VALUES.size() < ACTIVE_ZONE_COUNT:
        errors.append("ZONE_VALUES needs one entry per active zone")
    for i in range(ACTIVE_ZONE_COUNT):
        if ZONE_VALUES[i] <= 0:
            errors.append("ZONE_VALUES[%d] must be greater than 0" % i)
        if ZONE_UNLOCK_COSTS[i] < 0:
            errors.append("ZONE_UNLOCK_COSTS[%d] cannot be negative" % i)
        if WORKER_BASE_COSTS[i] < 0:
            errors.append("WORKER_BASE_COSTS[%d] cannot be negative" % i)
    if ZONE_UNLOCK_COSTS[0] != 0:
        errors.append("Zone 1 unlock cost should be 0")
    if ENABLE_ADVANCED_UPGRADES and not ENABLE_PROCESSING:
        errors.append("Advanced upgrades require processing in this demo")
    if BASE_PROCESS_BONUS_PERCENT < 0:
        errors.append("BASE_PROCESS_BONUS_PERCENT cannot be negative")
    if MAX_BAG_UPGRADE_LEVEL < 0 or MAX_PROCESSOR_UPGRADE_LEVEL < 0 or MAX_WORKER_SPEED_LEVEL < 0:
        errors.append("Upgrade max levels cannot be negative")
    if PLAYER_MOVE_SPEED <= 0.0:
        errors.append("PLAYER_MOVE_SPEED must be greater than 0")
    if PLAYER_ACCELERATION <= 0.0:
        errors.append("PLAYER_ACCELERATION must be greater than 0")
    if RESOURCE_COLLECT_INTERVAL <= 0.0:
        errors.append("RESOURCE_COLLECT_INTERVAL must be greater than 0")
    if WORKER_MOVE_SPEED <= 0.0 or WORKER_GATHER_DELAY <= 0.0 or WORKER_DEPOSIT_DELAY <= 0.0:
        errors.append("Worker movement/timing values must be greater than 0")
    if CAMERA_DISTANCE_LITE <= 2.0 or CAMERA_DISTANCE_PRO <= 2.0:
        errors.append("Camera distance must be greater than 2")
    return errors
