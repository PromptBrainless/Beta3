extends Area3D
class_name UpgradePad

var manager: GameManager
var cooldown: bool = false

func setup(game_manager: GameManager) -> void:
    manager = game_manager

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    if cooldown or manager == null or not (body is TycoonPlayer):
        return
    cooldown = true
    manager.buy_capacity_upgrade()
    await get_tree().create_timer(0.8).timeout
    cooldown = false
