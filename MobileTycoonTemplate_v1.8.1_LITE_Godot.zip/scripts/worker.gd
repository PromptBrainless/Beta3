extends CharacterBody3D
class_name TycoonWorker

@export var move_speed: float = 2.5
@export var gather_delay: float = 1.1
@export var deposit_delay: float = 0.35

var manager: GameManager
var zone_index: int = 0
var source_position: Vector3
var storage_position: Vector3
var carrying: bool = false
var waiting: bool = false
var worker_number: int = 0
var carry_visual: Node3D
var visual_root: Node3D
var walk_time: float = 0.0

func setup(game_manager: GameManager, target_zone_index: int, source: Vector3, storage: Vector3, number: int) -> void:
    manager = game_manager
    zone_index = target_zone_index
    worker_number = number
    var lane_offset_x: float = 0.0
    if worker_number == 1:
        lane_offset_x = -0.62
    elif worker_number == 2:
        lane_offset_x = 0.62
    source_position = source + Vector3(lane_offset_x, 0.0, 0.0)
    storage_position = storage + Vector3(lane_offset_x, 0.0, 0.0)

func _ready() -> void:
    global_position = storage_position + Vector3(0.0, 0.9, 0.0)
    if carry_visual:
        carry_visual.visible = false

func _physics_process(delta: float) -> void:
    if manager == null or waiting or not manager.is_zone_unlocked(zone_index):
        velocity = Vector3.ZERO
        move_and_slide()
        return

    var destination: Vector3 = storage_position if carrying else source_position
    var to_target: Vector3 = destination - global_position
    to_target.y = 0.0
    if to_target.length() <= 0.35:
        velocity = Vector3.ZERO
        move_and_slide()
        if carrying:
            _deposit_cycle()
        else:
            _gather_cycle()
        return

    var speed_multiplier: float = manager.get_worker_speed_multiplier()
    velocity = to_target.normalized() * move_speed * speed_multiplier
    if Vector2(velocity.x, velocity.z).length() > 0.1:
        rotation.y = lerp_angle(rotation.y, atan2(velocity.x, velocity.z), 0.22)
        walk_time += delta * 9.0
        if visual_root:
            visual_root.position.y = abs(sin(walk_time)) * 0.075
            visual_root.rotation.z = sin(walk_time) * 0.035
    elif visual_root:
        visual_root.position.y = move_toward(visual_root.position.y, 0.0, delta * 0.8)
        visual_root.rotation.z = move_toward(visual_root.rotation.z, 0.0, delta * 0.5)
    move_and_slide()

func _gather_cycle() -> void:
    if waiting:
        return
    waiting = true
    await get_tree().create_timer(gather_delay).timeout
    carrying = true
    if carry_visual:
        carry_visual.visible = true
    waiting = false

func _deposit_cycle() -> void:
    if waiting:
        return
    waiting = true
    await get_tree().create_timer(deposit_delay).timeout
    if manager:
        manager.add_worker_delivery(zone_index, 1)
    carrying = false
    if carry_visual:
        carry_visual.visible = false
    waiting = false
