extends Area3D
class_name ZoneUnlockPad

var manager: GameManager
var zone_index: int = 1
var cooldown: bool = false

func setup(game_manager: GameManager, target_zone_index: int) -> void:
    manager = game_manager
    zone_index = target_zone_index

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    if cooldown or manager == null or not (body is TycoonPlayer):
        return
    cooldown = true
    manager.unlock_zone(zone_index)
    await get_tree().create_timer(0.8).timeout
    cooldown = false
