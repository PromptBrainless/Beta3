@tool
extends GraphNode

signal add_data

var data = {
	"damage":0.0,
	"cost":100,
	"speedx":0.0,
	"speedy":0.0,
	"fire_rate":0.0,
	"energy":0.0,
	"desc": "N/A",
	"icon":"",
	"level":0,
	"max_level":1,
	"type":"modifier",
	"unlocked": false,
	"index": 0
}

func _ready():
	add_theme_constant_override("title_h_offset", 0)
	for i in range(20):
		$VBoxContainer/index.add_item(str(i))
	$VBoxContainer/index.selected = 0

func _on_delete_request() -> void:
	print("Delete Request")
	queue_free()

func set_data(text):
	data = JSON.parse_string(text)
	if data["type"] == "effect":
		$OptionButton.selected = 1
	$VBoxContainer/index.selected = data["index"]

func get_data() -> String:
	var d = data.duplicate()
	d["id"] = string_to_hex(name)
	return JSON.stringify(d, "\t")

func _on_button_pressed() -> void:
	emit_signal("add_data", self)

func _on_option_button_item_selected(index: int) -> void:
	data["type"] = $OptionButton.get_item_text(index)

func _on_index_item_selected(index: int) -> void:
	data["index"] = int($VBoxContainer/index.get_item_text(index))

func string_to_hex(text: String) -> String:
	var bytes = text.to_utf8_buffer()
	return bytes.hex_encode()
