@tool
extends EditorPlugin


var dock: Control 

func _enter_tree() -> void:
	dock = preload("res://addons/skill_editor/skill_editor.tscn").instantiate()
	
	#add_control_to_container(EditorPlugin.CustomControlContainer.CONTAINER_TOOLBAR, dock)
	get_editor_interface().get_editor_main_screen().add_child(dock)
	_make_visible(false)
	

func _exit_tree() -> void:
	# Clean-up of the plugin goes here.
	if is_instance_valid(dock):
		dock.queue_free()

func _make_visible(visible: bool) -> void:
	if is_instance_valid(dock):
		dock.visible = visible


func _get_plugin_name() -> String:
	return 'SkillEditor'


func _has_main_screen() -> bool:
	return true
