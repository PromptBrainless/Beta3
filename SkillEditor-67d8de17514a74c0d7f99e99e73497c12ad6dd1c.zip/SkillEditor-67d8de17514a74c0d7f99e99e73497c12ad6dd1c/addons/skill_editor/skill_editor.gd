@tool
extends Control

@onready var graphNode = preload("res://addons/skill_editor/modifier_node.tscn")

var node_index = 0
var inital_offset = Vector2(80,80)
var selected_nodes = []
var selected_node

var data = {}
var current_skill = ""


func _on_file_dialog_file_selected(path: String) -> void:
	if $FileDialog.file_mode == FileDialog.FILE_MODE_SAVE_FILE:
		if data.has(current_skill):
			data[current_skill]["connections"] = %GraphEdit.get_connection_list()
			data[current_skill]["nodes"] = []
			for node in %GraphEdit.get_children():
				if node is GraphNode:
					var n = {}
					n["name"] = node.name
					n["data"] = node.get_data()
					n["offsetx"] = node.position_offset.x
					n["offsety"] = node.position_offset.y
					data[current_skill]["nodes"].append(n)
		var data_to_save = JSON.stringify(data)
		var file = FileAccess.open(path, FileAccess.WRITE)
		file.store_line(data_to_save)
		file.close()
	elif $FileDialog.file_mode == FileDialog.FILE_MODE_OPEN_FILE:
		if FileAccess.file_exists(path):
			var file = FileAccess.open(path, FileAccess.READ)
			data = JSON.parse_string(file.get_as_text())
			file.close()
			load_skills()
			clear_graph()

func load_skills() -> void:
	var nodes = %SkillContainer.get_children()
	for node in nodes:
		%SkillContainer.remove_child(node)
		node.queue_free()
	for skill in data:
		var btn = Button.new()
		btn.text = skill
		%SkillContainer.add_child(btn)
		btn.pressed.connect(load_graph.bind(skill))
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT

func _on_load_pressed() -> void:
	$FileDialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	$FileDialog.add_filter("*.json; Json Files")
	$FileDialog.popup_centered(Vector2i(500, 400))

func _on_add_skill_pressed() -> void:
	if current_skill == "":
		$Popup.visible = true
		return
	var graph_node = graphNode.instantiate()
	graph_node.position_offset = inital_offset
	graph_node.title += str(node_index)
	%GraphEdit.add_child(graph_node)
	node_index += 1
	graph_node.connect("add_data", add_data)

func add_data(node: GraphNode) -> void:
	selected_node = node
	%TextEdit.text = node.get_data()
	$TextContainer.visible = true
	%TextEdit.grab_focus()

func _on_graph_edit_connection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	%GraphEdit.connect_node(from_node, from_port, to_node, to_port)

func _on_graph_edit_disconnection_request(from_node: StringName, from_port: int, to_node: StringName, to_port: int) -> void:
	%GraphEdit.disconnect_node(from_node, from_port, to_node, to_port)

func remove_connections_to_nodes(node) -> void:
	for con in %GraphEdit.get_connection_list():
		if con.to_node == node.name or con.from_node == node.name:
			%GraphEdit.disconnect_node(con.from_node, con.from_port, con.to_node, con.to_port)

func _on_graph_edit_delete_nodes_request(nodes: Array[StringName]) -> void:
	for node in selected_nodes:
		remove_connections_to_nodes(node)
		%GraphEdit.remove_child(node)
		node.queue_free()
	if data.has(current_skill):
		data[current_skill]["connections"] = %GraphEdit.get_connection_list()
		data[current_skill]["nodes"] = []
		for node in %GraphEdit.get_children():
			if node is GraphNode:
				var n = {}
				n["name"] = node.name
				n["data"] = node.get_data()
				n["offsetx"] = node.position_offset.x
				n["offsety"] = node.position_offset.y
				data[current_skill]["nodes"].append(n)
	selected_nodes = []

func _on_graph_edit_node_selected(node: Node) -> void:
	selected_nodes.append(node)

func _on_graph_edit_node_deselected(node: Node) -> void:
	selected_nodes.erase(node)

func _on_text_cancel_pressed() -> void:
	$TextContainer.visible = false
	%TextEdit.text = ""

func _on_text_save_pressed() -> void:
	if is_instance_valid(selected_node):
		selected_node.set_data(%TextEdit.text)
	$TextContainer.visible = false
	%TextEdit.text = ""

func _on_add_button_pressed() -> void:
	if data.has(%SkillTreeLineEdit.text) or %SkillTreeLineEdit.text == "":
		return
	data[%SkillTreeLineEdit.text] = {"nodes":[],"connections":[]}
	var btn = Button.new()
	btn.text = %SkillTreeLineEdit.text
	%SkillContainer.add_child(btn)
	btn.pressed.connect(load_graph.bind(%SkillTreeLineEdit.text))
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	%SkillTreeLineEdit.text = ""

func load_graph(skill) -> void:
	current_skill = skill
	%CurrentSkill.text = skill
	clear_graph()
	node_index = 0
	var new_connections = {}
	if data.has(skill):
		for node in data[skill]["nodes"]:
			var graph_node = graphNode.instantiate()
			graph_node.position_offset = Vector2(node["offsetx"],node["offsety"])
			graph_node.title += str(node_index)
			%GraphEdit.add_child(graph_node)
			node_index += 1
			graph_node.connect("add_data", add_data)
			graph_node.set_data(node["data"])
			new_connections[node["name"]] =  graph_node.name
		
		for con in data[skill]["connections"]:
			%GraphEdit.connect_node(new_connections[con.from_node], con.from_port, new_connections[con.to_node], con.to_port)

func clear_graph() -> void:
	%GraphEdit.clear_connections()
	var nodes = %GraphEdit.get_children()
	for node in nodes:
		if node is GraphNode:
			%GraphEdit.remove_child(node)
			node.queue_free()

func _on_save_pressed() -> void:
	$FileDialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	$FileDialog.add_filter("*.json; Json Files")
	$FileDialog.popup_centered(Vector2i(500, 400))

func _on_delete_pressed() -> void:
	data.erase(current_skill)
	current_skill = ""
	load_skills()
	clear_graph()


func _on_clear_pressed() -> void:
	current_skill = ""
	%CurrentSkill.text = ""
	data = {}
	clear_graph()
	for child in %SkillContainer.get_children():
		%SkillContainer.remove_child(child)
		child.queue_free()

func _on_popup_exit_pressed() -> void:
	$Popup.visible = false

func _on_skill_tree_line_edit_text_submitted(new_text: String) -> void:
	_on_add_button_pressed()
