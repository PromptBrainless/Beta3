class_name DPArrayMesher

## DPArrayMesher lets you make array meshes with ease!
## It kind of takes the mesh arrays and mushes them. Like a sled.
## Due to poor triangle strip restart support (35% of reported hardware supports Vulkan 1.3) this uses triangle lists.

var _surface_array : Array[Variant] = [];

enum TypeFlags {
	VERTEX = Mesh.ARRAY_FORMAT_VERTEX, ## Mesher contains vertices
	NORMAL = Mesh.ARRAY_FORMAT_NORMAL, ## Mesher contains normals
	TANGENT = Mesh.ARRAY_FORMAT_TANGENT, ## Mesher contains tangets
	COLOR = Mesh.ARRAY_FORMAT_COLOR, ## Mesher contains colors
	TEX_UV = Mesh.ARRAY_FORMAT_TEX_UV, ## Mesher contains UVs
	TEX_UV2 = Mesh.ARRAY_FORMAT_TEX_UV2, ## Mesher contains second UVs
	CUSTOM0 = Mesh.ARRAY_FORMAT_CUSTOM0, ## Mesher contains custom channel index 0
	CUSTOM1 = Mesh.ARRAY_FORMAT_CUSTOM1, ## Mesher contains custom channel index 1
	CUSTOM2 = Mesh.ARRAY_FORMAT_CUSTOM2, ## Mesher contains custom channel index 2
	CUSTOM3 = Mesh.ARRAY_FORMAT_CUSTOM3, ## Mesher contains custom channel index 3
	BONES = Mesh.ARRAY_FORMAT_BONES, ## Mesher contains bones
	WEIGHTS = Mesh.ARRAY_FORMAT_WEIGHTS, ## Mesher contains bone weights
	INDEX = Mesh.ARRAY_FORMAT_INDEX, ## Mesher uses indices
};
var _types_contained : int = 0;

var _vertex_count: int = 0;
var _index_count: int = 0;

# We ALWAYS use triangles for the AM
var _primitive_type : Mesh.PrimitiveType = Mesh.PRIMITIVE_TRIANGLES;

const _FuncQuads = preload("arraymesher_quads.gd");
const _FuncMisc = preload("arraymesher_misc.gd");
const _FuncTris = preload("arraymesher_tris.gd");

## Creates a new DP with the given arrays available in it.
func _init(types : int = TypeFlags.VERTEX | TypeFlags.NORMAL | TypeFlags.TEX_UV | TypeFlags.INDEX) -> void:
	_surface_array = [];
	_surface_array.resize(Mesh.ARRAY_MAX);
	_types_contained = types;
	_vertex_count = 0;
	_index_count = 0;
	
	assert(_types_contained & TypeFlags.VERTEX);
	if (_types_contained & TypeFlags.VERTEX):
		_surface_array[Mesh.ARRAY_VERTEX] = PackedVector3Array();
	if (_types_contained & TypeFlags.NORMAL):
		_surface_array[Mesh.ARRAY_NORMAL] = PackedVector3Array();
	if (_types_contained & TypeFlags.TANGENT):
		_surface_array[Mesh.ARRAY_TANGENT] = PackedFloat32Array();
	if (_types_contained & TypeFlags.COLOR):
		_surface_array[Mesh.ARRAY_COLOR] = PackedColorArray();
	if (_types_contained & TypeFlags.TEX_UV):
		_surface_array[Mesh.ARRAY_TEX_UV] = PackedVector2Array();
	if (_types_contained & TypeFlags.TEX_UV2):
		_surface_array[Mesh.ARRAY_TEX_UV2] = PackedVector2Array();
	if (_types_contained & TypeFlags.CUSTOM0):
		_surface_array[Mesh.ARRAY_CUSTOM0] = PackedFloat32Array();
	if (_types_contained & TypeFlags.CUSTOM1):
		_surface_array[Mesh.ARRAY_CUSTOM1] = PackedFloat32Array();
	if (_types_contained & TypeFlags.CUSTOM2):
		_surface_array[Mesh.ARRAY_CUSTOM2] = PackedFloat32Array();
	if (_types_contained & TypeFlags.CUSTOM3):
		_surface_array[Mesh.ARRAY_CUSTOM3] = PackedFloat32Array();
	if (_types_contained & TypeFlags.BONES):
		_surface_array[Mesh.ARRAY_BONES] = PackedInt32Array();
	if (_types_contained & TypeFlags.WEIGHTS):
		_surface_array[Mesh.ARRAY_WEIGHTS] = PackedFloat32Array();
	if (_types_contained & TypeFlags.INDEX):
		_surface_array[Mesh.ARRAY_INDEX] = PackedInt32Array();
			
#------------------------------------------------------------------------------#
			
func get_surface_array() -> Array[Variant]:
	resize(_vertex_count, _index_count);
	return _surface_array;
func get_surface_vertex() -> PackedVector3Array:
	return _surface_array[Mesh.ARRAY_VERTEX];
func get_surface_normal() -> PackedVector3Array:
	return _surface_array[Mesh.ARRAY_NORMAL];
func get_surface_color() -> PackedColorArray:
	return _surface_array[Mesh.ARRAY_COLOR];
func get_surface_tex_uv() -> PackedVector2Array:
	return _surface_array[Mesh.ARRAY_TEX_UV];
func get_surface_tex_uv2() -> PackedVector2Array:
	return _surface_array[Mesh.ARRAY_TEX_UV2];
func get_surface_bone() -> PackedInt32Array:
	return _surface_array[Mesh.ARRAY_BONES];
func get_surface_weights() -> PackedFloat32Array:
	return _surface_array[Mesh.ARRAY_WEIGHTS];
func get_surface_custom0() -> PackedFloat32Array:
	return _surface_array[Mesh.ARRAY_CUSTOM0];
func get_surface_custom1() -> PackedFloat32Array:
	return _surface_array[Mesh.ARRAY_CUSTOM1];
func get_surface_custom2() -> PackedFloat32Array:
	return _surface_array[Mesh.ARRAY_CUSTOM2];
func get_surface_custom3() -> PackedFloat32Array:
	return _surface_array[Mesh.ARRAY_CUSTOM3];
func get_surface_index() -> PackedInt32Array:
	return _surface_array[Mesh.ARRAY_INDEX];
	
func get_primitive_type() -> Mesh.PrimitiveType:
	return _primitive_type;
	
func get_vertex_count() -> int:
	return _vertex_count;
func get_index_count() -> int:
	return _index_count;
	
func get_format() -> int:
	return _types_contained;

#------------------------------------------------------------------------------#

## Resize the used type meshes to the given input amount.
## If the container finds that it needs more room, it still still allocate more.
func preallocate(vertices : int, indicies : int) -> void:
	for i in (Mesh.ARRAY_MAX - 1):
		var type_mask := 1 << i;
		if (_types_contained & type_mask):
			if (i == Mesh.ARRAY_TANGENT or i == Mesh.ARRAY_CUSTOM0 or i == Mesh.ARRAY_CUSTOM1 \
			or i == Mesh.ARRAY_CUSTOM2 or i == Mesh.ARRAY_CUSTOM3 or i == Mesh.ARRAY_BONES \
			or i == Mesh.ARRAY_WEIGHTS):
				if (_surface_array[i].size() < vertices * 4):
					_surface_array[i].resize(vertices * 4);
			else:
				if (_surface_array[i].size() < vertices):
					_surface_array[i].resize(vertices);
	if (_types_contained & TypeFlags.INDEX):
		if (_surface_array[Mesh.ARRAY_INDEX].size() < indicies):
			_surface_array[Mesh.ARRAY_INDEX].resize(indicies);
	pass
	
func preallocate_triangles(triangles : int) -> void:
	var vertexCount := triangles * 3;
	var indexCount := triangles * 3;
	preallocate(vertexCount, indexCount);
	
func preallocate_quads(quads : int) -> void:
	var vertexCount := quads * 4;
	var indexCount := quads * 6;
	preallocate(vertexCount, indexCount);
	
## Adds the given amount of storage
func add_storage(vertices : int, indicies : int) -> void:
	preallocate(_vertex_count + vertices, _index_count + indicies);

## Sets the storage to the given size and sets the vertex and index count to that same size
##
## Sets the internal arrays to the same size. Unlike preallocate, this will shrink arrays and delete
## data. This also sets the internal vertex and index count used for adding additional geometry and
## thus will affect any subsequent *_add calls.
func resize(vertices : int, indicies : int) -> void:
	for i in (Mesh.ARRAY_MAX - 1):
		var type_mask := 1 << i;
		if (_types_contained & type_mask):
			if (i == Mesh.ARRAY_TANGENT or i == Mesh.ARRAY_CUSTOM0 or i == Mesh.ARRAY_CUSTOM1 \
			or i == Mesh.ARRAY_CUSTOM2 or i == Mesh.ARRAY_CUSTOM3 or i == Mesh.ARRAY_BONES \
			or i == Mesh.ARRAY_WEIGHTS):
				_surface_array[i].resize(vertices * 4);
			else:
				_surface_array[i].resize(vertices);
	if (_types_contained & TypeFlags.INDEX):
		_surface_array[Mesh.ARRAY_INDEX].resize(indicies);
	_vertex_count = vertices;
	_index_count = indicies;
	pass
	
#------------------------------------------------------------------------------#
	
## Does this mesher have indicies?
func has_indicies() -> bool:
	return (_types_contained & TypeFlags.INDEX) != 0;
## Does this mesher have normals?
func has_normals() -> bool:
	return (_types_contained & TypeFlags.NORMAL) != 0;
## Does this mesher have vertex colors?
func has_colors() -> bool:
	return (_types_contained & TypeFlags.COLOR) != 0;
## Does this mesher have UVs?
func has_uv() -> bool:
	return (_types_contained & TypeFlags.TEX_UV) != 0;
## Does this mesher have secondary UVs?
func has_uv2() -> bool:
	return (_types_contained & TypeFlags.TEX_UV2) != 0;
	
#------------------------------------------------------------------------------#

## Adds a quad to the positions.
##
## Adds a quad to the vertex positions, with normal if enabled. UVs added defaults to a 0,0 -> 1,1 cube.
## Will also add indicies.
func quad_add(position : Vector3, up : Vector3, right : Vector3) -> void:
	assert(has_indicies(), "Array mesher missing Indicies's.");
	_FuncQuads.quad_add(self, position, up, right);
	
## Adds a quad with given indicies.
func quad_add_indicies(corner_00 : int, corner_10 : int,
					   corner_01 : int, corner_11 : int) -> void:
	assert(has_indicies(), "Array mesher missing Indicies's.");
	_FuncQuads.quad_add_indicies(self, corner_00, corner_10, corner_01, corner_11);

## Sets the UVs of the quad at the given corner
func quad_set_uvs(corner_00 : int,
				  uv_00 : Vector2, uv_10 : Vector2,
				  uv_01 : Vector2, uv_11 : Vector2) -> void:
	assert(corner_00 + 4 <= _vertex_count, "Not enough verticies to work from the given index");
	assert(has_uv(), "Array mesher missing UV's.");
	_FuncQuads.quad_set_uvs(self, corner_00, uv_00, uv_10, uv_01, uv_11);

## Sets the UV2s of the quad at the given corner
func quad_set_uv2s(corner_00 : int,
				  uv_00 : Vector2, uv_10 : Vector2,
				  uv_01 : Vector2, uv_11 : Vector2) -> void:
	assert(corner_00 + 4 <= _vertex_count, "Not enough verticies to work from the given index");
	assert(has_uv2(), "Array mesher missing UV2's.");
	_FuncQuads.quad_set_uv2s(self, corner_00, uv_00, uv_10, uv_01, uv_11);

## Sets the normal of the quad
func quad_set_normal(corner_00 : int, normal : Vector3) -> void:
	assert(corner_00 + 4 <= _vertex_count, "Not enough verticies to work from the given index");
	assert(has_normals(), "Array mesher missing normals.");
	_FuncQuads.quad_set_normal(self, corner_00, normal);
	
## Sets the UVs of the quad at the given corner
func quad_set_colors(corner_00 : int,
					 color_00 : Color, color_10 : Color,
					 color_01 : Color, color_11 : Color) -> void:
	assert(corner_00 + 4 <= _vertex_count, "Not enough verticies to work from the given index");
	assert(has_colors(), "Array mesher missing colorss.");
	_FuncQuads.quad_set_colors(self, corner_00, color_00, color_10, color_01, color_11);

## Adds a point to the data.
func point_add(position : Vector3) -> void:
	_FuncMisc.point_add(self, position);

## Adds an array of points to the data
func points_add(positions : PackedVector3Array) -> void:
	_FuncMisc.points_add(self, positions);
	
## Adds a triangle with the given indicies.
func tri_add_indicies(corner_0 : int, corner_1 : int, corner_2 : int) -> void:
	assert(has_indicies(), "Array mesher missing Indicies's.");
	_FuncTris.tri_add_indicies(self, corner_0, corner_1, corner_2);
