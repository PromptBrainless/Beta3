# evaluate_scene — Godot editor addon

The editor addon for the [Evaluate](https://github.com/radical-beard/evaluate) framework:
open an Evaluate `.scene` (TOML) file as an **editable** native scene in the Godot editor,
edit it with the normal tools — move nodes, create and place new nodes, set properties,
attach node scripts — and **Save back to the `.scene`** file. It also renders `.scene` files
as read-only previews.

> This repo is a distribution **mirror** of `dev/addons/evaluate_scene/` from the main
> [evaluate](https://github.com/radical-beard/evaluate) repo, laid out with `addons/` at the
> root so it installs cleanly via the Godot Asset Library. It is kept in sync automatically
> (see `.github/workflows/sync.yml`); edit the addon in the main repo, not here.

## Install

**Requires** the [`RadicalBeard.Evaluate`](https://www.nuget.org/packages/RadicalBeard.Evaluate)
NuGet package (≥ 0.7.1) in your Godot **C#** project — the addon calls into it for the
build/serialize logic.

- **Asset Library:** Editor → *AssetLib* → search “Evaluate Scene” → *Install*.
- **Manual:** copy `addons/evaluate_scene/` into your project (or grab
  `evaluate_scene-<version>.zip` from the main repo’s
  [releases](https://github.com/radical-beard/evaluate/releases)).

Then enable **Evaluate Scene Editor** in *Project Settings → Plugins*.

A Godot **C#** addon’s `.cs` must live under `res://addons/` and compile with your game, so
this ships as source; the stable `Evaluate.Editor` namespace means it drops in verbatim.

## License

Dual-licensed MIT OR Apache-2.0, same as Evaluate. See [LICENSE.md](LICENSE.md).
