# Node Row

A simple Godot plugin that adds two custom nodes for aligning 2D and 3D nodes at uniform distances and interpolate their properties.

## How to install

- Download this repository.
- Copy the addons/node_row folder into the addons folder of your project.
- Go to `Project > Project Settings > Plugins`, enable NodeRow and close the window.
- Reload the project with `Project > Reload Current Project`.

## How to use

- Add multiple nodes of the class Node2D or Node3D as children of a NodeRow2D or a NodeRow3D, respectively.
- Adjust the start and end points of the row by moving the first and last child nodes.
- Check/uncheck the propiertes of the children to be interpolated such as scale and rotation.
- To disable the automatic updating uncheck the property `Editor Live Update`, then you can align them manually clicking the `Align` button.
- The `Remove and reparent` button takes out the children and reparents them to NodeRow's parent, then deletes NodeRow.

## Credits

- [**Godot Engine Logo** by Andrea Calabró](https://commons.wikimedia.org/wiki/File:Godot_logo.svg), licensed under CC BY 4.0.
