@tool
## Interpolates the position and optional properties of its [Node2D] children between the first and the last one.
class_name NodeRow2D
extends NodeRowBase

@export_tool_button("Align", "2D") var align_button = _update_row

@export var interpolate_skew: bool = true
@export var interpolate_modulate: bool = false


func _update_row() -> void:
	var nodes_2d: Array[Node2D] = []
	
	for child: Node in get_children():
		var node_2d := child as Node2D
		if not node_2d:
			push_error(child, " is not a Node2D")
			return
		nodes_2d.append(node_2d)
	
	for i in nodes_2d.size() - 1:
		var weight: float = (float(i) / float(nodes_2d.size() - 1))
		nodes_2d[i].position = nodes_2d[0].position.lerp(nodes_2d[-1].position, weight)
		if interpolate_rotation:
			nodes_2d[i].rotation = _interpolate_float(nodes_2d[0].rotation, nodes_2d[-1].rotation, weight)
		if interpolate_scale:
			nodes_2d[i].scale = nodes_2d[0].scale.lerp(nodes_2d[-1].scale, weight)
		if interpolate_skew:
			nodes_2d[i].skew = _interpolate_float(nodes_2d[0].skew, nodes_2d[-1].skew, weight)
		if interpolate_modulate:
			nodes_2d[i].modulate = nodes_2d[0].modulate.lerp(nodes_2d[-1].modulate, weight)
