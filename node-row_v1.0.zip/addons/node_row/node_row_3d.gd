@tool
## Interpolates the position and optional properties of its [Node3D] children between the first and the last one.
class_name NodeRow3D
extends NodeRowBase

@export_tool_button("Align", "3D") var align_button = _update_row


func _update_row() -> void:
	var nodes_3d: Array[Node3D] = []
	
	for child: Node in get_children():
		var node_3d := child as Node3D
		if not node_3d:
			push_error(child, " is not a Node3D")
			return
		nodes_3d.append(node_3d)
	
	for i in nodes_3d.size() - 1:
		var weight: float = (float(i) / float(nodes_3d.size() - 1))
		nodes_3d[i].position = nodes_3d[0].position.lerp(nodes_3d[-1].position, weight)
		if interpolate_rotation:
			nodes_3d[i].rotation = nodes_3d[0].rotation.lerp(nodes_3d[-1].rotation, weight)
		if interpolate_scale:
			nodes_3d[i].scale = nodes_3d[0].scale.lerp(nodes_3d[-1].scale, weight)
