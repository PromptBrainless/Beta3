@icon("res://addons/node_row/node_row.svg")
@abstract
@tool
## Abstract base class for NodeRow classes.
class_name NodeRowBase
extends Node

@export_tool_button("Remove and reparent", "Remove") var remove_reparent_button = _reparent_and_remove

## Update the row in each frame in editor.
@export var editor_live_update: bool = true
## Update the row in each frame in-game.
@export var ingame_live_update: bool = false
@export var interpolate_rotation: bool = true
@export var interpolate_scale: bool = true


func _process(delta: float) -> void:
	if (Engine.is_editor_hint() and editor_live_update) or (not Engine.is_editor_hint() and ingame_live_update):
		_update_row()


## Update the position and optional properties of the children nodes between the first and the last one.
func _update_row() -> void:
	pass


## Move all the children out of this node and perform [method Node.queue_free]
func _reparent_and_remove() -> void:
	if (self == get_tree().edited_scene_root or self == get_tree().current_scene):
		push_error("Can't remove and reparent because ", self, " is the root Node")
		return
	for child: Node in get_children():
		child.reparent(get_parent())
	queue_free()


func _interpolate_float(value_a: float, value_b: float, weight: float) -> float:
	return value_a + (value_b - value_a) * weight
