# Existing Project

> [!WARNING]  
> This page is being deprecated in favor of [Basic Setup](/addons/maaacks_game_template/docs/BasicSetup.md).

These instructions assume starting with just the contents of `addons/` and going through the installer to copy the examples content into your project. This will be the case when installing the *plugin* version in the Godot Asset Library.

To revisit any part of the initial setup, find the `Setup Wizard` at `Project > Tools > Run Maaack's Game Template Setup...`. Example files can be re-copied from the `Setup Wizard`, assuming they have not been deleted.

1.  Update the project’s name in the main menu.
    

    1.  Open `main_menu.tscn`.
    2.  Select the `TitleLabel` node.
    3.  The `Text` should match the project's name (in the project's settings).
        1. If `Text` is customized, set `Auto Update` to false.
    4.  Select the `SubtitleLabelNode` node and customize the `Text` as desired.
    5.  Save the scene.
    

2.  Link the main menu to a custom game scene (skip if using the example game scene).
    

    1.  Open `main_menu.tscn`.
    2.  Select the `MainMenu` node.
    3.  Update `Game Scene Path` to the path of the project's game scene.
    4.  Save the scene.
    

3.  Add / remove configurable settings to / from menus.
    

    1.  Open `mini_options_menu.tscn` or `[audio|visual|input|game]_options_menu.tscn` scenes to edit their options.
    2.  If an option is not desired, it can always be hidden, or removed entirely (sometimes with some additional work).
    3.  If a new option is desired, refer to [Adding Custom Options.](/addons/maaacks_game_template/docs/AddingCustomOptions.md)


4.  Update the game credits / attribution.
    

    1.  Update the example `ATTRIBUTION.md` with the project's credits.
    2.  Open `credits_label.tscn`.
    3.  Check the `CreditsLabel` has updated with the text.
    4.  Optionally, disable `Auto Update` and customize the text.
    5.  Save the scene (even if it shows no changes).


5.  Continue with:

    1.  [Setting up the Main Menu.](/addons/maaacks_game_template/docs/MainMenuSetup.md)  
    2.  [Setting up a Game Scene.](/addons/maaacks_game_template/docs/GameSceneSetup.md)  
    3.  [Loading scenes asynchronously.](/addons/maaacks_scene_loader/docs/LoadingScenes.md)  
    4.  [Adding icons to the Input Options.](/addons/maaacks_game_template/docs/InputIconMapping.md)  
    5.  [Blending Music.](/addons/maaacks_music_controller/docs/BlendingMusic.md)  
    6.  [Adding UI Sound Effects.](/addons/maaacks_ui_sound_controller/docs/AddingUISFX.md)  
    7.  [Adding Custom Options.](/addons/maaacks_game_template/docs/AddingCustomOptions.md)
    8.  [Utilizing Game Saving.](/addons/maaacks_game_template/docs/GameSaving.md)  
