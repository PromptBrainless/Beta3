# Games 
This page features games using Maaack's Godot Game Template and/or plugins.

If you have a game you'd like to share, join the [Discord server](https://discord.gg/AyZrJh5AMp ) and post a link to your game in #showcase.

## Featured

| HeartFix Express | Baking Godium | Rent Seek Kill |  
| :-------:| :-------: | :-------: |
| ![HeartFix Express](/addons/maaacks_game_template/media/thumbnail-game-heartfix-express.png) | ![Baking Godium](/addons/maaacks_game_template/media/thumbnail-game-baking-godium.png) | ![Rent-Seek-Kill](/addons/maaacks_game_template/media/thumbnail-game-rent-seek-kill.png) |
|  [Find on Steam](https://store.steampowered.com/app/3983290/HeartFix_Express_Demo/)  | [Play on itch.io](https://maaack.itch.io/baking-godium) | [Play on itch.io](https://xandruher.itch.io/rent-seek-kill)  |

## All Shared
### 2026  
https://maaack.itch.io/armed-and-altered  
https://store.steampowered.com/app/3983290/HeartFix_Express_Demo/  
https://store.steampowered.com/app/4029840/Zero_Warning_Burnt_Out/  
https://maaack.itch.io/scout-quest  
https://chippper.itch.io/hand-me-that  

### 2025  
https://sevadusk.itch.io/liferoot  
https://maaack.itch.io/baking-godium  
https://baconeggsrl.itch.io/umbra-city  
https://store.steampowered.com/app/3911550/Warp_Marked_Demo/  
https://maaack.itch.io/kobo-expansion  
https://keur-collectif.itch.io/heartfix-express-demo  
https://spacecheese.itch.io/cia  
https://acul4321.itch.io/bleep  
https://redspine.itch.io/gmtk-game-jam-2025  
https://zunarii.itch.io/loopinball  
https://dragonruler1000.itch.io/beep  
https://store.steampowered.com/app/3751730/Loan_Shark/  
https://parallaxrat.itch.io/no-mans-land  
https://baconeggsrl.itch.io/sprouts-journey  
https://maaack.itch.io/indys-expedition-2  
https://maaack.itch.io/absurd-herd  
https://maaack.itch.io/dungeon-fantasy-fashion-show  
https://plexsoup.itch.io/factoriohno  
https://maaack.itch.io/furnace-in-the-archive  
https://schinken.itch.io/low-ink  

### 2024
https://store.steampowered.com/app/3291880/Spud_Customs/ (Source: https://github.com/Lost-Rabbit-Digital/SpudCustoms)  
https://glockenberg.itch.io/icefire-temple  
https://maaack.itch.io/backroom-labyrinths  
https://maaack.itch.io/haunted-circuits  
https://maaack.itch.io/talk-up-the-tower  
https://marinaaaa.itch.io/meowntaineer  
https://maaack.itch.io/a-darkness-like-gravity  
https://maaack.itch.io/lore-of-the-wild-gwj-70  
https://maaack.itch.io/infinite-horizon  
https://elidef.itch.io/forge-ur-boss  
https://maaack.itch.io/forgeomino  
https://xandruher.itch.io/rent-seek-kill  
https://maaack.itch.io/blind-escape-gwj-66-edition  
https://justaguyjustaguy.itch.io/nannybot-overload  
https://maaack.itch.io/the-last-host-boss-rush  
https://kyveri.itch.io/riverking  

### 2023
https://xandruher.itch.io/spectral-war  
https://maaack.itch.io/the-cat-with-eight-gwj-63-edition  
https://maaack.itch.io/harvest-hill-gwj-62-edition  
https://shoddygames.itch.io/once-summoned  
https://maaack.itch.io/the-last-host  
https://maaack.itch.io/do-androids-dream-gwj-55-edition  
https://maaack.itch.io/character-builder-gwj-53-edition  

### 2022
https://maaack.itch.io/rit-dot-wav  
https://maaack.itch.io/supercritical-a-post-apocalyptic-bonsai  
