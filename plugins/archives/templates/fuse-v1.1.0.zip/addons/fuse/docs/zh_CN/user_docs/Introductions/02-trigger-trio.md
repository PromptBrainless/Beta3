> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/02-trigger-trio.md)

# 5分钟搭出第一个游戏逻辑：Runner / Trigger / MultiEventTrigger 怎么选

看完这篇，你能用 Fuse 在 5 分钟内搭出第一个真正能跑的游戏逻辑，并且面对任何"当 X 发生就做 Y"的需求时，能在十秒内决定该用 Runner、Trigger 还是 MultiEventTrigger——这个选型决定了后面整套逻辑的地基，选错了越往后改越痛。

上一篇给了 Fuse 的能力全图，Event 70 / Instruction 185 / Condition 55 的数字很唬人，但读者真实的下一个问题往往是另一句："图我看懂了，第一步往哪儿下脚？"这篇就专治这个。不铺概念，直接从零搭三个案例，把三种触发器的边界摸清楚。

## 三件套：Fuse 事件入口的三把钥匙

Fuse 里所有"事件驱动"的逻辑，最终都要落到一个节点上：它负责监听某个事件，然后把挂在上面的 ActionRunner（指令序列）跑一遍。Runner、Trigger、MultiEventTrigger 就是这个入口节点的三种形态，区别只在于"监听什么"和"能控制多少"。

一张表先建立全局印象：

| 组件 | 一句话定位 | 典型场景 |
|---|---|---|
| Runner | 把 ActionRunner 包装成节点，监听一个信号或被代码直接调用 | 按钮点击、Timer 回调、代码 await |
| Trigger | 带 Event 资源的标准触发器，有 trigger_once / 冷却 / 事件参数 | 按键、碰撞、生命周期、动画事件 |
| MultiEventTrigger | 把多个事件-动作绑定塞进一个节点 | 一个实体的多种行为合并管理 |

记住一条主线：控制力从弱到强是 Runner → Trigger → MultiEventTrigger，但轻量程度反过来。Runner 最轻、能被代码 await；Trigger 最常用，是事件系统的标准单元；MultiEventTrigger 是给"一个节点要响应一堆事件"的场景准备的。下面用三个案例分别走一遍。

## Runner：按钮点击，以及代码里 await 它

Runner 是入门最快的组件，因为它根本不需要 Event 资源——选个目标节点、选个信号，就绑好了。我们搭一个最经典的"点击按钮打印日志"。

**第一步，搭场景树：**

```
UI
  Button          ← 一个普通 Button
  Runner          ← 添加子节点，搜 "Runner"
```

**第二步，配 Runner 的三个核心属性：**

| 属性 | 值 | 说明 |
|---|---|---|
| action_runner | 新建 ActionRunner | 挂指令序列 |
| target_node | ../Button | 指向按钮 |
| signal_name | pressed | 监听按下信号 |

`target_node` 和 `signal_name` 在 Inspector 里会自动列出目标节点的所有可用信号，下拉选 `pressed` 即可，不用手敲字符串。

**第三步，往 ActionRunner 里塞指令。** 双击新建的 ActionRunner 资源进入编辑，点 instructions 数组的 `+`，选一个 **Print**，`message` 写 "按钮被点了"。保存，按 F5 运行，点按钮——控制台就出来了。整个过程没写一行代码，也没建任何 Event 资源。

【图1：Runner 在 Inspector 中的三属性配置，红框标出 target_node / signal_name / action_runner】
*图注：Runner 的全部配置就这三项，信号名直接下拉选，不用记字符串。*

Runner 真正的杀手锏不是信号绑定，而是它能被代码 `await`。这是另外两个组件都没有的能力。举个例子，你想在代码里等一段死亡动画播完再清理场景：

```gdscript
@onready var runner: Runner = $Runner

func _die() -> void:
    runner.run()                    # 触发死亡指令序列（含播放动画等）
    await runner.wait_completed()   # 等指令序列全部跑完
    print("死亡动画播完了，可以清理场景")
    queue_free()
```

关键在 `await runner.wait_completed()`——它把一段可视化指令序列变成代码里可以等待的异步操作。指令序列里哪怕有 `Wait`、`TweenProperty` 这种耗时指令，代码也会乖乖等它跑完再往下走。这在"可视化搭表现 + 代码做编排"的混合写法里非常好用：策划在 ActionRunner 里拖表现，程序员在脚本里控制时序。

Runner 还提供 `execution_completed(total_time)` / `execution_failed(error)` / `execution_canceled(reason)` 三个信号，以及 `is_running()`、`cancel()`、`reset()` 一套执行控制 API，需要时翻 Runner 指南就行。

**Runner 什么时候别用？** 当你需要下面任意一项时，它搞不定，得换 Trigger：
- 输入事件（键盘 / 鼠标 / 手柄）、物理碰撞事件
- trigger_once（只触发一次）或冷却机制
- 事件参数要传给指令（比如碰撞体引用、输入向量）
- 条件检查

## Trigger：碰到敌人掉血，还得带冷却

Runner 处理不了物理碰撞和触发控制，这正是 Trigger 的主场。我们搭一个"角色碰到敌人受伤，0.5 秒内不重复掉血"的案例——平台跳跃和动作游戏里几乎人手一份的逻辑。

**场景树：**

```
Player
  CollisionShape2D
  Trigger (OnHit)
    event_definition: OnBodyEntered
    action_runner: hurt_actions
    cooldown_mode: GLOBAL_COOLDOWN
    cooldown_time: 0.5
```

和 Runner 最大的不同：Trigger 不直接选目标节点 + 信号，而是配一个 **Event 资源**（`event_definition`）。这个 Event 资源才是真正定义"什么时候触发"的东西。这里用 `OnBodyEntered`，表示有物理体进入 Player 的区域时触发。

光这样配还不够——任何东西碰一下都掉血显然不对，子弹、金币、友军全算进去了。所以 Event 资源里还有一个 `target_group` 字段，填 `"Enemy"`，就只有带 Enemy 组的碰撞体才会触发。这就是 Runner 做不到的"事件参数过滤"。

**冷却防重复触发。** 角色受伤后通常会有一段无敌时间，否则连续蹭到敌人血条瞬间清零。Trigger 直接给了两个现成字段：

| 字段 | 这里填 | 作用 |
|---|---|---|
| cooldown_mode | GLOBAL_COOLDOWN | 上次触发后全局等待 |
| cooldown_time | 0.5 | 0.5 秒内不再触发 |

冷却有两种模式值得记住：`GLOBAL_COOLDOWN` 是上次触发后整体冷却，适合"受伤无敌帧"；`PER_OBJECT_COOLDOWN` 是按触发源独立冷却，适合"对同一个敌人有冷却，但不同敌人各自算"。

另一个常用字段是 `trigger_once`——比如场景就绪初始化只跑一次，配 **OnReady** + trigger_once 就行，不用自己写 flag 变量去卡。

【图2：Trigger 配置，红框标出 event_definition / target_group / cooldown 三组关键字段】
*图注：Trigger 的核心是 Event 资源，冷却和 trigger_once 是 Runner 没有的触发控制。*

**事件参数会自动进上下文。** 这是 Trigger 相对 Runner 的隐性优势：`OnBodyEntered` 触发时，那个碰撞体引用会被自动塞进 ExecutionContext，后面的指令可以直接用变量读到它——比如用 `SetVariable` 把"是谁打的我"存下来，再发个事件通知 UI。这部分下一篇讲变量时还会细说。

Trigger 手动触发也有接口：`trigger_manually()`，但注意它**不支持 await**。如果你非要在代码里等一段指令跑完，那就该回到 Runner。这就是选型要权衡的地方：要 await 选 Runner，要事件控制和参数选 Trigger。

## MultiEventTrigger：把一堆触发器合并成一个节点

做一会儿你就会发现，同一个实体上挂的 Trigger 越来越多。一个 Player 通常同时需要：场景就绪时初始化、按空格跳跃、碰到敌人受伤、生命值归零死亡。四个 Trigger 节点平铺在场景树里，看着乱，管理也麻烦。

MultiEventTrigger 就是来解决这个的——它把多个"事件-动作绑定"（EventBinding）塞进一个节点，每个绑定还能独立配置冷却、trigger_once、条件。

**最爽的用法不是从头建，而是合并现成的。** 实操路径：

1. 先正常用 Trigger 把每种事件都搭好、调通（单事件调试更直观）
2. 在场景树里选中这些 Trigger，右键 → **合并为 MultiEventTrigger**
3. 系统自动建一个 MultiEventTrigger，把所有绑定迁过去，原 Trigger 节点删除
4. 支持 Ctrl+Z 撤销

合并后长这样：

```
Player
  CollisionShape2D
  MultiEventTrigger (PlayerEvents)
    EventBinding[0]:  OnReady           → init_actions    trigger_once: true
    EventBinding[1]:  OnInputKey(空格)  → jump_actions
    EventBinding[2]:  OnBodyEntered     → hurt_actions    cooldown_time: 1.0
    EventBinding[3]:  OnHealthChanged   → death_actions   trigger_once: true
```

场景树从四个触发器节点缩成一个，但每个绑定的配置一个都没丢。

【图3：右键合并 / 拆分的操作动图】
*图注：选中多个 Trigger 右键合并；反向操作是右键拆分，每个 EventBinding 变回独立 Trigger，按事件名自动命名。*

**拆分是合并的逆操作。** 当某个绑定需要单独深入调试，或者逻辑变了想拆开管理，选中 MultiEventTrigger 右键 → **拆分为多个 Trigger**，每个 EventBinding 变回独立 Trigger 节点，自动用事件名（如 OnInputKey、OnReady）命名。注意一个细节：拆分时 `enabled` 属性不会迁移，因为普通 Trigger 节点没有这个字段。

**每绑定独立控制，是这个组件的高阶价值。** 每个绑定都可以单独：
- 配自己的条件（`conditions`，支持复合条件）——比如跳跃绑定要求"生命值 > 0 且不在冷却中"才触发
- 用 `set_binding_enabled(index, false)` 在运行时单独开关——比如玩家死亡后把跳跃和受伤绑定都禁掉，省得死后还能蹦
- 拥有独立的冷却和 trigger_once

要在代码里手动触发某个绑定，用 `trigger_binding(index)`；重置所有状态用 `reset()`。

性能方面 MultiEventTrigger 也做了优化：多个条件会用 WorkerThreadPool 并行评估，高频触发时有批量信号模式，已触发的 trigger_once 和冷却中的绑定会短路跳过。所以合并之后不光场景树干净，运行开销也不会变大。

什么时候别用 MultiEventTrigger？只有一个事件时，直接 Trigger 更直观；需要 await 时，只有 Runner 能做。

## 一张图理清选型

把上面三段压成一条决策路径，面对新需求照着走就行：

1. 需要从代码里调用、或要 `await` 等执行完成？→ **Runner**
2. 只监听一个简单信号、不需要任何过滤和控制？→ **Runner**
3. 需要输入事件 / 物理碰撞 / 生命周期 / 动画事件？→ **Trigger**
4. 需要 trigger_once、冷却、事件参数过滤？→ **Trigger**
5. 同一个实体上有多个事件-动作绑定？→ **MultiEventTrigger**（可以先建多个 Trigger 调通，再右键合并）
6. 需要运行时单独启用 / 禁用某条绑定、或每绑定独立条件？→ **MultiEventTrigger**

几个高频场景再对一遍：

| 场景 | 选谁 | 理由 |
|---|---|---|
| 按钮点击开面板 | Runner | 纯信号绑定 |
| Timer 结束生成敌人 | Runner | 信号转发 |
| 代码 await 动画播完 | Runner | 唯一支持 await |
| 按空格跳跃 | Trigger | 输入事件 + 可能要条件 |
| 碰敌人受伤带冷却 | Trigger | 物理事件 + 组过滤 + 冷却 |
| 场景就绪初始化 | Trigger | trigger_once |
| 一个 NPC 的多种行为 | MultiEventTrigger | 多事件合并 |

记不住没关系——触发器选型指南里有完整的功能矩阵和决策流程图，需要时回查就行。

## 小结

Runner、Trigger、MultiEventTrigger 是 Fuse 所有事件驱动逻辑的三个入口：Runner 最轻、能被代码 await，Trigger 是带事件系统的标准单元，MultiEventTrigger 把多绑定收进一个节点。把这三把钥匙握在手里，你就拥有了一个能把"当 X 发生就做 Y"快速落地的完整工具链——从今天起，大部分游戏逻辑都可以不写代码地搭出来。

不过案例里你可能注意到了一个细节：Trigger 把碰撞体塞进了"上下文"，Runner 的指令里也能读写变量。这些数据到底存在哪、谁能读、跨场景怎么办？这是下一篇的主线。

下一篇：《别让全局变量满天飞：Fuse 的 LOCAL / SCOPE / GLOBAL 三层变量怎么管》——讲清楚可视化逻辑里的数据从哪来、到哪去，以及全局变量持久化怎么接存档。
