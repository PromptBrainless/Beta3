> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/05-flow-control-and-data-structures.md)

# 《If、循环、数组、字典：在可视化系统里搭出复杂逻辑》

看完这篇，你会把 Fuse 从"能算公式、能动动画"推进到"能写真正的程序逻辑"。敌人 AI 怎么在血量低于三成时逃跑、波次系统怎么每一波生成 N 个敌人并等三秒进下一波、背包怎么用字典存物品数量、排行榜怎么排序取最高分——这些在传统观念里"必须写代码"的逻辑，Fuse 用 16 个流程控制指令加 18 个数组操作、16 个字典操作，让你在 Inspector 里全部搭出来。而且这一篇会打破一个常见误解：可视化系统不等于只能做"按按钮播动画"的简单活儿，它照样能写出带分支、带循环、带数据结构的复杂逻辑。

承接上一篇：表达式让我们能算伤害、拼文本、做判断。但只有判断没有分支、只有计算没有循环，逻辑还停留在"一次性直线"阶段。要让逻辑真正像程序一样运转，我们需要流程控制骨架和承载数据的集合结构。

## 一、先纠正一个误解：可视化 ≠ 简单

很多人对可视化编程的印象停留在"连连看"：点按钮 → 播动画，走到区域 → 触发对话。这种触发-响应式的逻辑确实好做，但只要需求里冒出"遍历所有敌人""循环直到血量归零""根据分数查表定等级"，很多人第一反应是"这得写代码了吧"。

Fuse 的流程控制指令组就是为了堵住这个退路而存在的。它把 if/else、for、while、break、continue、函数调用、暂停恢复这些编程语言里最基础的流程原语，全部做成了可视化组件。配合数组、字典两种集合操作，你能搭出的逻辑复杂度，和写 GDScript 没有本质区别——区别只在于，你用的是 Inspector 和下拉框，而不是键盘。

这是 Fuse 的一个重要定位信号：它不是"给不会写代码的人用的简化工具"，而是"另一种表达逻辑的方式"，表达能力强弱不因可视化而打折。这一点贯穿下面所有内容。

## 二、流程控制全家桶：16 个指令

Fuse 的流程控制指令一共 16 个，分六组。先用一张表建立全局印象：

| 分组 | 指令 | 干什么 |
|------|------|--------|
| 条件分支 | **IfThen**（如果/那么）、**IfElse**（如果/否则）、**RunConditionCheck**（运行条件检查） | 条件为真执行子指令；真假两分支；先跑一遍条件检查再决定 |
| 循环 | **ForLoop**（For 循环）、**ForEach**、**WhileLoop**（While 循环）、**Count**（计数） | 计数循环、遍历集合、条件循环、事件驱动的累加器 |
| 循环控制 | **BreakLoop**（跳出循环）、**ContinueLoop**（继续循环） | 跳出当前循环、跳过本次进入下次 |
| 等待 | **Wait**（等待）、**WaitUntil**（等待直到）、**WaitForEvent**（等待事件）、**WaitForSignal**（等待信号） | 等若干秒、轮询等条件成立、挂起直到收到 Event Bus 事件/指定信号 |
| 游戏控制 | **PauseGame**（暂停游戏）、**ResumeGame**（恢复游戏） | 暂停场景树、恢复 |
| 高级调用 | **RunRunner**（运行 Runner） | 触发另一个 ActionRunner，相当于"函数调用" |

注意几个和代码习惯不同的点：

`IfThen` 和 `IfElse` 的"条件"不是表达式文本框，而是一个 Condition 资源——也就是上一篇讲的 ExpressionCondition，或者更复杂的 `CheckAll` / `CheckAny` 复合条件。你可以把任意条件树塞进 if 里。

`ForEach` 的数组来源有两种：从变量取、从节点组取。这意味着你可以直接遍历"敌人组"里的每一个敌人，不用先手动收集成数组；如果要遍历某节点的子节点，可以先用 `GetAllChildren` 等指令把子节点收集成数组再传入。

`Wait` 是异步指令，它后面的指令会等等待结束才继续——这正好用来做"波次之间停三秒"这种节奏控制。

`BreakLoop` / `ContinueLoop` 只影响最近的一层循环，嵌套循环时记住这个作用域。

`RunRunner` 是可视化逻辑里的"函数调用"：把一段公共逻辑抽成单独的 Runner 资源，通过 `target_runner` 参数指定要触发的 Runner 节点，多处复用，改一处全改。

## 三、实战：敌人 AI 决策

先用分支搭一个最常见的逻辑——敌人 AI。需求很简单：每帧检查，离玩家近就追，血量低于三成就跑，否则攻击。

```
事件: OnProcess（每帧处理）
指令:
  → IfThen(条件: 距离玩家 < 200)
      → 追逐玩家（MoveCharacterBody2DComposite 朝向玩家）
  → IfElse(条件: 生命值 <= 30%)
      真分支 → 逃跑（朝远离玩家方向移动）
      假分支 → 攻击（播放攻击动画 + 伤害判定）
```

这里第一个 `IfThen` 的条件是 `CheckDistance`（对象距离），第二个 `IfElse` 的条件可以用 `CompareHealthThreshold`（生命值低于/高于）或者直接用上一篇的 `ExpressionCondition` 写 `{local:hp} / {local:max_hp} <= 0.3`。两种写法都行，前者是现成条件组件，后者更灵活。

注意这里两个 if 是**并列**的，不是嵌套。Fuse 的指令序列默认从上到下顺序执行，每条 IfThen 独立判断。如果你想要"先判断距离、再在距离近的前提下判断血量"，把第二个 IfElse 拖进第一个 IfThen 的子指令列表里就行——子指令是可以无限嵌套的，这就是分支组合的方式。

## 四、实战：波次生成（循环 + 等待 + 数组）

把循环和等待组合起来，做一个波次系统。需求：游戏开始后，共 5 波，每波生成 3 个敌人，每波之间等 3 秒。

```
游戏开始（OnReady）
  → ForLoop(i, loop_count=5)
      循环体:
        → ForLoop(j, loop_count=3)
            循环体:
              → GetRandomPointInRange（在出生点附近取随机位置）
              → InstantiateScene（实例化敌人场景到该位置）
              → ArrayAdd（把新敌人加入"存活敌人"数组）
        → Wait(3 秒)
```

这是双层 `ForLoop` 嵌套：外层跑 5 波，内层每波生 3 个敌人。内层结束后 `Wait` 停 3 秒，再进下一波。注意 `Wait` 放在外层循环体里、内层循环之后——位置决定了它是"每波之间等"而不是"每个敌人之间等"。

`ForLoop` 的核心参数是 `loop_count`（循环次数），可选 `index_variable`（索引变量，默认 `"i"`）来在循环体里拿到当前迭代索引。它和代码里的 `for i in range(count)` 等价，**没有**独立的"起始/结束/步长"参数。

`ForLoop` 和 `Count` 容易混，区分一下：`ForLoop` 是一次性跑完整个循环（比如生成 5 波），`Count` 是每次执行时把内部计数器增加 `increment` 的简单计数器。做波次用 ForLoop，做"击杀满 10 个解锁成就"需要配合条件组件判断 `Count` 的当前值。

## 五、实战：暂停菜单（游戏控制 + 分支）

暂停菜单是流程控制里很典型的一组搭配，用 `PauseGame` / `ResumeGame` 加 `IfThen`：

```
事件: OnInputKey（ESC 键）
指令:
  → IfThen(条件: 游戏未暂停)
      → PauseGame
      → ShowHideUI（显示暂停菜单面板）
  → IfThen(条件: 游戏已暂停)
      → ResumeGame
      → ShowHideUI（隐藏暂停菜单面板）
```

两个 `IfThen` 互斥，靠一个"是否已暂停"的变量（或节点激活状态）来切换。`PauseGame` 暂停整个场景树，`ResumeGame` 恢复。这是个很干净的状态切换模式。

## 六、数组：18 个操作管集合

流程控制解决了"怎么走"，数据结构解决"装什么"。Fuse 的数组操作一共 18 个，覆盖增删查改、排序、统计、向量运算。

| 分组 | 指令 |
|------|------|
| 增删改 | **ArrayAdd**（添加数组元素）、**ArrayInsert**（数组插入）、**ArraySet**（设置数组元素）、**ArrayRemove**（移除数组元素）、**ArrayClear**（清空数组）、**ArrayGet**（获取数组元素） |
| 查找 | **ArrayFind**（查找数组元素）、**ArrayContains**（检查数组包含）、**ArrayRandom**（获取随机元素）、**ArraySize**（数组大小） |
| 重排 | **ArrayReverse**（反转数组）、**ArrayShuffle**（打乱数组）、**ArrayNumericSort**（数值排序）、**ArrayVectorSort**（向量排序） |
| 统计 | **ArrayNumericGetLargest**（获取最大值）、**ArrayNumericGetSmallest**（获取最小值） |
| 向量 | **ArrayVectorGetClosest**（获取最近向量）、**ArrayVectorGetFurthest**（获取最远向量） |

数组的来源有两种：从变量取、从节点组取。这意味着你不用先手动把敌人组转成数组，`ArraySize` 可以直接对着"enemies"这个组取成员数。如果要遍历子节点，先用 `GetAllChildren` 等指令把子节点收集成数组即可。

几个实战要点：

`ArrayGet` / `ArraySet` / `ArrayInsert` / `ArrayRemove` 都支持**负索引**，`-1` 就是最后一个元素。这在"取数组最后一个敌人"时很方便，不用先 `ArraySize` 再减一。

`ArrayNumericSort` 和 `ArrayVectorSort` 是**原地排序**，直接改原数组。`ArrayShuffle` 用的是 Fisher-Yates 算法，洗牌是公平的。

排序和统计配合能做排行榜：`ArrayAdd` 加分 → `ArrayNumericSort` 降序 → `ArrayNumericGetLargest` 取最高分显示。三步搞定。

向量那一组是 2D/3D 游戏的宝藏。最常见的"找最近敌人"：把所有敌人位置收集成一个向量数组，`ArrayVectorGetClosest`（获取最近向量）对着玩家位置一比，直接返回最近的那个敌人坐标，再喂给 `LookAt`（朝向）——瞄准逻辑两三步完成。反过来 `ArrayVectorGetFurthest` 找最远，适合做"逃离最远敌人"的 AI。

## 七、字典：16 个操作管键值对

字典是 RPG 和存档系统的主力。Fuse 提供 16 个字典操作，分六组：

| 分组 | 指令 |
|------|------|
| 基础 | **DictSetKeyValue**（设置字典键值）、**DictGetValue**（获取字典值）、**DictRemoveKey**（移除字典键）、**DictClear**（清空字典）、**DictSize**（获取字典大小）、**DictDuplicate**（复制字典） |
| 批量 | **DictGetKeys**（获取字典键列表）、**DictGetValues**（获取字典所有值）、**DictMerge**（合并字典） |
| 嵌套路径 | **DictGetByPath**（获取字典路径值）、**DictSetByPath**（设置字典路径值） |
| 数值运算 | **DictModifyNumber**（修改字典数值）、**DictMathOp**（字典数学运算）、**DictToggleBoolean**（切换字典布尔值） |
| JSON | **DictToJson**（字典转 JSON）、**DictFromJson**（JSON 转字典） |

字典的来源是 Scope Variable 或 Global Variable——因为字典通常是要跨节点、跨场景共享的结构化数据，放局部变量意义不大。

最值得强调的是**嵌套路径访问**。`DictGetByPath` 和 `DictSetByPath` 接受一个用斜杠分隔的路径，比如 `"player/stats/hp"`，等同于 `dict["player"]["stats"]["hp"]`。这意味着你可以用一个扁平的字典存一棵嵌套的数据树，不用一层层 `DictGetValue` 取出来再取。这对存档和配置表极其友好：

```
读取难度: DictGetByPath(配置字典, "settings/difficulty")
修改设置: DictSetByPath(配置字典, "settings/difficulty", "hard")
```

`DictModifyNumber` 是另一个高频指令，专门对数值键做加减。背包用物品 ID 当键存数量，用掉一个就 `DictModifyNumber(背包, 物品ID, -1)`，比"取出值、减一、存回去"三步合一。`DictToggleBoolean` 同理，一键翻转开关类状态。

`DictToJson` / `DictFromJson` 这一对打通了存档的最后一公里：把玩家数据字典序列化成 JSON 字符串，再用上一篇讲过的 `SaveGlobalVariables` 存进全局存档槽位；读档时反过来 `LoadGlobalVariables` → `DictFromJson` 还原。一个完整的玩家数据管理链路就通了：

```
初始化 → DictSetKeyValue(玩家数据, "name", "勇者")
         DictSetKeyValue(玩家数据, "level", 1)
升级   → DictModifyNumber(玩家数据, "level", +1)
存档   → DictToJson(玩家数据) → SaveGlobalVariables
读档   → LoadGlobalVariables → DictFromJson → DictGetValue
```

几个细节：`DictSetKeyValue` 在字典不存在时会自动创建新字典，不用担心初始化顺序；`DictGetValue` 支持默认值参数，键不存在时返回默认值而不报错；`DictMerge` 默认会覆盖已存在的键，可以通过 `overwrite_existing` 选项改成保留原值。

## 八、可视化照样写出真实逻辑：把四块拼起来

这一篇的标题是"搭出复杂逻辑"，所以最后把流程控制、数组、字典、上一篇的表达式拼成一个稍完整的例子，证明可视化系统的表达能力。

需求：一个掉落系统。击杀敌人后，根据敌人等级查掉落表（字典），把掉落物加入背包（字典），如果背包满了（数组长度达标）就触发提示，否则播放拾取动画。

```
事件: 敌人死亡（OnHealthChanged → hp <= 0，或自定义信号）
指令:
  → DictGetByPath(掉落表, "level_" + str({local:enemy_level}) + "/items")
      # 取出该等级的掉落物列表，存到 drops 数组
  → ForEach(drops)
      循环体（当前元素 = 物品ID）:
        → ArraySize(背包数组) → 存到 bag_size
        → IfElse(条件: {local:bag_size} >= {local:max_slots})
            真分支 → SetUIText("背包已满") + TweenShakeAnimation（震动提示）
            假分支 → DictModifyNumber(背包字典, 物品ID, +1)
                      + TweenPopAnimation（拾取弹出动画）
  → ArrayRemove(存活敌人数组, 当前敌人)
  → IfThen(条件: ArraySize(存活敌人数组) == 0)
      → 触发下一波（RunRunner 调用波次生成 Runner）
```

这段逻辑里，你看到了：字典嵌套路径查表、ForEach 遍历掉落物、数组大小判断背包满、IfElse 双分支、字典数值自增记背包、Tween 动画做反馈、RunRunner 复用波次逻辑、ArrayRemove 维护存活列表、IfThen 判断全灭。这十来条指令组合出来的逻辑，换成 GDScript 至少三四十行。而它在 Fuse 里就是 Inspector 里一串可读的指令序列，每一条都能点开看参数、能加断点单步调试（调试是后面专门一篇的内容）。

这就是"可视化照样写出真实逻辑"的实证。它不是玩具，是能扛住中等复杂度游戏逻辑的表达系统。

## 九、几个要记牢的注意事项

`WhileLoop` 一定要确保循环条件最终会变 false，否则就是无限循环卡死游戏。不确定时优先用 `ForLoop`（有明确结束值）。

`BreakLoop` / `ContinueLoop` 只跳出最近一层循环。双层 ForLoop 里内层 break，外层还在继续。

`Wait` 是异步的，它后面的指令会等。但要注意，如果在等待期间触发器被禁用或节点被释放，等待中的逻辑可能不会跑完——做长时间序列时把这点考虑进去。

`ForEach` 遍历过程中如果用 `ArrayRemove` 删元素，索引会错乱。正确做法是先遍历收集要删的，遍历完再批量删，或者遍历时倒序删除。

数组原地排序（`ArrayNumericSort` / `ArrayVectorSort`）会改原数组。如果你想保留原顺序，先把原数组存一份到另一个变量。

## 十、下一篇：让画面动起来

逻辑骨架搭好了，分支循环数据结构都有了，但现在的游戏还是"会算、会判断、却不会动"。敌人攻击只有动画播放、没有受击震动；UI 弹窗只有显示隐藏、没有弹出缓动；拾取物品没有放大淡出的反馈。

**下一篇，我会讲 Fuse 的动画全家桶：AnimationPlayer 的播放/停止/混合/变速，6 个动画事件怎么驱动状态切换，以及 Tween 那 13 个预置动画和特效指令怎么打磨手感。** 到那一步，你的可视化逻辑就不仅能跑，还能"好看好动"了。
