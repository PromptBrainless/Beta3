> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/07-character-control-in-practice.md)

# 不写代码做出能跳能攀墙的角色:Fuse 输入与物理实战

看完这篇，你会把 Fuse 从"动画会播"推进到"角色真正受控"。在 Fuse 里用可视化砖块拼出一个响应键鼠、触摸、手柄三种输入，具备起跳、二段跳、攀墙、滑铲的 2D 平台角色，中间一行 `_process` 都不用写。

承接上一篇：动画系统让角色会做动作了，但一个只会原地做动作的角色不算角色——它得能跑、能跳、能贴着墙往上蹭。

## 先理清楚:输入事件是怎么"流"进逻辑的

很多刚接触可视化编程的人卡在第一步：按下一个键，到底是谁告诉角色"动"？在 Fuse 里，答案是**输入事件(Event)**。事件是 Trigger 的触发源，它一旦满足条件就会驱动挂在上面的指令(Instruction)链执行。

Fuse 的输入事件一共有十多个，覆盖了你能想到的所有输入设备。我们把它们按设备归一下类：

键盘用 `OnInputKey`(按键输入)，它支持三种触发时机：按下时、释放时、重复触发。鼠标这边分工更细：`OnMouseButton`(鼠标按键)管点击，`OnMouseMove`(鼠标移动)管轨迹，`OnMouseEnter`(鼠标进入)和 `OnMouseExit`(鼠标离开)专门针对 `Control` 这类 UI 节点做悬停检测。触摸设备有 `OnTouch`(触摸)和 `OnTouchSwipe`(触摸滑动)，后者支持配置 `min_distance`(最小滑动距离)和 `swipe_direction`(滑动方向)，做手游的左右翻页、滑动闪避很顺手。手柄则拆成 `OnGamepadButton`(游戏手柄按键)和 `OnGamepadAxis`(游戏手柄轴)，后者要设 `deadzone`(死区)阈值，避免摇杆回中时的误触发。

如果你不想被具体的物理按键绑死，还有一层抽象：`OnInputAction`(动作输入)走的是 Godot 原生的 Input Map 系统，你在项目设置里定义好 `jump`、`attack` 这些动作，再把键鼠手柄都映射进去，逻辑这边只认动作名，换设备零成本。要处理像 WASD 这种四向移动，直接用 `OnInputActionComposite`(复合输入动作)，它把上下左右四个动作打包，还自动支持对角线移动。

这里有个容易被忽略的点：输入事件触发时，会把按键码、位置、力度、方向这些数据塞进执行上下文(ExecutionContext)，后续指令可以直接取用。比如 `OnTouchSwipe` 触发后，指令链里能读到起始位置、结束位置、方向和距离——做"向右滑切换武器"这种逻辑，根本不用你自己算角度。

## 让角色动起来:三种移动模式怎么选

输入接好了，轮到角色怎么响应。对于 `CharacterBody2D` 这种物理角色，Fuse 提供了 `MoveCharacterBody2DComposite`(移动 CharacterBody2D(复合))这条核心指令。它接收四向输入，然后按你选的移动模式去更新角色速度。

这三种模式决定了角色的"手感"，值得展开说：

**DIRECT(直接设置速度)**。指令直接把 `velocity` 设成目标值，松手即停，没有任何惯性。网格移动、回合制、需要绝对精确响应的操作首选它。优点是跟手，缺点是机械。

**SMOOTH(平滑插值)**。用线性插值把当前速度平滑过渡到目标速度，过渡快慢由 `smooth_factor` 控制，值越大变化越快。休闲游戏、需要"丝滑"观感的场景用它，角色会有一点点滑行的余韵，但又不至于失控。

**ACCELERATION(加速度)**。这是最接近真实物理的一种，用 `acceleration`(加速度)和 `friction`(摩擦力)两个参数模拟加减速。起步有冲量感，急刹会滑一小段。平台跳跃、动作游戏强烈推荐这种，因为它天然带着"重量感"。

我们先搭一个能跑通的四向移动。前提：项目设置里定义好 `move_up`/`move_down`/`move_left`/`move_right` 四个 Input Map 动作，场景里有一个挂了 `CollisionShape2D` 的 `CharacterBody2D`。

在角色节点下加一个 Trigger，Event 选 `OnInputActionComposite`，四个方向动作名分别填进去，触发帧率(trigger_rate)选 60 FPS。然后给这个 Trigger 接一条 `MoveCharacterBody2DComposite` 指令：`target_node` 指向角色自身，`speed` 给 200，`move_mode` 选 DIRECT。运行场景，WASD 就能控制角色四向走，同时按两个方向还能斜着走。把 `move_mode` 换成 ACCELERATION，`acceleration` 给 1000、`friction` 给 800，角色立刻就有了滑步感——同一个角色，换个参数就是两种风格。

这里还有一个性能取舍：`OnInputActionComposite` 的 `trigger_rate` 决定了事件每秒触发多少次。60 FPS 最流畅但系统负载最高，30 FPS 是休闲游戏的平衡点，20 FPS 适合移动端，10 FPS 会有明显卡顿不推荐。角色主控这种需要精确响应的，别为了省性能降到 20 FPS。

## 物理条件七件套:让角色"知道"自己在哪

移动只是基础，真正让平台跳跃好玩的是角色对自己状态的感知：我在地上吗？贴墙了吗？在空中是上升还是下落？速度够不够触发冲刺？这些判断都靠物理条件(Condition)。Fuse 在 `conditions/physics/` 下提供了 7 个物理条件，我先给一张全景：

| 条件 | 中文名 | 底层判断 | 典型用途 |
|------|--------|----------|----------|
| `CheckOnFloor` | 在地面上 | `is_on_floor()` | 决定能否起跳 |
| `CheckOnWall` | 在墙壁上 | `is_on_wall()` | 攀墙、蹬墙跳 |
| `CheckInAir` | 在空中 | 不在地面也不在墙 | 二段跳、空中行为 |
| `CheckIsFalling` | 正在下落 | 垂直速度低于阈值 | 下落加速、展翅动画 |
| `CheckVelocity` | 速度检测 | 速度大小或分量 | 冲刺判定、超速反馈 |
| `CheckSlope` | 检查斜坡 | `get_floor_normal()` | 陡坡滑铲 |
| `CheckOverlapArea` | 检查区域重叠 | 重叠体/区域检测 | 站在岩浆上、触发陷阱 |

前三者回答"在哪"，中间两个回答"怎么动"，最后两个回答"和谁接触"。注意它们都依赖 `move_and_slide()` 的调用结果——也就是说角色必须在物理帧里真正移动过，这些判断才准确。`target_node` 指向的角色节点要确实是 `CharacterBody2D`/`CharacterBody3D`。

最容易搞混的是 `CheckInAir` 和 `CheckIsFalling`。在空中(`CheckInAir` 为真)不等于在下落——角色刚起跳、正在上升的那一段同样"在空中"。把两者结合，才能区分"上升中"和"下落中"两个状态，这对切换跳跃动画和下落动画很关键。`CheckIsFalling` 直接判断 `velocity.y > 0`(Godot 坐标系中 Y 轴向下为正，Y 速度大于 0 即下落)，没有额外的阈值参数。

`CheckVelocity` 很灵活，它比较的是速度大小(标量)，通过 `velocity_threshold`(速度阈值)和 `comparison_operator`(比较运算符)来配置。判断"是否在冲刺"就用 `comparison_operator` 选 `Greater Than`、`velocity_threshold` 给一个大值；判断"是否几乎静止"就用 `Less Than`、`velocity_threshold` 给一个很小的值。

## 实战:把跳跃、二段跳、攀墙、滑铲拼出来

理论够了，我们做一套真正能跑的。下面这套用一个 `OnPhysicsProcess`(物理帧处理)驱动，因为物理状态判断必须在物理帧里才有意义。

**1)基础跳跃**

起跳的前提是在地面。先放 `CheckOnFloor`，为真时再嵌一层 `CheckInputPressed`(按键按下)判断 `jump` 动作，两者都满足才执行跳。跳的实现是给角色一个向上的速度——可以用 `SetVelocity`(设置速度)直接改 Y 分量，也可以用 `ApplyImpulse`(施加冲量)给一个向上的冲量。

```
OnPhysicsProcess
└── CheckOnFloor  target_node: Player
    └── CheckInputPressed  action_name: "jump"
        └── SetVelocity  target_node: Player, velocity: (x, -500)
```

**2)二段跳**

二段跳是空中再跳一次，但不能无限跳。引入一个本地变量 `jumps_left` 记录剩余跳跃次数。落地时把它重置为 2，在空中按跳跃就消耗一次。

```
OnPhysicsProcess
├── CheckOnFloor  target_node: Player
│   └── SetVariable  target_variable_scope: LOCAL, target_variable: "jumps_left", new_value: 2
└── CheckInAir  target_node: Player
    └── CheckInputPressed  action_name: "jump"
        └── CheckVariable  variable_name: "jumps_left", comparison_operator: GREATER_THAN, expected_value: 0
            ├── SetVelocity  target_node: Player, velocity: (x, -450)
            └── AddVariable  variable_name: "jumps_left", add_value: -1
```

这里 `CheckInAir` 保证只有空中才进二段跳分支，`CheckVariable` 卡住次数。落地那段 `CheckOnFloor` 每帧把次数刷新回 2，角色一着地就满血复活跳跃能力。

**3)攀墙**

贴墙后按住攀爬键就往上走。`CheckOnWall` 判断是否贴墙，再叠加 `CheckInputHeld`(按键持续按住)判断 `climb` 动作。满足时停止水平移动，改用一个向上的速度或冲量。

```
OnPhysicsProcess
└── CheckOnWall  target_node: Player
    └── CheckInputHeld  action_name: "climb"
        └── SetVelocity  target_node: Player, velocity: (0, -120)
```

想让攀墙更细腻，可以再加 `CheckIsFalling` 区分"主动攀爬"和"贴墙下滑"，下滑时用更小的下落速度模拟摩擦。

**4)滑铲**

陡坡上按下方向键就进入滑铲。`CheckSlope` 的 `angle_degrees` 参数是度数，设 `compare_type` 为 `GREATER_EQUAL`、角度 45 度就触发。配合 `CheckOnFloor` 确保是站在地上，再用 `CheckInputHeld` 判断 `move_down`。

```
OnPhysicsProcess
└── CheckOnFloor  target_node: Player
    └── CheckSlope  target_node: Player, compare_type: GREATER_EQUAL, angle_degrees: 45.0
        └── CheckInputHeld  action_name: "move_down"
            └── (切换滑铲动画 + 调整碰撞体积)
```

把上面四段用 `CheckAll`/`CheckAny` 组合进同一个 `OnPhysicsProcess` Trigger，就是一个状态完整的平台角色。值得一提 `OnGroundStateChanged`(着地状态变化)这个物理事件——它在角色"离开地面"和"重新着地"的瞬间各触发一次，比每帧 `CheckOnFloor` 更省，做"起跳尘土特效""落地音效"这种一次性反馈非常合适。

这一篇我们让角色真正受控了：三种输入设备、三种移动模式、七种物理状态判断，组合出跳跃、二段跳、攀墙、滑铲。但一个能动会跳的角色，玩起来可能还是"干巴"——没有反馈。下一篇我们给游戏加满手感：UI、相机、音频三连击，让你的每一次操作都有看得见、听得着的回响。
