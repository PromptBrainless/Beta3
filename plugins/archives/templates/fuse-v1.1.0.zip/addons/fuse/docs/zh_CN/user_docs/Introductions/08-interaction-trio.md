> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/08-interaction-trio.md)

# 给游戏加满"手感":用 Fuse 搞定 UI、相机与音频反馈

上一篇角色能跳能攀墙了，但你大概已经发现：角色动作全对，玩起来就是不够"爽"。问题不在角色，在反馈。一次攻击命中，血条没动、镜头没震、没有音效——再精致的逻辑都像隔着玻璃。这篇解决的就是手感：用 Fuse 的 UI、相机、音频三套指令，让玩家的每一个操作都有看得见、听得着的回响。读完你能搭出"受击瞬间血条扣减+镜头震动+音效炸裂"这种三连反馈，全程可视化。

承接上一篇：角色能动会跳了，但动作全对、玩起来就是不够爽——缺的是反馈。

## UI 反馈:让画面上的数字会自己动

UI 是反馈最直接的载体。Fuse 的 UI 指令一共 6 条，核心是这 4 条：`SetUIText`(设置 UI 文本)、`SetUITexture`(设置 UI 纹理)、`SetUIProgress`(设置 UI 进度)、`ShowHideUI`(显示/隐藏 UI)。

`SetUIText` 负责文本，支持 Label、RichTextLabel、Button、LineEdit 这些带 `text` 属性的控件。它有个关键设计：文本既可以写死，也可以从变量读(`use_variable = true`)。做分数显示就靠这个——把分数存进变量，每次变化用 `SetUIText` 刷新到 Label，文本里还能用表达式做格式化，比如 `分数:{local:score}` 自动插值。

`SetUIProgress` 专门伺候 ProgressBar，填一个 0.0 到 1.0 的进度值。血条、加载条、技能充能都靠它。同样支持从变量读，血量一变，血条平滑跟着变。`SetUITexture` 管 TextureRect 的贴图，来源可以是文件路径也可以是变量，做"武器图标随装备切换""表情切换"这种很方便。`ShowHideUI` 控制可见性，有 SHOW、HIDE、TOGGLE 三种动作，TOGGLE 一个暂停菜单的开合就够了。

光有指令还不够，你得知道 UI 啥时候该变。Fuse 给了 7 个 UI 事件，最常用的是这几个：`OnButtonPressed`(按钮按下)监听点击；`OnValueChanged`(值改变)监听 Slider/SpinBox/ProgressBar，而且它有阈值模式，可以只在"达到某个值""到达最大值"时才触发，不用每帧判断；`OnTextChanged`(文本改变)监听输入框，同样有"为空""达到最大长度""匹配正则"等触发模式，做表单校验很好用；`OnItemSelected`(ItemList 选中项改变)管列表选择；`OnFocus`(焦点变化)管控件获得/失去焦点。

一个最小可跑的血条案例：假设你已经有一个全局变量 `hp_ratio` 存着血量比例(0~1)。在角色身上放一个 Trigger，Event 用 `OnHealthChanged`(生命值变化)，触发后接一条 `SetUIProgress`，`target_node` 指向血条 ProgressBar，`use_variable = true`，`value_variable` 填 `hp_ratio`。角色每次掉血，血条自动跟着缩。再把分数的 `SetUIText` 也接进去，一个掉血+扣分的 HUD 就成型了。

## 相机反馈:让镜头替你表达情绪

相机是玩家唯一的眼睛，而镜头语言本身就是反馈。Fuse 的相机指令 7 条，这篇聚焦 4 个最出效果的：`CameraFollow`(相机跟随)、`CameraShake`(相机抖动)、`SetCameraZoom`(设置相机缩放)、`SetCameraLimit`(设置相机边界)。

`CameraFollow` 是横版游戏的基石，有三种跟随模式。LOCK 是硬切，相机瞬间锁定目标，适合俯视角的精确同步；SMOOTH 用 `smooth_speed` 控制追踪速度，镜头会稍微"追"一下角色，最常用；DAMPED 用物理阻尼实现自然减速，镜头停下前会有个柔和的收尾。游戏开始时设一次就行：

```
OnReady
└── CameraFollow  target_node: Player, camera_node: Camera2D, follow_mode: Smooth, smooth_speed: 8.0
```

`CameraShake` 是手感的核心，而且它是异步指令——会在抖动持续时间内一直占着，结束后才标记完成，所以它天然适合"受击瞬间"这种短促反馈。`intensity`(强度 0~1)配 `duration`(秒数)，受击给 0.8 强度 0.3 秒，爆炸给 1.0 强度 0.5 秒，感觉完全不同。

`SetCameraZoom` 支持直接给值或从变量读，做"冲刺时镜头拉远""瞄准时拉近"这种效果很顺手。`SetCameraLimit` 限制相机不超出关卡边界，`limit_value` 设 -9999 表示该方向不限。一个横版关卡，四条 `SetCameraLimit` 分别锁住上下左右，镜头就不会把关卡外的空背景摇出来。

相机指令不止这些，`CameraFadeIn`(摄像机淡入)和 `CameraFadeOut`(摄像机淡出)做黑屏过渡、过场切换很标准，配合下一篇要讲的事件系统，能搭出"场景切换→淡出→加载完成→淡入"的完整流程。

## 音频反馈:让耳朵参与判断

声音是手感的最后一块拼图，而且往往是玩家下意识判断"有没有打中"的依据。Fuse 的音频指令 7 条，这篇用 4 个：`PlaySound`(播放音效)、`PlayMusic`(播放音乐)、`CrossfadeToMusic`(交叉淡入淡出音乐)、外加节奏事件 `OnMusicBeat`(音乐节拍)。

`PlaySound` 播一次性音效，自动创建一个 `AudioStreamPlayer`，播完自动清理，不用你管内存。它有 `volume`、`pitch_scale`、`bus` 三个参数，`pitch_scale` 很有用——给受击音效加一点随机扰动(比如 0.95~1.05)，连击就不会听腻。命名格式是 `Fuse_AudioPlayer_<随机数>`，方便其它指令按名称模式定位。

`PlayMusic` 播背景音乐，是异步指令，支持淡入(`fade_in` + `fade_duration`)。换场景换音乐别用直接切，用 `CrossfadeToMusic`——它会自动找到当前在播的 `Fuse_MusicPlayer*`，做一段交叉淡入淡出，听感平滑没有断点。

```
OnSceneLoaded
└── CrossfadeToMusic  music_path: "res://audio/level2_bgm.ogg", volume: 0.8, crossfade_duration: 3.0
```

最特别的是 `OnMusicBeat`(音乐节拍)。它按你设定的 BPM 定时触发，适合做节奏游戏或者"踩着鼓点生成敌人""每拍闪一下画面"这类音乐可视化。`beat_interval` 控制多久触发一次：1 是每拍，2 是每两拍，4 是每小节。触发后会把 `beat_count`(节拍计数)、`bpm`、`elapsed_time` 传给指令链，你可以用节拍计数来驱动整个游戏的节奏。

## 三连击主线:一次受击，三路同时反馈

把上面三套揉在一起，做一个"角色受击"的完整反馈链。设定：角色有一个 `hp` 变量，受击时减少。我们要让血条缩、镜头震、音效响，三件事同时发生。

拆成三个 Trigger，各自监听同一个触发源，互不阻塞：

Trigger 1(血条)：Event 用 `OnHealthChanged`，指令接 `SetUIProgress` 把新血量比例刷到血条，再叠一条 `SetUIColor` 把血条瞬间染红再用 Tween 缓回，强调"受伤"。

```
OnHealthChanged
├── SetUIProgress  target_node: HPBar, use_variable: true, value_variable: hp_ratio
└── (Tween 颜色:红 → 白，强调受击)
```

Trigger 2(镜头)：同样用 `OnHealthChanged`，接 `CameraShake`，强度按伤害量缩放。

```
OnHealthChanged
└── CameraShake  target_node: Camera2D, intensity: 0.8, duration: 0.3
```

Trigger 3(音效)：同样 `OnHealthChanged`，接 `PlaySound` 播放受击音，`pitch_scale` 加一点随机让连击不腻。

```
OnHealthChanged
└── PlaySound  sound_path: "res://audio/hit.wav", pitch_scale: 0.97~1.03 随机
```

三个 Trigger 监听同一事件、各干各的，这正是可视化编程的解耦优势——你想加第四路反馈(比如粒子特效)，再挂一个 Trigger 就行，完全不用动前三条。这种"一个触发源、多路响应"的模式，背后其实是 Fuse 的事件机制在支撑。下一篇我们就把"事件"这件事彻底讲透：从节点的生命周期、各种时序事件，到跨场景通信的 Event Bus，看 Fuse 怎么把"触发"做到既强大又可控。
