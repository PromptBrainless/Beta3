> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/09-event-system-complete.md)

# 把"触发"讲透:Fuse 的生命周期、时序事件与 Event Bus

前八篇我们用了无数次"事件"这个词：输入事件、物理事件、UI 事件、动画事件。但你可能一直没机会系统看一眼：Fuse 的事件到底分几类、各自什么脾气、什么时候该用哪个。这篇就来填这个坑，而且会重点落在 Fuse 最具差异化的 Event Bus 上——它不只是"又一个事件类型"，而是让逻辑真正解耦、能跨场景通信的关键设计。读完你会清楚每一种触发该配什么事件，以及怎么用事件总线把原本纠缠在一起的系统拆成互不依赖的模块。

承接上一篇：事件已经用了很多次了，但从未系统看过全貌。

## 先建立全局观:四类事件各管一摊

Fuse 的事件源码分布在 `events/` 下若干子目录，按职责可以归成四大类。

**生命周期事件**：绑定在节点的生命周期回调上，回答"这个节点什么时候出生、什么时候每帧跑、什么时候死"。包括 `OnReady`、`OnEnterTree`、`OnExitTree`、`OnProcess`、`OnPhysicsProcess`、`OnInterval`、`OnIntervalWithVariable`。它们是逻辑的"心跳"。

**时序事件**：和时间打交道，回答"多久之后做一次""冷却好了没""还剩多少秒"。包括 `OnTimer`、`OnCooldownFinished`、`OnCountdown`、`OnRealtime`。它们管的是节奏和冷却。

**节点事件**：监听节点状态变化或信号，回答"这个属性变了没""这个信号发出了没""这个场景被实例化了没"。包括 `OnPropertyChanged`、`OnTargetSignalEmit`、`OnSignalFromGroup`、`OnNodeInstance`。它们把 Godot 原生的信号系统接进了可视化逻辑。

**Event Bus**：Fuse 自有的全局事件总线，跨 Trigger、跨场景通信，是这套系统真正的护城河。下面逐类展开，Event Bus 单独重笔墨。

## 生命周期事件:别让 OnProcess 拖垮你的帧率

生命周期事件里，最该先搞清楚的是"触发频率"。同样是周期性触发，代价天差地别。

一次性触发的有三个，都很廉价。`OnReady` 对应 `_ready()`，场景树就绪后触发一次，是做初始化的标准入口：设初始血量、绑定信号、加载配置、生成 HUD 都放这里。它还有个 `delay_seconds` 参数，可以延迟触发，留一帧给其它节点先就绪。`OnEnterTree` 比 `OnReady` 更早，在节点刚进入场景树时就触发，此时父节点可能还没就绪，所以大多数初始化还是该用 `OnReady`，`OnEnterTree` 留给特殊场景。`OnExitTree` 对应节点退出场景树，是做清理的标准入口：保存进度、断开信号、释放资源。

危险的是两个帧循环事件。`OnProcess` 对应 `_process(delta)`，**每帧**都触发，文档直接给了性能警告。只要你往上面挂一条稍微复杂的指令链，帧率就会肉眼可见地掉。它必须配 `execution_interval` 降频——默认 0.016(约 60 FPS)，你至少该设到 0.1(每秒最多 10 次)。`OnPhysicsProcess` 对应 `_physics_process`，固定频率(默认 60 FPS)，只该用在物理相关的更新上，比如上一篇的角色移动。

这里有个很实在的建议：**绝大多数"持续检测"根本不该用 `OnProcess`，而该用 `OnInterval`**。`OnInterval` 按固定秒数周期触发，`interval_seconds` 你说了算，比 `OnProcess` 可控得多、性能也好得多。比如"每 2 秒扫描一次附近敌人"，用 `OnProcess` 是每帧扫 60 次(浪费)，用 `OnInterval` 设 2.0 就是每 2 秒一次(精准)。

```
OnInterval  interval_seconds: 2.0, max_repeats: 0
└── CheckDistance  target_a: Player, target_b: Enemy, operator: LESS_THAN, value: 10.0
    └── (敌人接近，触发战斗)
```

`OnIntervalWithVariable` 是 `OnInterval` 的进阶版，间隔值从变量动态读取，运行时可变。做"难度递增，敌人刷新越来越快"这种，把间隔变量越改越小就行，不用重写逻辑。

文档给了一份很实用的性能分级，值得记住：`OnReady`/`OnEnterTree`/`OnExitTree` 是低，随便用；`OnInterval`/`OnIntervalWithVariable` 是中，注意间隔别小于 0.033 秒；`OnProcess`/`OnPhysicsProcess` 是高，必须降频、且只在别无选择时用。

## 时序事件:四把不同的"时钟"

时序事件四个，本质区别在"用什么时间尺度"和"触发模式"。

`OnTimer` 等同于 Godot 的 `Timer` 节点，按 `wait_time` 周期触发，`repeat_count` 为 0 是无限循环。做"每 10 秒刷一波怪"这种周期任务最直接。它受游戏时间影响——也就是说，游戏暂停它就停。

`OnCooldownFinished` 专门做技能冷却。它的精髓在 `manual_trigger` 参数：设成 true 后，冷却不会自动重启，而是等你手动触发一次，这才开始走冷却、走完再通知你"好了"。配合 `CheckCountdownFinished`(倒计时结束)这个条件判断冷却状态，能搭出"技能冷却中按了没反应，冷却好了一按就放"的标准技能系统。它还有个 `show_progress` 选项，会往变量里写一个 0.0 到 1.0 的冷却进度，UI 上画冷却环直接读这个值。

`OnCountdown` 是倒计时，在指定时长内持续触发，`update_interval` 控制更新频率。它会把剩余时间写进一个变量，做限时关卡、屏幕上的倒计时数字直接读这个变量刷新就行。

`OnRealtime` 是这四个里最特殊的：它基于**现实时间**，不受 `time_scale` 和暂停影响。游戏暂停了它照样走。所以它只适合"每日任务刷新""离线奖励计算""防作弊计时"这类和现实挂钩的需求，**绝不要**拿它做游戏内逻辑——你一暂停游戏，角色跳跃冷却还在走，体验会很诡异。

| 维度 | OnTimer | OnCooldownFinished | OnCountdown | OnRealtime |
|------|---------|--------------------|-------------|------------|
| 时间尺度 | 游戏时间 | 游戏时间 | 游戏时间 | 现实时间 |
| 受暂停影响 | 是 | 是 | 是 | 否 |
| 触发模式 | 周期/单次 | 冷却结束瞬间 | 持续更新 | 周期 |
| 典型场景 | 刷怪 | 技能冷却 | 限时关卡 | 每日刷新 |

## 节点事件:把 Godot 信号接进可视化

节点事件四个，处理的是"节点层面的状态变化和信号"，其中两个细节容易踩坑。

`OnPropertyChanged`(属性变化)监听目标节点某个属性的变化，比如血量、位置。但它用的是**轮询模式**，按 `check_interval` 定期检查属性值，不是真正的信号绑定。这意味着响应有延迟(最长等于检查间隔)，高频变化的属性得把间隔压到 0.05 秒以下。它的好处是不需要目标节点提前声明信号，任何属性都能监听。

`OnTargetSignalEmit`(目标信号发出)监听特定节点的特定信号，是真正的信号绑定，零延迟。而且编辑器有集成：选了目标节点后，信号下拉框会自动缓存该节点所有可用信号，不用手打名字。`trigger_once` 能让它只响应一次，`filter_signal_args` 还能按信号参数值过滤——比如只想在 `health_changed` 信号带着"扣血"参数时才响应。监听按钮点击用它配 `pressed` 信号是最稳的。

`OnSignalFromGroup`(组信号监听)是 `OnTargetSignalEmit` 的批量版：监听某个组里**任意**节点发出的指定信号。做"敌人组里随便哪个死了都加分"这种逻辑，一条事件搞定，不用给每个敌人单独挂监听。注意组名区分大小写。

`OnNodeInstance`(节点实例化)在指定场景被实例化时触发，做"Boss 房间加载完成就初始化 Boss 血量""预加载场景就绪就执行后续"很合适。匹配靠场景路径，要和实例化时用的路径完全一致(含 `.tscn`)。

这四个节点事件已经很强，但它们都局限在"同一个场景树内"。一旦你要让场景 A 通知场景 B、或者让一个全局系统响应任意模块的某个状态变化，它们就力不从心了。这时候轮到 Event Bus 登场。

## Event Bus:Fuse 的护城河

Event Bus 是 Fuse 最值得多花笔墨的部分，因为它是这套可视化系统区别于"把脚本翻译成节点"的关键设计。它是一个全局的事件总线，任何 Trigger 都能往上面发事件，任何 Trigger 也都能从上面接事件，发送方和接收方互不认识、互不依赖。

**基本模型**像广播电台。`SendEvent`(发送事件)是电台，`OnReceiveEvent`(接收事件)是收音机，事件名是频道。发送方只管喊一声 `"player_died"`，所有调到这个频道的接收方 Trigger 各自响应。发送方完全不知道、也不需要知道有谁在听——这就是松耦合的本质。

```
Trigger A (玩家系统)             Trigger B (游戏结束 UI)        Trigger C (敌人 AI)
  SendEvent "player_died"   →   OnReceiveEvent "player_died"   OnReceiveEvent "player_died"
                                   显示 GameOver UI               停止所有敌人
```

这种设计的直接收益是：你想新增一个对"玩家死亡"的响应，只管再加一个监听 `"player_died"` 的 Trigger，玩家的发送逻辑一行都不用改。系统越复杂，这种解耦的价值越大。

**带参数通信**是 Event Bus 的第二层能力。`SendEvent` 的 `Event Args` 是个字典，可以塞任意数据；接收方开启 `Store Args to Local` 后，这些参数会自动存成局部变量，前缀默认是 `event_`。比如发送 `{"item_id": "sword", "count": 1}`，接收方指令链里就能直接用 `event_item_id`、`event_count`。跨模块传数据就这么干净，不用共享全局变量。

**一次性事件**用 `Trigger Once` 选项。游戏首次启动的教程、首通成就这类"只该触发一次"的逻辑，开这个开关就免去了你自己管"是不是已经触发过"的状态变量。

**延迟发送**用 `Deferred` 选项。它把事件推迟到帧末尾发送，避免同一帧内大量事件堆叠，做密集广播时能平滑负载。

**命名规范**是 Event Bus 用得好的关键，文档给了明确建议：用模块前缀加点号分隔，比如 `player:died`、`quest:completed`、`ui:refresh`、`scene:loaded`。避免 `died`(太模糊)、`event1`(无意义)、`playerDied`(风格不统一)这种命名。一套清晰的命名规范，本身就是最好的文档——看到事件名就知道是哪个模块、什么性质的事。

**调试历史**是 Event Bus 一个很贴心的工程化设计。总线节点 `FuseEventBus` 会记录最近 100 个事件的历史，包含事件名、参数和时间戳。事件"没被接收到"时，这是排查的第一现场：在场景树里找到 `FuseEventBus`，看 `event_history`，确认事件到底发出去没有、参数对不对。这比在几十个 Trigger 里大海捞针快得多。

我们做一个能跑的跨场景通信案例。场景：玩家在战斗场景死亡，要通知主菜单系统弹出结算。两个 Trigger 分属不同场景，靠 Event Bus 牵线。

发送端(战斗场景，挂在玩家 Trigger 上)：

```
OnHealthChanged  (血量归零时)
└── SendEvent  event_name: "player:died", event_args: {"score": "{local:score}"}, deferred: true
```

接收端(结算 UI，可以挂在任意场景的根节点上，只要它活着)：

```
OnReceiveEvent  event_name: "player:died", trigger_once: false, store_args_to_local: true
├── SetUIText  target_node: ScoreLabel, text: "本局得分:{local:event_score}"
└── ShowHideUI  target_node: ResultPanel, action: SHOW
```

发送端用 `player:died` 这个规范命名，带着 `score` 参数；接收端开启 `Store Args to Local`，直接拿到 `event_score` 用。两边都不需要互相持有引用，甚至不在同一个场景。这就是 Event Bus 的威力——它把"谁触发的"和"谁响应的"彻底切开。

最后给一张通信方式的选型对比，帮你在不同需求下做选择：

| 方式 | 适用场景 | 复杂度 |
|------|----------|--------|
| Event Bus | 跨 Trigger、跨场景、全局事件 | 低 |
| `OnTargetSignalEmit` | 监听某个具体节点的信号 | 低 |
| `OnSignalFromGroup` | 监听一组同类节点的信号 | 中 |
| 全局变量 + 轮询 | 单向状态同步 | 高 |

原则很简单：能解耦就别耦合。同一场景内、一对一的监听，用 `OnTargetSignalEmit` 就够；一对多或跨组，用 `OnSignalFromGroup`；一旦涉及跨场景或者你想让模块真正独立演进，上 Event Bus。

这篇我们把"触发"这件事从底层到顶层走了一遍：生命周期管心跳、时序管节奏、节点事件对接 Godot 信号、Event Bus 打通全局。事件负责"什么时候做"，但很多时候你还需要判断"满足什么条件才做"——比如跳跃前先确认在不在地面。下一篇我们就正式进入条件系统，把 `CheckAll`/`CheckAny`/`CheckNot` 这套复合判断，以及距离、时间、表达式等各类条件彻底讲清，让逻辑真正会"思考"。
