> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/11-scene-and-node-management.md)

# 场景切换、后台加载、节点增删改：Fuse 管好你的游戏世界

上一篇我们给 Trigger 装上了"大脑"——条件系统负责判断"要不要做"。但判断只是准备，真正改变游戏世界的还得靠"动手"：玩家通关了要切到下一关，Boss 倒下了要在原地爆出一堆掉落物，UI 菜单要从屏幕外滑进来。这些操作背后都是同一类问题：怎么在运行时管理场景和节点。看完这篇，你能用 Fuse 的 6 个场景管理指令和 22 个节点操作指令，把整个游戏世界安排得明明白白——从流畅的关卡切换、不卡顿的后台加载，到运行时动态生成敌人、批量改属性、跨节点通信，全程不写一行代码。

## 场景管理：6 个指令撑起完整链路

先看场景管理这一组，共 6 个指令，覆盖了场景操作的全部链路：

- **ChangeScene**（切换场景）：跳到新场景，支持延迟。
- **ReloadScene**（重载场景）：重新加载当前场景，用于重试。
- **GetScenePath**（获取场景路径）：拿到当前场景文件路径或根节点路径，存进变量。
- **AddSceneAsChild**（添加场景为子节点）：实例化一个场景挂到指定父节点下。
- **PreloadSceneInstruction**（预加载场景）：后台异步加载，输出加载状态。
- **LoadSceneBackground**（后台加载场景）：异步加载，直接把 PackedScene 存进变量。

基础切换最常用的是 `ChangeScene` 和 `ReloadScene`。两个指令都带 `delay` 参数，方便配合淡入淡出动画。`ChangeScene` 是异步指令，设了 delay 后会等倒计时走完才完成。

`GetScenePath` 看起来不起眼，却是存档系统的基石。有两种模式：Current Scene File Path 返回 `"res://scenes/level_01.tscn"`，Root Node Path 返回 `"/root/Level_01"`。做存档时把文件路径存进 GLOBAL 变量，读档时再交给 `ChangeScene` 切回去，完整的关卡续传逻辑就搭起来了。

`AddSceneAsChild` 解决"运行时把一个现成的场景塞进当前场景树"。生成敌人、放特效、动态加 UI 面板，都用它。

## 预加载：让大场景不再卡顿

`PreloadSceneInstruction` 走的是 `ResourceLoader.load_threaded_request()`，输出加载状态字符串：`NOT_LOADED`、`LOADING`、`LOADED`、`FAILED`、`TIMEOUT`。有 Async Now（阻塞等待）和 Async Later（不阻塞立即返回）两种模式。

`LoadSceneBackground` 走另一条路——直接把加载好的 PackedScene 资源存进变量。

预加载标准四步流程：

第一步，**开始预加载**。在玩家进入战斗区域前，用 `PreloadSceneInstruction` 启动 Async Later 模式加载 Boss 场景。

第二步，**轮询检查状态**。`OnInterval` 配合 `CheckPreloadStatus` 检查是否 LOADED。

第三步，**加载完成后实例化或切换**。用 `AddSceneAsChild` 或 `ChangeScene` 正式使用，几乎零延迟。

第四步，**处理超时和失败**。TIMEOUT 或 FAILED 时走兜底分支。

## 节点操作：22 个指令，7 个分类

场景管的是大颗粒，节点操作管的是细颗粒。Fuse 的节点操作指令共 22 个，分 7 类：

场景实例化（3 个）：`InstantiateScene`、`RecyclePooledScene`、`WarmUpPool`。节点查找与枚举（8 个）：`FindNode`、`GetNode`、`GetAllChildren`、`GetAllChildrenPosition`、`GetChildByIndex`、`GetLastChild`、`GetRandomChild`、`GetChildCount`。组操作（2 个）：`GetNodesInGroup`、`GetGroupCount`。节点生命周期（3 个）：`CloneNode`、`QueueFreeNode`、`ReparentNode`。节点属性（3 个）：`SetPropertyValue`、`SetGlobalPosition`、`SetProcessMode`。节点控制（2 个）：`EnableDisableNode`、`EmitSignal`。高级操作（1 个）：`RunTargetNodeFunction`。

`FindNode` 是最灵活的查找指令，支持三种搜索维度（按名称 BY_NAME、按类型 BY_TYPE、按组 BY_GROUP）和三种范围（子节点 CHILDREN、当前场景 SCENE、全场景树 GLOBAL）。

## 节点通信：EmitSignal 与 RunTargetNodeFunction

`EmitSignal` 在指定节点上发射信号，是松耦合的通信方式——只管喊一声，谁监听谁响应。

`RunTargetNodeFunction` 是紧耦合的直接调用——在目标节点上动态调用指定方法，支持传参和捕获返回值。

要广播用 `EmitSignal`，要直接调用某个具体方法用 `RunTargetNodeFunction`。

## 实战：敌人波次生成器

一个能跑通的综合案例：每隔 3 秒生成一只敌人，预加载避免卡顿。

第一步，`OnReady` 执行 `PreloadSceneInstruction` 后台加载敌人场景。第二步，`OnInterval`（3 秒）配合 `CheckPreloadStatus` 检查加载完成。第三步，`GetRandomPointInRange` 算随机位置。第四步，`InstantiateScene` 实例化敌人。

## 几个容易踩的坑

`scene_path` 必须用 `res://` 协议完整路径。`ChangeScene` 会销毁当前场景树，切换前存好全局变量。

`AddSceneAsChild` 的 `target_parent` 是相对路径不是绝对路径。

`PreloadSceneInstruction` 的 `scene_path` 和 `status_variable` 必须和启动时完全一致。

`QueueFreeNode` 延迟到帧结束释放，同一帧内释放后别引用。组名区分大小写。

## 小结

场景和节点是游戏世界的物理载体。Fuse 用 6 个场景管理指令 + 22 个节点操作指令覆盖了日常需求。但有个问题迟早会冒出来——自定义节点方法怎么变成可视化指令？靠 `RunTargetNodeFunction` 临时调用是一回事，沉淀成可复用指令是另一回事。下一篇就讲指令生成器，看你自己的节点方法如何一键变成指令库的正式成员。
