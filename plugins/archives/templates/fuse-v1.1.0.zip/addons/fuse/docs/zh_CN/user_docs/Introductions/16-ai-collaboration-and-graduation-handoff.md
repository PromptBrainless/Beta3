> 🌐 中文 | [**English**](../../../en_US/user_docs/Introductions/16-ai-collaboration-and-graduation-handoff.md)

# AI 协作与毕业交接：把"原型在 Fuse 里验完"变成"工程代码离桥而生"

前面 15 篇讲的都是"手搭"这条腿：怎么拖砖块、怎么调变量、怎么调试和审查。这一篇讲另一条腿——也是 Fuse 与其他可视化编程插件拉开差距的地方：**AI 可以直接生成 Fuse 的逻辑配置，调稳的系统可以"毕业"成脱离 Fuse 的工程代码，而且全程非破坏、可回滚。**如果你是带着"会不会被可视化工具套牢"的疑虑读到这里 的，这篇就是答案。

## 一、为什么"能毕业"比"能搭"更重要

可视化脚本系统最常被团队拒绝采用的理由，不是表达力不够，而是"套牢焦虑"：逻辑进了插件，人就出不来了——想优化得等插件更新，想交给程序重写得从零翻译，项目大了想迁移更是噩梦。

Fuse 对这个问题的回答分两层。**入口层**：AI 生成的逻辑配置是带 schema 的 JSON，不是黑盒——机器可读、可静态校验、可版本管理。**出口层**：任何调稳的系统都能导出为结构化交接工件（系统划分、行为规格、组件契约），交给工程侧的 AI agent 直接编写脱离 Fuse 运行时的代码。进去有校验、出来有工件，这条桥双向都安全。

## 二、Preset AI 生成闭环：让 AI 直接写逻辑

第 15 篇讲过 preset（预设）怎么让逻辑像积木一样跨项目搬运。这里补上 AI 这一环：Fuse 把全部 310 个组件的"使用说明书"dump 成三个 JSON，放在 `addons/fuse/preset_ai_context/` 下——

- **components.json**：组件清单（每个 Event / Instruction / Condition 的类型名、分类、关键词）；
- **schemas.json**：参数结构，含条件注册的动态参数及其 `requires` 门控（选了某个枚举值才解锁下一级参数，逐级嵌套）；
- **enums.json**：全部枚举取值。

实操流程非常短。把这三个 JSON 喂给你的 AI agent，说清楚要什么——比如"生成一个受击无敌帧 preset：`OnCooldownFinished` 事件驱动，把 `invincible` 变量置回 false"。AI 按 schema 产出一份 JSON；然后跑离线校验器把关：

```bash
Godot --headless --path . res://addons/fuse/editor/preset_ai/validate_preset.tscn -- <preset.json>
# 退出码：0 = 无 error；1 = 有 error finding
```

校验器做四层规则检查（结构、组件引用、参数类型、语义约束），有 error 退出码非 0——这意味着它可以直接接进 CI 或脚本做门禁。校验通过导入即用，参数在 Inspector 里继续人工微调。**AI 出结构，人出手感**，分工干净。

## 三、拓扑导出：把场景变成结构化事实

毕业的第一步，是把"场景里到底有哪些逻辑单元、它们怎么关联"变成机器可读的事实。这就是第 14 篇 Topology 主屏的 CLI 版本：

```bash
Godot --headless --path . res://addons/fuse/editor/topology/export_topology.tscn -- --scene res://<你的场景>.tscn
```

产物是一份拓扑 JSON（文件名 = 场景文件名）：全场景的 Trigger / MultiEventTrigger / Runner 单元，以及跨单元关联——事件引用、RunRunner 调用链、变量读写、信号收发，还有竞态预警和源场景溯源字段。14 篇在面板里看到的箭头和连线，这里全部落成结构化数据。

## 四、System 工件：从拓扑到系统划分

有了拓扑，下一步是把它切成交接友好的"系统"。derive CLI 会按 Trigger / MultiEventTrigger 单元推导出 System 草稿：

```bash
# 推导草稿（草稿目录默认不进 git）
Godot --headless --path . res://addons/fuse/editor/graduation/derive_systems.tscn -- --scene res://<你的场景>.tscn

# 人工确认草稿（补 description、确认警告清单）后离线校验
Godot --headless --path . res://addons/fuse/editor/graduation/validate_system.tscn -- <system.json>
```

推导会同时落盘一份 `_derive_report.json`（跳过项 / 组件清单 / 分单元警告），人工确认就是把这份报告里的问题逐条过掉。validate 内置 `topology_digest` 漂移检测——场景改了、工件没更新，校验直接报 error，防止拿着过期规格写代码。

## 五、一键交接打包：handoff bundle

到这一步你手里有拓扑 JSON、System JSON、preset JSON——但真要交给一个 AI agent 写代码，还得回答它的一连串问题：这些组件的语义是什么？怎么验收写对了？基建（事件总线、全局状态、对象池）从哪来？**fuse-handoff-packer skill** 把这些一次性打包齐：

它随插件分发（`addons/fuse/agent_skills/fuse-handoff-packer/SKILL.md`），工具中立——任何能读文件的 AI agent 都能执行。它与你交互确认"毕业哪个系统、需要哪些模板"后，产出 `fuse_generated/handoff/<系统名>/` 自包含交接包，八件产物：

| 产物 | 干什么 |
|------|--------|
| `system.json` | 系统划分定稿（含确认过的警告清单） |
| `topology.json` | 场景拓扑快照 |
| `presets/` | 行为规格——该系统涉及的 preset |
| `semantics.md` | 语义契约——涉及组件的行为约定 |
| `README-for-agent.md` | 给接手 AI agent 的导读 |
| `acceptance.md` | 验收清单——写完怎么证明没写错 |
| `components.json` | 涉及组件的 schema 摘录 |
| `templates/` | 基建模板：事件总线 / 全局状态 / 对象池 |

仓库里有一份金样例可以走查：`fuse_generated/handoff/game_flow/`——一个游戏主流程系统的完整交接包，八件产物齐备，拿它喂给任何一个 AI agent 都能直接开工。

## 六、出口边界：主线与实验

毕业工具有两条出口，定位不同：**derive / validate + handoff 打包是主线**——Fuse 供给结构化事实，工程代码由你的 AI agent 编写，彻底脱离 Fuse 运行时。另一条 `export_system` CLI 能直接生成 GDScript（白名单指令原生直译、其余委托执行的混合模式），但它目前是**实验特性**——生成代码仍依赖 Fuse 运行时，只作为参考实现保留，不是推荐出口。

## 七、非破坏性承诺

最后把这条腿的安全保证说全：交接包产出的那一刻，**Fuse 侧什么都没变**——源 Trigger 原地不动继续跑，不写代码的同事留在运行时里调参；工程代码在别处长出来、跑通、替换上线之前，桥一直都在；哪天想回滚，删掉生成的代码回到纯 Fuse 运行时即可，零迁移成本。毕业不是告别，是多了选择。

## 系列完结

十六篇走完：入门三篇上手，核心八篇筑基，护城河三篇进阶，这一篇收官。Fuse 的完整故事是一条链：**砖块模型管表达，变量与表达式管数据，流程与数据结构管逻辑，动画物理 UI 管表现，调试与 Topology 管质量，工程化四件套管生产，preset 闭环管 AI 协作，交接工件管毕业**。从"策划拖出第一个 Hello World"到"工程团队的 AI agent 接走整个系统"，中间没有断点——这就是"非破坏性桥梁"的全部含义。
