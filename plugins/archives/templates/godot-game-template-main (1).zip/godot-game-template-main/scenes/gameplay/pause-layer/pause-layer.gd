extends CanvasLayer

@export var settings_menu: PanelContainer
@export var margin_container: MarginContainer

@onready var pause := self
@onready var pause_button := $MarginContainer/Control/PauseButton
@onready var resume_option := $MarginContainer/Control/VBoxOptions/Resume
@onready var label = $MarginContainer/Control/Label
@onready var pause_options = $MarginContainer/Control/VBoxOptions
@onready var color_rect = $ColorRect

@onready var nodes_grp1 = [pause_button, label] # should be visible during gamemplay and hidden during pause
@onready var nodes_grp2 = [pause_options, color_rect] # should be visible only in pause menu


func _ready():
	pause_hide()


func pause_show():
	for n in nodes_grp1:
		n.hide()
	for n in nodes_grp2:
		n.show()


func pause_hide():
	for n in nodes_grp1:
		if n:
			n.show()
	for n in nodes_grp2:
		if n:
			n.hide()
	settings_menu.hide()


func _unhandled_input(event):
	if event.is_action_pressed("pause"):
		if settings_menu.visible:
			return
		if get_tree().paused:
			resume()
		else:
			pause_game()
		get_viewport().set_input_as_handled()


func resume():
	get_tree().paused = false
	pause_hide()


func pause_game():
	resume_option.grab_focus()
	get_tree().paused = true
	pause_show()


func _on_Resume_pressed():
	resume()


func _on_PauseButton_pressed():
	pause_game()


func _on_main_menu_pressed():
	GGT.change_scene("res://scenes/menu/menu.tscn", {"show_progress_bar": false})


func _on_settings_pressed() -> void:
	settings_menu.show()


func _on_settings_menu_visibility_changed() -> void:
	margin_container.visible = !settings_menu.visible
	if !settings_menu.visible:
		resume_option.grab_focus() # restore focus


func _on_settings_menu_confirm_button_clicked() -> void:
	settings_menu.hide()
