extends Node

const Icons = preload("uid://dhdqwmdcw4n26")
const InputDeviceTracker = preload("uid://dpnmg6swmq30l")
const InputBinding = preload("uid://qv8fn38jaxf6")
const SettingApplier = preload("uid://bb2oa0wnxndx1")
const SettingSources = preload("uid://biwn3sfivkq6w")
const SettingsData = preload("uid://defj5f8oxiba6")
const SettingsI18n = preload("uid://csepy51qxiem1")
const SettingsSchema = preload("uid://dyur3ipiqsfn5")

signal setting_changed(key: String, value: Variant)
# Emitted when the player switches input device family (Xbox to Switch, keyboard to controller) 
signal input_device_changed(family: String)

const SAVE_DELAY_SECONDS := 0.5

var schema: SettingsSchema
var data: SettingsData

var _applier: SettingApplier
# pending appliers are used to register appliers that are not ready yet, such as keybinds
var _pending_appliers: Dictionary = {} # String key -> Callable
var _save_timer: Timer
var _dirty := false
var _input_family: String = ""

# INIT
#================================================================================#
func _ready() -> void:
	_save_timer = Timer.new()
	_save_timer.one_shot = true
	_save_timer.wait_time = SAVE_DELAY_SECONDS
	_save_timer.timeout.connect(flush)
	add_child(_save_timer)

	SettingsI18n.load_translations()

	# Device tracking lives here in the autoload
	Input.joy_connection_changed.connect(_on_joy_connection_changed)
	InputDeviceTracker.refresh_connections()
	_input_family = InputDeviceTracker.current_family()

	schema = SettingsSchema.new()
	schema.parse()
	SettingSources.apply(schema)

	data = SettingsData.new(schema)
	data.load_saved()

	if data.sanitize_resolution():
		_queue_save()

	_applier = SettingApplier.new()
	_applier.setup(data, schema)
	_flush_pending_appliers()
	_applier.apply_all()
#================================================================================#

# DESTRUCT
#================================================================================#
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_EXIT_TREE:
		flush(true)
#================================================================================#

# API
#================================================================================#
func get_setting(key: String) -> Variant:
	if not schema.has_key(key):
		push_error(_unknown_key_message(key))
		return null
	return data.get_value(key)

func set_setting(key: String, value: Variant, persist: bool = true) -> void:
	if not schema.has_key(key):
		push_error(_unknown_key_message(key))
		return

	if not data.set_value(key, value):
		return

	var applied: Variant = data.get_value(key)
	_applier.apply(key, applied)
	setting_changed.emit(key, applied)
	if persist:
		_queue_save()

func get_keybind_conflicts() -> Dictionary:
	var owners: Dictionary = {}
	var counts: Dictionary = {}
	for key in schema.keys():
		if str(schema.get_setting(key).get("type", "")) != "keybind":
			continue
		var binding = InputBinding.coerce(data.get_value(key))
		for column in [InputBinding.KEYBOARD, InputBinding.CONTROLLER]:
			for encoded in binding[column]:
				var fingerprint := InputBinding.event_fingerprint(encoded)
				if fingerprint.is_empty():
					continue
				if not owners.has(fingerprint):
					owners[fingerprint] = []
					counts[fingerprint] = 0
				var keys: Array = owners[fingerprint]
				if key not in keys:
					keys.append(key)
				counts[fingerprint] += 1

	var conflicts: Dictionary = {}
	for fingerprint in owners:
		var keys: Array = owners[fingerprint]
		if counts[fingerprint] >= 2:
			conflicts[fingerprint] = keys.duplicate()
	return conflicts

func reset_section(section_id: String) -> void:
	_announce(data.reset_section(section_id))

func reset_all() -> void:
	_announce(data.reset_all())

func register_applier(key: String, callable: Callable) -> void:
	if _applier == null:
		_pending_appliers[key] = callable
		return
	_applier.register(key, callable)
	if data.has_key(key):
		_applier.apply(key, data.get_value(key))

func unregister_applier(key: String) -> void:
	_pending_appliers.erase(key)
	if _applier != null:
		_applier.unregister(key)

func flush(wait: bool = false) -> void:
	_save_timer.stop()
	if _dirty:
		_dirty = false
		data.save()
	if wait:
		data.wait_for_saves()
#================================================================================#

# INTERNAL
#================================================================================#
func _input(event: InputEvent) -> void:
	Icons.note_input_event(event)
	_emit_input_family_if_changed()

func _on_joy_connection_changed(_device: int, _connected: bool) -> void:
	InputDeviceTracker.refresh_connections()
	_emit_input_family_if_changed()

func _emit_input_family_if_changed() -> void:
	var family := InputDeviceTracker.current_family()
	if family == _input_family:
		return
	_input_family = family
	input_device_changed.emit(family)

func _announce(changed_keys: PackedStringArray) -> void:
	for key in changed_keys:
		var value: Variant = data.get_value(key)
		_applier.apply(key, value)
		setting_changed.emit(key, value)

	if not changed_keys.is_empty():
		_queue_save()

func _flush_pending_appliers() -> void:
	for key in _pending_appliers:
		_applier.register(key, _pending_appliers[key])
	_pending_appliers.clear()

func _queue_save() -> void:
	_dirty = true
	_save_timer.start()

func _unknown_key_message(key: String) -> String:
	var suggestion := schema.suggest_key(key)
	if suggestion.is_empty():
		return "Sweet Settings: no setting named '%s' in '%s'." % [key, schema.source_path]

	return (
		"Sweet Settings: no setting named '%s' in '%s'. Did you mean '%s'?"
		% [key, schema.source_path, suggestion]
	)
#================================================================================#
